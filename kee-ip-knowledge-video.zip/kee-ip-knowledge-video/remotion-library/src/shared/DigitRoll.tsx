import React from 'react';
import {useCurrentFrame} from 'remotion';
import {dampedSettle} from './motion';

/**
 * 数字翻滚：每一位像老式里程表一样滚到目标数字，末尾带一次回弹。
 *
 * 思路参考 video-shotcraft 的 odometer-digit-roll（Apache 2.0），
 * 但实现是按使用者风格重写的：
 *   - 它是横屏产品片的机械里程表质感（金属滚筒 + 阴影）
 *   - 我们要的是编辑感大字：无衬底、跟 DisplayHeadline 同字体、
 *     靠 dampedSettle 给一点手绘的不精确感
 *
 * 用在哪：
 *   镜01 的「11」——现在是直接淡入，翻滚更能让人下意识去数
 *   镜03 的 21 / 0 / 16 —— 三个数依次滚出，比同时淡入有节奏
 *
 * 纯函数：只依赖 frame，可并行渲染。
 */

export const DigitRoll: React.FC<{
  /** 目标数字 */
  value: number;
  /** 起滚帧 */
  delay?: number;
  /** 滚动时长（帧） */
  duration?: number;
  /** 每一位之间的错开帧数，0 表示所有位同时滚 */
  stagger?: number;
  fontSize?: number;
  color?: string;
  fontFamily?: string;
  fontWeight?: number;
  /**
   * 单元格高度 / 字号。既是滚动步距，也是 `overflow: hidden` 的可视窗口。
   *
   * 原值 0.92 会裁掉字形顶部：line-height 小于字体自身的 normal（Inter Tight 约 1.21em）
   * 时半行距为负，字形上沿被顶出内容盒，再被 overflow 切平。比例写死，
   * 所以任何字号都在裁，只是字号越大绝对切量越明显——430px 的绿色 `0` 顶部
   * 被切成一条平边才被发现。
   *
   * 1.02 给足了 heavy 字重数字的余量；调小之前先渲一帧看顶边是不是圆的。
   */
  cellRatio?: number;
  /**
   * 单元格宽度 / 字号。滚动窗口是 `overflow: hidden`，**横向也会裁**。
   *
   * 原值 0.58 窄于 heavy 字重数字的实际字宽，`0`、`8` 这类圆字左右两侧
   * 会被切成平边。0.72 对 Inter Tight 800 够用。
   *
   * 单个数字不需要「滚」的观感时，别用本组件——直接渲一个大字，
   * 没有裁剪盒就没有这类问题。
   */
  widthRatio?: number;
  style?: React.CSSProperties;
}> = ({
  value,
  delay = 0,
  duration = 22,
  stagger = 4,
  fontSize = 280,
  color,
  fontFamily,
  fontWeight = 800,
  cellRatio = 1.02,
  widthRatio = 0.72,
  style,
}) => {
  const frame = useCurrentFrame();
  const digits = String(value).split('');
  // 单个数字的行高，滚动距离按它算
  const cell = fontSize * cellRatio;

  return (
    <div style={{display: 'flex', alignItems: 'flex-start', ...style}}>
      {digits.map((d, i) => {
        const target = Number(d);
        const start = delay + i * stagger;
        const t = Math.min(1, Math.max(0, (frame - start) / duration));
        // easeOutCubic：起步快、收尾慢，像滚筒被甩出去后自己停下
        const eased = 1 - Math.pow(1 - t, 3);

        // 多转两圈再落到目标位，转的过程才有「滚」的观感
        const TURNS = 2;
        const rolled = eased * (TURNS * 10 + target);
        // 落定后叠一次阻尼回弹，幅度很小，只为去掉机器感
        const settle =
          t >= 1 ? dampedSettle(frame - start - duration, 0.12, 0.22) * cell * 0.05 : 0;
        const offset = -(rolled % 10) * cell + settle;

        return (
          <div
            key={i}
            style={{
              height: cell,
              overflow: 'hidden',
              // 数字等宽，滚动时左右不跳
              width: fontSize * widthRatio,
              position: 'relative',
            }}
          >
            <div style={{position: 'absolute', top: 0, left: 0, transform: `translateY(${offset}px)`}}>
              {/* 0-9 再接一个 0，越过边界时无缝 */}
              {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map((n, k) => (
                <div
                  key={k}
                  style={{
                    height: cell,
                    fontSize,
                    lineHeight: `${cell}px`,
                    fontFamily,
                    fontWeight,
                    color,
                    textAlign: 'center',
                    fontVariantNumeric: 'tabular-nums',
                  }}
                >
                  {n}
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};
