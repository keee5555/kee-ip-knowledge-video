import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {DisplayHeadline, MicroLabel, PaperStage} from '../components/EditorialComponents';
import {colors, fonts} from '../theme';
import {DigitRoll} from './DigitRoll';
import {ListReveal, MarkerUnderline, StackPress, TextStagger, TitleDemote} from './MotionKit';

/**
 * 六个动效的演示片，只为肉眼验收用，不进任何成片。
 * 改了 MotionKit 之后渲一遍这个就能看清每个的手感。
 */

export const MOTION_KIT_DEMO_DURATION = 6 * 90;

const Slide: React.FC<{label: string; children: React.ReactNode}> = ({label, children}) => (
  <PaperStage>
    <div style={{position: 'absolute', left: 90, top: 92}}>
      <MicroLabel>{label}</MicroLabel>
    </div>
    <div style={{position: 'absolute', left: 90, top: 320, right: 90}}>{children}</div>
  </PaperStage>
);

const Row: React.FC<{children: React.ReactNode; accent?: boolean}> = ({children, accent}) => (
  <div
    style={{
      fontSize: 58,
      fontWeight: 650,
      color: accent ? colors.terracotta : colors.forest,
      borderBottom: `2px solid ${colors.whisper}`,
      paddingBottom: 12,
    }}
  >
    {children}
  </div>
);

const S1 = () => (
  <Slide label="01 / DigitRoll 数字翻滚">
    <DigitRoll value={11} delay={6} duration={26} stagger={5} fontSize={240} color={colors.forest} fontFamily={fonts.display} />
    <div style={{marginTop: 30, fontFamily: fonts.mono, fontSize: 28, color: colors.terracotta}}>
      两位错开 5 帧，末尾阻尼落定
    </div>
  </Slide>
);

const S2 = () => (
  <Slide label="02 / StackPress 逐条压入">
    <StackPress
      delay={8}
      step={9}
      items={['选题定', '人群定', '角度定', '结构定', '标题定'].map((t, i) => (
        <Row key={t} accent={i === 1}>{t}</Row>
      ))}
    />
  </Slide>
);

const S3 = () => (
  <Slide label="03 / ListReveal 遮罩揭出">
    <ListReveal
      delay={8}
      step={13}
      items={['状态不靠追问', '方法不靠记忆', '结果能够回流'].map((t, i) => (
        <Row key={t} accent={i === 2}>{t}</Row>
      ))}
    />
  </Slide>
);

const S4 = () => (
  <Slide label="04 / MarkerUnderline 马克笔划线">
    <DisplayHeadline size={92}>连接才是重点</DisplayHeadline>
    <MarkerUnderline width={520} delay={22} duration={10} color={colors.forest} style={{marginTop: 6}} />
    <div style={{marginTop: 40, fontFamily: fonts.mono, fontSize: 27, color: colors.terracotta}}>
      10 帧一笔呵成，贴着字底，有粗细变化
    </div>
  </Slide>
);

const S5 = () => (
  <Slide label="05 / TextStagger 逐字入场">
    <div style={{fontFamily: fonts.display, fontSize: 88, fontWeight: 800, color: colors.forest}}>
      <TextStagger text="每条都要重来一遍" delay={8} within={26} />
    </div>
    <div style={{marginTop: 40, fontFamily: fonts.mono, fontSize: 27, color: colors.terracotta}}>
      字数多时自动收紧间隔，保证在给定帧内出完
    </div>
  </Slide>
);

const S6 = () => {
  const frame = useCurrentFrame();
  return (
    <PaperStage>
      <TitleDemote
        hold={38}
        duration={24}
        from={92}
        to={27}
        origin={{left: 90, top: 320}}
        target={{left: 90, top: 92}}
        style={{fontFamily: fonts.display, fontWeight: 800, color: colors.forest}}
      >
        四层之间只有三条关系
      </TitleDemote>
      <div
        style={{
          position: 'absolute',
          left: 90,
          top: 200,
          right: 90,
          opacity: Math.min(1, Math.max(0, (frame - 60) / 16)),
        }}
      >
        <Row>页面 · 把状态显示给人</Row>
        <div style={{height: 18}} />
        <Row accent>数据 · 存放全部状态</Row>
        <div style={{height: 18}} />
        <Row>Agent · 执行并回写</Row>
      </div>
      <div style={{position: 'absolute', left: 90, bottom: 300, fontFamily: fonts.mono, fontSize: 27, color: colors.terracotta}}>
        标题降格成角标，让位但不退场
      </div>
    </PaperStage>
  );
};

const slides = [S1, S2, S3, S4, S5, S6];

export const MotionKitDemo: React.FC = () => (
  <AbsoluteFill style={{background: colors.cream, fontFamily: fonts.body}}>
    {slides.map((C, i) => (
      <Sequence key={i} from={i * 90} durationInFrames={90}>
        <C />
      </Sequence>
    ))}
  </AbsoluteFill>
);
