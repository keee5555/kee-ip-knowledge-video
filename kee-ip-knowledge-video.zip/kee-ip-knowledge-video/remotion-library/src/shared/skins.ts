/**
 * 皮肤令牌 —— 动效跨风格复用的唯一契约。
 *
 * ─────────────────────────────────────────────
 * 立此文件的原因（2026-08-10）：
 *
 * 使用者定的规矩：**进 MotionKit 的动效，一律要在 A/B/C 三套风格里复用。**
 * 所以「能不能换色」不是加分项，是准入条件。
 *
 * 问题在于以前没有统一说法：风格 A 叫 forest/yellow/terracotta，
 * B 叫 cream/green/orange，C 叫 ink/yellow/orange——同一个角色三个名字。
 * 写组件的人只能瞎猜该开哪些 props，用组件的人只能翻源码才知道要传什么。
 *
 * 这里把颜色按**角色**收敛成 10 个令牌。三套风格各填一份，
 * 动效只认角色不认具体色值。
 * ─────────────────────────────────────────────
 *
 * 新动效的准入规则（三条，缺一不可）：
 *
 *   1. 组件不得 import 任何 theme / themeB / themeC。
 *      颜色一律走 props，默认值可以取风格 A（图省事），但渲染体里
 *      不许出现任何写死的色值。
 *
 *   2. 每个颜色 prop 必须能对上下面某一个令牌。
 *      对不上说明这个动效在别的风格里没有对应物——那就不该进 MotionKit，
 *      留在该风格自己的 Components 里。
 *
 *   3. 落库前必须在 MotionKitDemoAll 里跑一遍 A / B / C。
 *      demo 的 22 张 slide 只写一份、用 skin 参数化，
 *      藏着风格假设的组件会当场崩样，不靠眼力找。
 */

import {colors, fonts} from '../theme';
import {bColors, bFonts} from '../style-b/themeB';
import {cColors, cFonts} from '../style-c/themeC';

export type Skin = {
  /** 风格代号，A / B / C */
  key: 'A' | 'B' | 'C';

  /** 正文主色。场底上最重的那个颜色，标题和正文都用它 */
  ink: string;
  /** 次级色。未激活、已读、辅助说明。必须比 ink 弱但仍可读 */
  muted: string;
  /** 强调色。一屏最多一处，用来标关键词 / 划线 / 圈注 */
  accent: string;
  /** 第二强调色。给注解、参数说明这类「元信息」，不跟 accent 抢 */
  accent2: string;

  /** 面色。胶囊、色块、高亮条的底 */
  surface: string;
  /** 面色上的字色。必须和 surface 有足够对比 */
  onSurface: string;
  /** 场底色。整屏背景，也是反白字的字色 */
  bg: string;

  /** 多色序列。纸屑、图例、分类色环这类需要一串颜色的场合 */
  palette: string[];

  /** 标题字体 */
  display: string;
  /** 正文 / 注解字体 */
  mono: string;

  /**
   * 手绘抖动强度。这是唯一一个**非颜色**的风格令牌。
   * 圈注、下划线这类「手画的」笔迹靠它区分风格：
   * B 是硬边几何风，抖动跟它的语言冲突，必须给 0。
   */
  rough: number;
};

/** A —— 纸感编辑风：米白纸底 + 墨绿 + 柠檬黄 */
export const SKIN_A: Skin = {
  key: 'A',
  ink: colors.forest,
  muted: colors.pencil,
  accent: colors.terracotta,
  accent2: colors.terracotta,
  surface: colors.yellow,
  onSurface: colors.forest,
  bg: colors.cream,
  palette: [colors.yellow, colors.terracotta, colors.mint, colors.teal, colors.blush],
  display: fonts.display,
  mono: fonts.mono,
  rough: 7,
};

/** B —— 深黑荧光风：纯黑场 + 荧光绿 + 橙 */
export const SKIN_B: Skin = {
  key: 'B',
  ink: bColors.cream,
  muted: bColors.muted,
  accent: bColors.green,
  accent2: bColors.orange,
  surface: bColors.green,
  onSurface: bColors.black,
  bg: bColors.black,
  palette: [bColors.green, bColors.orange, bColors.pink, bColors.lilac, bColors.blue],
  display: bFonts.main,
  mono: bFonts.main,
  // 硬边几何风，笔迹发抖跟它冲突
  rough: 0,
};

/** C —— 暖奶油风：奶油底 + 蓝墨 + 黄橙，圆体手写调性 */
export const SKIN_C: Skin = {
  key: 'C',
  ink: cColors.ink,
  muted: cColors.inkLight,
  accent: cColors.orange,
  accent2: cColors.blue,
  surface: cColors.yellow,
  onSurface: cColors.ink,
  bg: cColors.cream,
  palette: [cColors.yellow, cColors.orange, cColors.blue, cColors.creamDeep],
  display: cFonts.title,
  mono: cFonts.body,
  rough: 6,
};

export const SKINS: Record<'A' | 'B' | 'C', Skin> = {A: SKIN_A, B: SKIN_B, C: SKIN_C};
