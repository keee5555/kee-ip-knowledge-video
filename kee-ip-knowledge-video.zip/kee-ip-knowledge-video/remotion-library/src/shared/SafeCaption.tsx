import React from 'react';
import {useCurrentFrame} from 'remotion';
import {CANVAS, CAPTION, CAPTION_BLOCK_HEIGHT, LINE_BREAK, TEXT_WRAP} from '../layout';

/**
 * 全风格共用字幕组件。风格 A/B/C 一律使用本组件，
 * 禁止在生产文件里内联重写字幕。
 *
 * 已废弃并应删除：
 *   风格A EditorialComponents.PlainCaption
 *   风格B ComponentsB.CreamCaption
 */

export type CaptionCue = {
  /** 起始帧，含 */
  from: number;
  /** 结束帧，不含 */
  to: number;
  text: string;
};

const CaptionBox: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div
    style={{
      position: 'absolute',
      zIndex: 100,
      left: CAPTION.left,
      right: CAPTION.right,
      bottom: CAPTION.bottom,
      height: CAPTION_BLOCK_HEIGHT,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    }}
  >
    <div
      style={{
        maxWidth: CAPTION.maxWidth,
        padding: `${CAPTION.paddingY / 2}px 22px`,
        borderRadius: CAPTION.borderRadius,
        background: CAPTION.background,
        color: CAPTION.color,
        fontFamily: CAPTION.fontFamily,
        fontSize: CAPTION.fontSize,
        lineHeight: CAPTION.lineHeight,
        fontWeight: CAPTION.fontWeight,
        textAlign: 'center',
        // 禁止单字成行
        textWrap: TEXT_WRAP.balance,
        lineBreak: LINE_BREAK,
      }}
    >
      {children}
    </div>
  </div>
);

/** 生产文件用：按帧区间切换字幕 */
export const SafeCaption: React.FC<{cues: CaptionCue[]}> = ({cues}) => {
  const frame = useCurrentFrame();
  const active = cues.find((cue) => frame >= cue.from && frame < cue.to);
  if (!active) return null;
  return <CaptionBox>{active.text}</CaptionBox>;
};

/** 样片和规范板用：整段只显示一句 */
export const StaticCaption: React.FC<{children: React.ReactNode}> = ({children}) => (
  <CaptionBox>{children}</CaptionBox>
);

/** 供闸门脚本读取的画布常量再导出，避免脚本硬编码 */
export const CAPTION_CANVAS = CANVAS;
