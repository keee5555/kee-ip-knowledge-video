import type {CaptionCue} from './SafeCaption';

/**
 * 按字幕节奏排期，而不是手填 delay。
 *
 * ─────────────────────────────────────────────
 * 为什么要有这个：
 *
 * 实测 CNT-EXAMPLE-001 全片 58% 的时间画面完全静止——口播还在说，
 * 但入场动效在每镜前 40% 就跑完了。根因是 delay 全靠手填，
 * 跟口播讲到哪句毫无关系，于是所有元素都堆在开头一次性放完。
 *
 * 正确的做法是：一句字幕对应一次画面推进。
 * 口播讲到第几句，画面就推进到第几步——观众耳朵听到的和眼睛看到的同步前进，
 * 静止段自然就没了。
 * ─────────────────────────────────────────────
 */

/** 该镜覆盖到的字幕，按时间排好 */
export const cuesOfScene = (
  cues: CaptionCue[],
  sceneFrom: number,
  duration: number,
): CaptionCue[] =>
  cues.filter((c) => c.from < sceneFrom + duration && c.to > sceneFrom).sort((a, b) => a.from - b.from);

/**
 * 把 N 个画面元素分配到该镜的字幕上，返回每个元素的场景内 delay。
 *
 * 元素比字幕多时，多出来的按最后一句均分；
 * 元素比字幕少时，取前 N 句——**优先保证每句都有画面动作**。
 *
 * `lead` 让元素比字幕早几帧出现（默认 4）：观众先看到再听到，
 * 比反过来自然。太大会脱节，闸门 G5 的容差是 15 帧。
 */
export const scheduleByCues = (
  cues: CaptionCue[],
  sceneFrom: number,
  duration: number,
  count: number,
  lead = 4,
): number[] => {
  const scoped = cuesOfScene(cues, sceneFrom, duration);
  if (scoped.length === 0) {
    // 没有字幕就退回均分，至少铺满整镜
    return Array.from({length: count}, (_, i) => Math.round((duration * 0.15) + (i * duration * 0.6) / count));
  }

  const out: number[] = [];
  for (let i = 0; i < count; i++) {
    if (i < scoped.length) {
      out.push(Math.max(0, scoped[i].from - sceneFrom - lead));
      continue;
    }
    // 多出来的元素挤进最后一句的时长里
    const last = scoped[scoped.length - 1];
    const extra = i - scoped.length + 1;
    const room = last.to - last.from;
    const slots = count - scoped.length + 1;
    out.push(Math.max(0, last.from - sceneFrom - lead + Math.round((room * extra) / slots)));
  }
  return out;
};

/**
 * 该镜最后一次画面动作应该发生在哪一帧之前。
 *
 * 用来自查：如果所有 delay 都远小于这个值，说明后半段是死的。
 * 闸门 G14 用同样的口径做静态检查。
 */
export const lastCueStart = (cues: CaptionCue[], sceneFrom: number, duration: number): number => {
  const scoped = cuesOfScene(cues, sceneFrom, duration);
  return scoped.length ? scoped[scoped.length - 1].from - sceneFrom : Math.round(duration * 0.6);
};
