import React from 'react';
import {useCurrentFrame} from 'remotion';

/**
 * 线条沸腾 —— 让静止的画面「活着」。
 *
 * 手法参考 video-shotcraft 的 line-boil 配方卡（Apache 2.0），按使用者风格重写。
 *
 * 原理：SVG feTurbulence 生成噪声，feDisplacementMap 拿它去扰动图形轮廓，
 * 噪声的 seed 每 3 帧换一次——效果就是轮廓像被人一帧一帧重新描过，
 * 有手绘逐帧动画那种微微呼吸的活气。
 *
 * 为什么需要它：
 *   实测 CNT-EXAMPLE-001 全片 58% 的时间画面完全静止（口播还在说，
 *   但入场动效早就跑完了）。这类长 hold 段最伤观感。
 *   沸腾是「寄生型」——不占时长、不改布局，套在已经站定的元素上就行。
 *
 * 用在哪：大标题、描边框、手绘圈注这类**有轮廓**的元素。
 * 不要用在：实心小图标、人物立绘、截图——沸腾会读作模糊或故障。
 */

export const LineBoil: React.FC<{
  children: React.ReactNode;
  /** 形变幅度。大字标题 8，小字细线 5-6。>12 会读作故障扭曲 */
  scale?: number;
  /** 每几帧重描一次。3 是手绘感，2 太贼，4 以上读作卡顿 */
  every?: number;
  /** 从第几帧开始沸腾——通常等于入场动效结束的那一帧 */
  from?: number;
  /** 形变尺度。0.015 约等于字高级；0.05 以上变成毛边噪点 */
  frequency?: number;
  style?: React.CSSProperties;
}> = ({children, scale = 7, every = 3, from = 0, frequency = 0.015, style}) => {
  const frame = useCurrentFrame();
  const active = frame >= from;
  // seed 每 every 帧跳一次，就是「重描」的节拍
  const seed = Math.floor(Math.max(0, frame - from) / every);
  const id = `boil-${Math.round(scale * 100)}-${every}-${Math.round(frequency * 10000)}`;

  return (
    <div style={style}>
      <svg width="0" height="0" style={{position: 'absolute'}} aria-hidden>
        <filter id={id}>
          <feTurbulence
            type="fractalNoise"
            baseFrequency={frequency}
            numOctaves={1}
            seed={seed}
            result="noise"
          />
          <feDisplacementMap
            in="SourceGraphic"
            in2="noise"
            scale={active ? scale : 0}
            xChannelSelector="R"
            yChannelSelector="G"
          />
        </filter>
      </svg>
      <div style={{filter: active ? `url(#${id})` : undefined}}>{children}</div>
    </div>
  );
};
