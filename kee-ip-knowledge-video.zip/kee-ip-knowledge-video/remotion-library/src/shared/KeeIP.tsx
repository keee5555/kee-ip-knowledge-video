import React from 'react';
import {Img, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {IP_ASPECT_RATIO} from '../layout';

/**
 * 使用者 IP 立绘 — 风格无关。
 *
 * 全部资产是同一个人同一套造型（深蓝长卷发 / 黑西装 / 蓝阔腿裤 / 黄鞋），
 * 换风格不换人。5 个姿势三套风格共用，不再按风格分目录。
 *
 * 源图 941×1672 真透明（四角 alpha=0，全透明像素约 66%），
 * 垫在任何底色上都不露白边，深底浅底都能直接用。
 */

export type KeePose = 'explaining' | 'pointing' | 'confused' | 'confirming' | 'executing';

/** 姿势语义 — 挑姿势按这个表，不要凭图好看挑 */
export const KEE_POSES: Record<KeePose, string> = {
  explaining: '摊手讲解 — 陈述、铺垫、讲概念',
  pointing: '抬手指向左上 — 指画面里的某个元素',
  confused: '托腮思考 — 提问、卡点、痛点',
  confirming: '竖大拇指 — 结论、认可、收尾',
  executing: '写字板打勾 — 验收、清单、执行',
};

export const KeeIP: React.FC<{
  action: KeePose;
  width?: number;
  delay?: number;
  /** 描边色。深底或花底上用来把人物从背景里拔出来；不传则不描边 */
  outline?: string;
  outlineWidth?: number;
  /** 入场上移距离，越大越有弹入感 */
  rise?: number;
  damping?: number;
  stiffness?: number;
  style?: React.CSSProperties;
}> = ({
  action,
  width = 380,
  delay = 0,
  outline,
  outlineWidth = 6,
  rise = 60,
  damping = 18,
  stiffness = 88,
  style,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pop = spring({frame: Math.max(0, frame - delay), fps, config: {damping, stiffness}});
  const o = outlineWidth;
  return (
    <Img
      src={staticFile(`ip/kee-${action}-v1.png`)}
      style={{
        width,
        objectFit: 'contain',
        opacity: pop,
        transform: `translateY(${(1 - pop) * rise}px) scale(${0.96 + pop * 0.04})`,
        ...(outline
          ? {
              filter: `drop-shadow(${o}px 0 0 ${outline}) drop-shadow(-${o}px 0 0 ${outline}) drop-shadow(0 ${o}px 0 ${outline}) drop-shadow(0 -${o}px 0 ${outline})`,
            }
          : {}),
        ...style,
      }}
    />
  );
};

/** 按宽度算立绘底边，用于确认不压字幕（闸门 G10 的同一套算法） */
export const keeIpBottom = (top: number, width: number) => top + width * IP_ASPECT_RATIO;
