import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {dampedSettle, lagged, velocityAt} from './motion';
import {colors} from '../theme';

/**
 * 动效套件。
 *
 * 手感参考 video-shotcraft（Apache 2.0）的几张配方卡，实现按使用者风格重写：
 *   list-stack-press      → StackPress
 *   list-reveal           → ListReveal
 *   marker-underline-title→ MarkerUnderline
 *   split-text-stagger    → TextStagger
 *   title-demote-to-label → TitleDemote
 *
 * 它那套是横屏产品片质感（金属、粒子、相机运镜），我们要的是纸感编辑风：
 * 没有阴影、没有渐变、靠位移和阻尼给重量，靠手绘笔触给人味。
 *
 * 全部是帧号的纯函数，可并行渲染。
 */

const ease = (t: number) => 1 - Math.pow(1 - t, 3);
const clamp01 = (t: number) => Math.min(1, Math.max(0, t));

/* ─────────────────────────────────────────────
 * StackPress —— 逐条压入，整摞被压一下再弹回
 *
 * 原卡的意图是「堆叠有重量」：新的一条落上来，已落定的整摞被压下再弹回，
 * 观众从物理反馈里读出「这是实打实攒下来的」。
 *
 * 用在：镜01 的十一项判断、镜02 的三条成本
 * ───────────────────────────────────────────── */
export const StackPress: React.FC<{
  items: React.ReactNode[];
  /** 起始帧 */
  delay?: number;
  /** 每条间隔帧 */
  step?: number;
  /** 被压下的位移峰值 */
  press?: number;
  gap?: number;
  style?: React.CSSProperties;
}> = ({items, delay = 0, step = 6, press = 7, gap = 18, style}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{display: 'grid', gap, ...style}}>
      {items.map((node, i) => {
        const start = delay + i * step;
        const t = clamp01((frame - start) / 12);
        // 自己入场：从下方推上来
        const enter = (1 - ease(t)) * 26;

        // 被后面每一条落地压一下——越靠上被压得越多，衰减保证不会无限叠加
        let pressed = 0;
        for (let j = i + 1; j < items.length; j++) {
          const hit = frame - (delay + j * step + 12);
          if (hit > 0 && hit < 30) {
            pressed += dampedSettle(hit, 0.13, 0.3) * press * (1 - (j - i) * 0.18);
          }
        }

        return (
          <div
            key={i}
            style={{
              opacity: ease(t),
              transform: `translateY(${enter + Math.max(0, pressed)}px)`,
            }}
          >
            {node}
          </div>
        );
      })}
    </div>
  );
};

/* ─────────────────────────────────────────────
 * ListReveal —— 逐条从遮罩里揭出来
 *
 * 比 StackPress 安静：不做物理反馈，用一条从左往右推开的遮罩把内容「显影」。
 * 适合不想要重量感、只想要秩序感的清单。
 *
 * 用在：镜08 的三条验收标准
 * ───────────────────────────────────────────── */
export const ListReveal: React.FC<{
  items: React.ReactNode[];
  delay?: number;
  step?: number;
  gap?: number;
  style?: React.CSSProperties;
}> = ({items, delay = 0, step = 10, gap = 22, style}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{display: 'grid', gap, ...style}}>
      {items.map((node, i) => {
        const t = clamp01((frame - (delay + i * step)) / 14);
        const e = ease(t);
        return (
          <div
            key={i}
            style={{
              // 遮罩从左往右退开，内容像被擦出来
              clipPath: `inset(0 ${(1 - e) * 100}% 0 0)`,
              opacity: 0.25 + e * 0.75,
            }}
          >
            {node}
          </div>
        );
      })}
    </div>
  );
};

/* ─────────────────────────────────────────────
 * MarkerUnderline —— 关键词底下快速划一笔马克笔
 *
 * 原卡的三个命门我们照单接受：
 *   快 —— 8-12 帧一笔呵成，慢了读作加载条
 *   近 —— 贴着字底，离远了就不是「圈重点」
 *   糙 —— 笔形有粗细变化和毛边，不能是一条规整的矩形
 *
 * 和已有的 MarkerHighlight 的区别：那个是整块高亮底色，
 * 这个是一笔下划线，更轻，不抢标题的戏。
 * ───────────────────────────────────────────── */
export const MarkerUnderline: React.FC<{
  width: number;
  delay?: number;
  /** 划完用多少帧，8-12 之间 */
  duration?: number;
  color?: string;
  thickness?: number;
  style?: React.CSSProperties;
}> = ({width, delay = 0, duration = 10, color = '#1A3300', thickness = 9, style}) => {
  const frame = useCurrentFrame();
  const t = clamp01((frame - delay) / duration);
  const e = ease(t);
  const h = thickness * 2.2;
  return (
    <svg width={width} height={h} viewBox={`0 0 ${width} ${h}`} style={style}>
      <path
        // 微上斜 + 中段略粗，模拟手腕发力
        d={`M2 ${h * 0.72} Q ${width * 0.35} ${h * 0.42} ${width * 0.62} ${h * 0.55} T ${width - 2} ${h * 0.3}`}
        fill="none"
        stroke={color}
        strokeWidth={thickness}
        strokeLinecap="round"
        pathLength="1"
        strokeDasharray="1"
        strokeDashoffset={1 - e}
        opacity={0.9}
      />
    </svg>
  );
};

/* ─────────────────────────────────────────────
 * TextStagger —— 逐字错开入场
 *
 * 每个字自己从下方浮起，相邻字错开两三帧。字数多时自动收紧间隔，
 * 保证整句在给定帧数内出完——否则长标题会拖到下一句口播。
 *
 * 用在：需要「一个字一个字砸出来」的强调句
 * ───────────────────────────────────────────── */
export const TextStagger: React.FC<{
  text: string;
  delay?: number;
  /** 整句必须在这么多帧内出完 */
  within?: number;
  style?: React.CSSProperties;
}> = ({text, delay = 0, within = 24, style}) => {
  const frame = useCurrentFrame();
  const chars = Array.from(text);
  // 字数多就自动收紧，保证总时长可控
  const step = Math.max(1, Math.min(3, within / Math.max(1, chars.length)));
  return (
    <span style={{display: 'inline-flex', flexWrap: 'wrap', ...style}}>
      {chars.map((c, i) => {
        const t = clamp01((frame - (delay + i * step)) / 10);
        const e = ease(t);
        return (
          <span
            key={i}
            style={{
              display: 'inline-block',
              opacity: e,
              transform: `translateY(${(1 - e) * 22}px)`,
              // 空格不能被 inline-block 吃掉
              whiteSpace: 'pre',
            }}
          >
            {c}
          </span>
        );
      })}
    </span>
  );
};

/* ─────────────────────────────────────────────
 * TitleDemote —— 标题降格成角标，而不是消失
 *
 * 原卡的洞察很好：标题的常规命运是「出现→消失→内容登场」，
 * 标题和内容互不认识。降格让标题**让位而不退场**——
 * 大字站稳一拍，然后连续缩小平移到左上角变成小节标签。
 *
 * 用在：需要强开场又要给内容让位的镜；也可以作为镜与镜之间的承接
 * ───────────────────────────────────────────── */
export const TitleDemote: React.FC<{
  children: React.ReactNode;
  /** 大字站稳多少帧后开始降格 */
  hold?: number;
  /** 降格过程帧数 */
  duration?: number;
  /** 大字号 */
  from?: number;
  /** 降格后的字号 */
  to?: number;
  /** 降格后落位 */
  target?: {left: number; top: number};
  origin?: {left: number; top: number};
  style?: React.CSSProperties;
}> = ({
  children,
  hold = 34,
  duration = 22,
  from = 92,
  to = 27,
  target = {left: 90, top: 92},
  origin = {left: 90, top: 300},
  style,
}) => {
  const frame = useCurrentFrame();
  const appear = clamp01(frame / 12);
  const t = clamp01((frame - hold) / duration);
  const e = ease(t);

  return (
    <div
      style={{
        position: 'absolute',
        left: interpolate(e, [0, 1], [origin.left, target.left]),
        top: interpolate(e, [0, 1], [origin.top, target.top]),
        fontSize: interpolate(e, [0, 1], [from, to]),
        opacity: appear * (1 - e * 0.35),
        letterSpacing: e * 1.4,
        transformOrigin: 'left top',
        transform: `translateY(${(1 - appear) * 24}px)`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/* ═══════════════════════════════════════════════════════════════
 * 第二批收编 —— 2026-08-10
 *
 * 又从 video-shotcraft（Apache 2.0）挑了 22 张卡。挑选口径是「不需要
 * 产品页面截图」：ui-entrance / interaction / camera 三类共 52 张全部排除，
 * 它们的前提是有真实网页可截，我们没有。
 *
 * 注意 motion.ts 里那句「其余 106 张都不搭，没有引入」写于第一批时期，
 * 现在的判断是：横屏产品语法确实不搭，但**时序和缓动是与画幅无关的**。
 * 所以照旧只取纯逻辑——参数按 1080×1920 竖版重新标定（原卡多数在
 * 1920×1080 或 480×270 设计坐标下调校，位移量直接照抄会过冲）。
 *
 * 视觉一律按纸感编辑风重写：不用金属渐变、不用粒子辉光、不用 boxShadow。
 * 需要重量就用位移和阻尼，需要人味就用手绘笔触。
 *
 * 全部 props 驱动，颜色字体内容全外传，A/B/C 三套风格通用。
 * ═══════════════════════════════════════════════════════════════ */

/** 种子哈希。硬规矩：禁 Math.random，同一帧号永远同一画面（并行渲染安全） */
const hash01 = (n: number) => {
  const s = Math.sin(n * 127.3) * 43758.5453;
  return s - Math.floor(s);
};

/** 帧窗 [a,b] → 0..1，默认 outCubic。原卡的 seg() 的等价物 */
const seg = (frame: number, a: number, b: number, e: (t: number) => number = ease) =>
  e(clamp01((frame - a) / Math.max(1, b - a)));

const CLAMP = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

/* ───────── 一、文字与字卡 ───────── */

/* BlurSlide —— 逐词入场，y / blur / opacity 三通道同缓动同步收敛
 *
 * 原卡（blur-slide）的价值全在「同步」两个字：三个通道走同一条 outCubic，
 * 所以词是「浮现」不是「飞进来」。任一通道换缓动都会散。
 * 这是最不抢戏的标题入场，适合当默认。
 *
 * 竖版重标定：原卡 dy=40 在 480 宽设计坐标（放大 4 倍 = 160px），
 * 竖版一行装不下那么大位移，收到 26。 */
export const BlurSlide: React.FC<{
  words: string[];
  delay?: number;
  /** 词间错开帧，1-3 帧量级，大了就散成逐词砸 */
  gap?: number;
  /** 单词入场帧数 */
  dur?: number;
  dy?: number;
  blur?: number;
  style?: React.CSSProperties;
}> = ({words, delay = 0, gap = 2, dur = 10, dy = 26, blur = 8, style}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{display: 'flex', flexWrap: 'wrap', columnGap: '0.3em', ...style}}>
      {words.map((w, i) => {
        const p = seg(frame, delay + i * gap, delay + i * gap + dur);
        return (
          <span
            key={i}
            style={{
              opacity: p,
              transform: `translateY(${(1 - p) * dy}px)`,
              filter: p > 0.995 ? undefined : `blur(${(1 - p) * blur}px)`,
              whiteSpace: 'pre',
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

/* PaperTitleCard —— 逐词压印上纸，一个词标强调，短划线收束
 *
 * 原卡（paper-title-card）是模板片的呼吸位：两段高能镜头之间给观众一句话
 * 的喘息。它的三条硬规矩我们照单接受：
 *   ① scale 起点 1.28 —— 这是「压印」读感的甜点，不是随便一个放大值
 *   ② 一句恰好一个强调词 —— 两个 accent 等于没有 accent
 *   ③ 下划线是收束信号 —— 出现即预告本卡快结束，不能早于 16f
 *
 * 时长定式化 50-55f：观众读一句话的时间，长了拖节奏短了读不完。 */
export const PaperTitleCard: React.FC<{
  words: string[];
  /** 哪个词标强调色 + 斜体，一句恰好一个；-1 = 不标 */
  accentAt?: number;
  accent?: string;
  delay?: number;
  /** 下划线像素宽，0 = 不画 */
  underline?: number;
  style?: React.CSSProperties;
}> = ({words, accentAt = -1, accent = colors.terracotta, delay = 0, underline = 220, style}) => {
  const frame = useCurrentFrame();
  const ul = seg(frame, delay + 16, delay + 34);
  return (
    <div style={{display: 'inline-flex', flexDirection: 'column', alignItems: 'flex-start', ...style}}>
      <div style={{display: 'flex', flexWrap: 'wrap', columnGap: '0.28em'}}>
        {words.map((w, i) => {
          const p = seg(frame, delay + 4 + i * 4, delay + 13 + i * 4);
          const isAccent = i === accentAt;
          return (
            <span
              key={i}
              style={{
                opacity: p,
                // 从大压到 1 —— letterpress 的读感来源
                transform: `scale(${1.28 - 0.28 * p})`,
                filter: p > 0.995 ? undefined : `blur(${(1 - p) * 7}px)`,
                color: isAccent ? accent : undefined,
                fontStyle: isAccent ? 'italic' : undefined,
                whiteSpace: 'pre',
              }}
            >
              {w}
            </span>
          );
        })}
      </div>
      {underline > 0 && (
        <div
          style={{
            marginTop: 18,
            width: underline,
            height: 6,
            background: accent,
            transform: `scaleX(${ul})`,
            transformOrigin: 'left center',
          }}
        />
      )}
    </div>
  );
};

/* PillSlotCycle —— 句干钉死，句尾词槽老虎机滚一格
 *
 * 原卡（pill-slot-cycle）解决的是「功能列举」：比逐条列表快，比乱码解码有语义。
 * 关键是句干**完全不动**——一个字都不许抖，观众的眼睛才会锁在词槽上。
 * 旧词上飞淡出、新词从下滑入，一拍 21 帧（约 0.7s）。
 *
 * 竖版改动：原卡 pill 带 boxShadow 和图标，我们去掉阴影只留描边纸片。 */
export const PillSlotCycle: React.FC<{
  /** 句干前半，钉死不动 */
  prefix: string;
  /** 句干后半，可空 */
  suffix?: string;
  /** 轮换词 */
  pills: string[];
  /** 全部轮完后落定的收束词，不给就停在最后一个 pill */
  settle?: string;
  delay?: number;
  /** 每拍帧数 */
  beat?: number;
  pillBg?: string;
  pillColor?: string;
  style?: React.CSSProperties;
}> = ({
  prefix,
  suffix = '',
  pills,
  settle,
  delay = 0,
  beat = 21,
  pillBg = colors.forest,
  pillColor = colors.cream,
  style,
}) => {
  const frame = useCurrentFrame();
  const intro = seg(frame, delay, delay + 12);
  const cycleEnd = delay + 12 + pills.length * beat;
  const fin = seg(frame, cycleEnd, cycleEnd + 14);

  const local = frame - delay - 12;
  const idx = Math.floor(local / beat);

  return (
    <div style={{display: 'flex', alignItems: 'center', flexWrap: 'wrap', columnGap: '0.3em', opacity: intro, ...style}}>
      <span style={{whiteSpace: 'pre'}}>{prefix}</span>
      <span style={{position: 'relative', display: 'inline-block', overflow: 'hidden', verticalAlign: 'middle'}}>
        {/* 词槽：只渲染当前和上一个，其余不挂载 */}
        {pills.map((p, i) => {
          if (i < idx - 1 || i > idx) return null;
          if (settle && frame >= cycleEnd) return null;
          const start = delay + 12 + i * beat;
          const inP = seg(frame, start, start + 9);
          const outP = i === idx - 1 ? seg(frame, start + beat, start + beat + 7) : 0;
          const y = (1 - inP) * 46 - outP * 46;
          const op = Math.min(inP, 1 - outP);
          if (op <= 0.002) return null;
          return (
            <span
              key={p}
              style={{
                display: i === idx ? 'inline-block' : 'block',
                position: i === idx ? 'relative' : 'absolute',
                inset: i === idx ? undefined : 0,
                padding: '0.08em 0.34em',
                borderRadius: 999,
                background: pillBg,
                color: pillColor,
                opacity: op,
                transform: `translateY(${y}px)`,
                whiteSpace: 'pre',
              }}
            >
              {p}
            </span>
          );
        })}
        {settle && frame >= cycleEnd && (
          <span style={{display: 'inline-block', opacity: fin, transform: `translateY(${(1 - fin) * 20}px)`, whiteSpace: 'pre'}}>
            {settle}
          </span>
        )}
      </span>
      {suffix && <span style={{whiteSpace: 'pre'}}>{suffix}</span>}
    </div>
  );
};

/* WordRelay —— 一个恒定主语 + 动词原位接力
 *
 * 原卡（word-relay-filmstrip）左边配一列步进滚动的页面卡，那部分我们丢掉
 * （需要真实截图）。留下的是右侧的接力逻辑：主语恒定不动，动词在**原位**
 * 换——先灰化淡出再换新词，绝不左右平移。
 *
 * 「一个主体 × 多种能力」的枚举段，比三条并列的列表更有主角感。 */
export const WordRelay: React.FC<{
  /** 恒定词，全程不动 */
  fixed: string;
  /** 轮换词 */
  words: string[];
  /** 每个词的切入帧 */
  switches?: number[];
  /** 换词过程帧数 */
  swDur?: number;
  fadeColor?: string;
  style?: React.CSSProperties;
  wordStyle?: React.CSSProperties;
}> = ({fixed, words, switches, swDur = 16, fadeColor = colors.pencil, style, wordStyle}) => {
  const frame = useCurrentFrame();
  const cues = switches ?? words.map((_, i) => 14 + i * 48);
  return (
    <div style={{display: 'flex', flexDirection: 'column', ...style}}>
      <div style={{opacity: seg(frame, 0, 12)}}>{fixed}</div>
      <div style={{position: 'relative', ...wordStyle}}>
        {words.map((w, i) => {
          const sIn = cues[i];
          const sOut = cues[i + 1];
          const pIn = seg(frame, sIn + 7, sIn + swDur);
          // 换词前先灰化——先褪色再退场，读作「交棒」而不是「消失」
          const grey = sOut ? seg(frame, sOut - 14, sOut - 2) : 0;
          const pOut = sOut ? 1 - seg(frame, sOut, sOut + 8) : 1;
          const op = pIn * pOut;
          if (op <= 0.002) return null;
          return (
            <span
              key={w}
              style={{
                position: i === 0 ? 'relative' : 'absolute',
                left: 0,
                top: 0,
                opacity: op,
                color: grey > 0.02 ? fadeColor : undefined,
                transform: `translateY(${(1 - pIn) * 16}px)`,
                whiteSpace: 'pre',
              }}
            >
              {w}
            </span>
          );
        })}
      </div>
    </div>
  );
};

/* KaraokeFill —— 旁白读到哪个词，哪个词就被填亮
 *
 * 这是 22 张里唯一直接绑语音的卡。我们有 CosyVoice 出的时间轴，
 * 词级 start/end 可以从 srt 反推，所以它能真的对上口播——
 * 不是「看起来像跟着读」，是真跟着读。
 *
 * 双层叠放：底层浅色未读字，上层深色按 clip-path 从左往右揭开。
 * 逐词独立叠层，clip 百分比即词内进度，不需要量测词在整行的像素占比。 */
export const KaraokeFill: React.FC<{
  /** 词级时间轴，start/end 是绝对帧号 */
  words: {text: string; start: number; end: number}[];
  read?: string;
  unread?: string;
  /** 读指下划线粗细，0 = 不画 */
  cursor?: number;
  style?: React.CSSProperties;
}> = ({words, read = colors.forest, unread = colors.pencil, cursor = 8, style}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{display: 'flex', flexWrap: 'wrap', columnGap: '0.3em', ...style}}>
      {words.map((w, i) => {
        const p = interpolate(frame, [w.start, w.end], [0, 1], CLAMP);
        const active = frame >= w.start && frame < w.end;
        return (
          <span key={i} style={{position: 'relative', display: 'inline-block', whiteSpace: 'pre'}}>
            <span style={{color: unread}}>{w.text}</span>
            <span style={{position: 'absolute', inset: 0, color: read, clipPath: `inset(0 ${(1 - p) * 100}% 0 0)`}}>
              {w.text}
            </span>
            {active && cursor > 0 && (
              <span style={{position: 'absolute', left: 0, bottom: -14, width: `${p * 100}%`, height: cursor, background: read}} />
            )}
          </span>
        );
      })}
    </div>
  );
};

/* ───────── 二、节奏与蒙太奇 ───────── */

/* useFreezeRemap —— 时间轴非线性重映射
 *
 * 原卡（speed-ramp-freeze / freeze-annotate）的本体不是圈注，是**帧号 remap**：
 * 把「源时间」和「播放时间」解耦，中间插一段斜率为 0 的平台就是定格。
 * 返回源帧号，调用方拿它算位置——所以任何按帧驱动的动画都能被它冻住。
 *
 * 配方卡明确点名「教学解说语境用定格标注」，正是我们的场景。
 * 典型：useFreezeRemap([0,45,100,135],[0,45,45,94]) —— 流动/定格/解冻(1.4x 补偿) */
export const useFreezeRemap = (playStops: number[], srcStops: number[]) => {
  const frame = useCurrentFrame();
  return interpolate(frame, playStops, srcStops, CLAMP);
};

/* HandCircle —— 手绘感圈注椭圆 + 可选指引线
 *
 * feTurbulence 位移让笔迹发抖，这是「手画的」和「电脑画的」的分界线。
 * 滤镜 id 按实例生成，同场多个实例不会串引。 */
export const HandCircle: React.FC<{
  cx: number;
  cy: number;
  rx: number;
  ry: number;
  /** 描画起止帧 */
  from?: number;
  to?: number;
  color?: string;
  width?: number;
  /** 画布尺寸 */
  w?: number;
  h?: number;
  /** 抖动强度，0 = 规整椭圆 */
  rough?: number;
  seed?: number;
  style?: React.CSSProperties;
}> = ({cx, cy, rx, ry, from = 0, to = 8, color = colors.terracotta, width = 8, w = 1080, h = 1920, rough = 7, seed = 7, style}) => {
  const frame = useCurrentFrame();
  const draw = seg(frame, from, to, (t) => t);
  const fid = `hc${seed}-${Math.round(cx)}-${Math.round(cy)}`;
  const C = Math.PI * 2 * Math.sqrt((rx * rx + ry * ry) / 2);
  return (
    <svg width={w} height={h} style={{position: 'absolute', inset: 0, pointerEvents: 'none', ...style}}>
      <defs>
        <filter id={fid}>
          <feTurbulence type="fractalNoise" baseFrequency="0.02" numOctaves="2" seed={seed} result="n" />
          <feDisplacementMap in="SourceGraphic" in2="n" scale={rough} />
        </filter>
      </defs>
      <ellipse
        cx={cx}
        cy={cy}
        rx={rx}
        ry={ry}
        fill="none"
        stroke={color}
        strokeWidth={width}
        strokeLinecap="round"
        strokeDasharray={C}
        strokeDashoffset={C * (1 - draw)}
        transform={`rotate(-6 ${cx} ${cy})`}
        filter={rough > 0 ? `url(#${fid})` : undefined}
      />
    </svg>
  );
};

/* BlackoutSlam —— 一帧切黑，死寂 12 帧，然后砸入
 *
 * 原卡（drop-blackout-slam）借的是 EDM 的 drop 手法：蓄力**全靠那一段静默**，
 * 屏上完全无物。12 帧是下限，短了读作闪烁不是留白。
 *
 * 砸入帧：主体 scale 1.35→1（5f），同帧整屏震动指数衰减（τ≈2.5f，12f 收干）。
 * 我们去掉了原卡的亮环（那是发光质感，纸面上不成立），改成底色瞬间加深。 */
export const BlackoutSlam: React.FC<{
  /** 黑场之前放什么 */
  before?: React.ReactNode;
  /** 砸进来的主体 */
  children: React.ReactNode;
  blackAt?: number;
  blackFrames?: number;
  black?: string;
  bg?: string;
  /** 震屏峰值像素 */
  shake?: number;
}> = ({before, children, blackAt = 50, blackFrames = 12, black = '#0C0C0C', bg = colors.cream, shake = 10}) => {
  const frame = useCurrentFrame();
  const slam = blackAt + blackFrames;

  if (frame < blackAt) return <AbsoluteFill style={{background: bg}}>{before}</AbsoluteFill>;
  if (frame < slam) return <AbsoluteFill style={{background: black}} />;

  const t = frame - slam;
  const pop = interpolate(t, [0, 5], [1.35, 1], {...CLAMP, easing: Easing.out(Easing.cubic)});
  // 震屏：两个方向各取一条独立衰减正弦，避免读成单轴抖动
  const amp = Math.exp(-t / 2.5) * shake;
  const sx = Math.sin(t * 1.9) * amp;
  const sy = Math.cos(t * 2.3) * amp;

  return (
    <AbsoluteFill style={{background: bg, transform: `translate(${sx}px, ${sy}px)`}}>
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', transform: `scale(${pop})`}}>{children}</AbsoluteFill>
    </AbsoluteFill>
  );
};

/* BeatStepList —— 列表逐拍上移，中央胶囊接住下一个词
 *
 * 原卡（beat-step-list-theme-cycle）的洞察是「三通道锁死同一拍」：
 * 行位移、胶囊颜色、场底色在同一帧一起跳。任何一个通道晚半帧，
 * 整个节奏感就散了——这也是它比普通列表滚动高级的唯一原因。
 *
 * 我们去掉了原卡的换底色（纸面风格不换场），保留行 + 胶囊两通道，
 * 胶囊落位时 squash 弹一下。 */
export const BeatStepList: React.FC<{
  words: string[];
  /** 每拍帧数 */
  beat?: number;
  /** 前置静置帧 */
  delay?: number;
  rowHeight?: number;
  pill?: string;
  /** 选中词颜色 */
  activeColor?: string;
  idleColor?: string;
  pillWidth?: number;
  style?: React.CSSProperties;
}> = ({
  words,
  beat = 18,
  delay = 30,
  rowHeight = 150,
  pill = colors.yellow,
  activeColor = colors.forest,
  idleColor = colors.pencil,
  pillWidth = 820,
  style,
}) => {
  const frame = useCurrentFrame();
  const nBeats = words.length - 1;
  const raw = (frame - delay) / beat;
  const b = Math.min(nBeats, Math.max(0, Math.floor(raw) + 1));
  const beatStart = delay + (b - 1) * beat;
  // 跳变只占拍头 6 帧，剩下的时间是静止——这是「拍」而不是「匀速滚动」的关键
  const tIn = b === 0 ? 1 : seg(frame, beatStart, beatStart + 6, (t) => 1 - Math.pow(1 - t, 3.2));
  const step = b === 0 ? 0 : b - 1 + tIn;
  const pop = b === 0 ? 1 : interpolate(tIn, [0, 0.6, 1], [1.12, 0.97, 1], CLAMP);

  return (
    <div style={{position: 'relative', height: rowHeight * 3, overflow: 'hidden', ...style}}>
      <div
        style={{
          position: 'absolute',
          left: '50%',
          top: rowHeight,
          width: pillWidth,
          height: rowHeight - 20,
          transform: `translateX(-50%) scale(${pop})`,
          background: pill,
          borderRadius: 999,
        }}
      />
      <div style={{position: 'absolute', left: 0, right: 0, top: rowHeight - 10, transform: `translateY(${-step * rowHeight}px)`}}>
        {words.map((w, i) => (
          <div key={w} style={{height: rowHeight, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <span style={{color: i === b ? activeColor : idleColor, position: 'relative', zIndex: 2}}>{w}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

/* SmearGhosts —— 高速位移拖出可数的分身
 *
 * 原卡（smear-multiples）是动画式速度感，不是摄影式运动模糊：
 * 分身**清晰可数**才对，糊成一片就退化成 blur 了。
 *
 * 实现直接吃 motion.ts 里已有的 lagged + velocityAt：
 * 第 k 个分身 = 主体在 frame - k*lag 帧的状态，重新采样而不是累积，并行渲染安全。
 * 速度门控：只有本体够快才渲染分身，慢下来自动摘掉。 */
export const SmearGhosts: React.FC<{
  /** 主体轨迹，必须是帧号的纯函数 */
  posAt: (f: number) => {x: number; y: number};
  children: React.ReactNode;
  ghosts?: number;
  /** 每个分身滞后帧数 */
  lag?: number;
  /** 低于这个速度（px/帧）不出分身 */
  minSpeed?: number;
  maxSpeed?: number;
}> = ({posAt, children, ghosts = 4, lag = 2, minSpeed = 25, maxSpeed = 60}) => {
  const frame = useCurrentFrame();
  const body = posAt(frame);
  const {speed} = velocityAt(posAt, frame);
  const gate = interpolate(speed, [minSpeed, maxSpeed], [0, 1], CLAMP);
  const ops = Array.from({length: ghosts}, (_, i) => 0.45 * Math.pow(0.62, i));

  return (
    <>
      {ops.map((baseOp, i) => {
        const op = baseOp * gate;
        if (op <= 0.002) return null;
        const g = lagged(posAt, frame, (i + 1) * lag);
        return (
          <div key={i} style={{position: 'absolute', left: g.x, top: g.y, opacity: op}}>
            {children}
          </div>
        );
      })}
      <div style={{position: 'absolute', left: body.x, top: body.y}}>{children}</div>
    </>
  );
};

/* ───────── 三、数据与指标 ───────── */

/* OdometerRoll —— 每位独立滚轮，逐位过冲停稳，全锁定时整体脉冲
 *
 * 我们已经有 DigitRoll（第一批），这是它的升级版，三处不同：
 *   ① 逐位错峰停稳（位 i 在 20+i*7 帧才开始减速），不是整体一起停
 *   ② 滚动期叠两个错帧残影，按速度门控，停稳即摘
 *   ③ 全部锁定瞬间整体加深 + 微缩放脉冲 —— 这一下是「钉住」的画面体
 *
 * 用在单个王牌指标的全屏亮相。DigitRoll 留给行内小数字。 */
export const OdometerRoll: React.FC<{
  /** 目标数字串，只有 0-9 会滚，其余字符（%、. 、单位）常驻 */
  value: string;
  delay?: number;
  /** 高速滚动速度，行/帧 */
  spin?: number;
  digitWidth?: number;
  rowHeight?: number;
  color?: string;
  style?: React.CSSProperties;
}> = ({value, delay = 0, spin = 0.85, digitWidth = 126, rowHeight = 210, color = colors.forest, style}) => {
  const frame = useCurrentFrame();
  const chars = Array.from(value);
  const rollable = chars.map((c, i) => ({c, i, isDigit: /[0-9]/.test(c)}));
  const digitIdx: number[] = [];
  rollable.forEach((r) => r.isDigit && digitIdx.push(r.i));

  const lastLock = delay + 20 + (digitIdx.length - 1) * 7 + 22;
  const pulse = interpolate(frame, [lastLock, lastLock + 4, lastLock + 8], [1, 1.035, 1], CLAMP);

  return (
    <div style={{display: 'flex', alignItems: 'flex-end', transform: `scale(${pulse})`, color, ...style}}>
      {rollable.map(({c, i, isDigit}) => {
        if (!isDigit) return <span key={i} style={{whiteSpace: 'pre'}}>{c}</span>;
        const k = digitIdx.indexOf(i);
        const target = Number(c);
        const decelFrom = delay + 20 + k * 7;
        // 位置（单位：行）。减速前恒速滚，减速段 16f 过冲半格，6f 回弹锁定
        let pos: number;
        if (frame < decelFrom) {
          pos = (frame - delay) * spin;
        } else {
          const base = (decelFrom - delay) * spin;
          const land = Math.ceil(base / 10) * 10 + target;
          const over = interpolate(frame, [decelFrom, decelFrom + 16], [base, land + 0.5], {
            ...CLAMP,
            easing: Easing.out(Easing.cubic),
          });
          const back = interpolate(frame, [decelFrom + 16, decelFrom + 22], [land + 0.5, land], {
            ...CLAMP,
            easing: Easing.out(Easing.cubic),
          });
          pos = frame < decelFrom + 16 ? over : back;
        }
        const speed = Math.abs(spin) * (frame < decelFrom ? 1 : 0);
        const ghost = speed > 0.4 ? 1 : 0;
        return (
          <span key={i} style={{display: 'inline-block', width: digitWidth, height: rowHeight, overflow: 'hidden', position: 'relative'}}>
            <span style={{position: 'absolute', left: 0, top: 0, transform: `translateY(${-(pos % 10) * rowHeight}px)`}}>
              {Array.from({length: 21}, (_, d) => (
                <span key={d} style={{display: 'block', height: rowHeight, lineHeight: `${rowHeight}px`, textAlign: 'center', width: digitWidth}}>
                  {d % 10}
                </span>
              ))}
            </span>
            {ghost > 0 && (
              <span style={{position: 'absolute', inset: 0, opacity: 0.22, transform: `translateY(${-rowHeight * 0.5}px)`}}>
                <span style={{display: 'block', height: rowHeight, lineHeight: `${rowHeight}px`, textAlign: 'center'}}>
                  {Math.floor(pos + 1) % 10}
                </span>
              </span>
            )}
          </span>
        );
      })}
    </div>
  );
};

/* CounterBurst —— 数字冲刺计数，到位前一拍纸屑抢拍炸入
 *
 * 原卡（counter-confetti）用 8 色霓虹纸屑，我们换成主题色板的纸片：
 * 矩形、无发光、带自转和重力。纸感风格里彩色亮片是异物。
 *
 * 关键教训（原卡写死的）：纸屑要在数字到位**之前**炸，抢拍才有庆祝感；
 * 数字停稳了才放礼炮，读作马后炮。 */
export const CounterBurst: React.FC<{
  to: number;
  from?: number;
  delay?: number;
  /** 计数到位帧（相对 delay） */
  arrive?: number;
  /** 纸屑片数，超过 60 片开始像雪 */
  bits?: number;
  palette?: string[];
  format?: (n: number) => string;
  style?: React.CSSProperties;
}> = ({
  to,
  from = 0,
  delay = 0,
  arrive = 62,
  bits = 46,
  palette = [colors.yellow, colors.terracotta, colors.mint, colors.teal, colors.blush],
  format = (n) => String(Math.round(n)),
  style,
}) => {
  const frame = useCurrentFrame();
  const t = clamp01((frame - delay) / arrive);
  const q = 1 - Math.pow(1 - t, 4); // easeOutQuart
  const n = from + (to - from) * q;
  // scale 过冲：0.2 → 1.3 → 1
  const s = interpolate(t, [0, 0.55, 0.78, 1], [0.2, 1.3, 1.3, 1], CLAMP);
  // 抢拍：到位前 5 帧起爆
  const burstAt = delay + arrive - 5;
  const bt = Math.max(0, frame - burstAt);

  return (
    <div style={{position: 'relative', ...style}}>
      <div style={{transform: `scale(${s})`, transformOrigin: 'center'}}>{format(n)}</div>
      {bt > 0 &&
        Array.from({length: bits}, (_, i) => {
          const side = i % 2 ? 1 : -1;
          const vx = side * (5 + hash01(i * 3) * 11);
          const vy = -(9 + hash01(i * 7) * 8);
          const x = vx * bt;
          const y = vy * bt + 0.42 * bt * bt; // 重力
          const rot = (hash01(i * 11) - 0.5) * 24 * bt;
          const op = clamp01(1 - bt / 46);
          if (op <= 0.01) return null;
          const w = 8 + hash01(i * 5) * 10;
          return (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: '50%',
                top: '50%',
                width: w,
                height: w * (0.5 + hash01(i * 13)),
                background: palette[i % palette.length],
                opacity: op,
                transform: `translate(${x}px, ${y}px) rotate(${rot}deg)`,
              }}
            />
          );
        })}
    </div>
  );
};

/* HatchBars —— 斜纹占位条伸长，然后换成实心真数据
 *
 * 原卡（hatch-depth）讲的是「从草稿到真实数据」，妙在**几何不跳变**：
 * 条的长度早就到位了，只换纹理和颜色。如果长度也变，观众读到的是
 * 两次动画，隐喻就断了。 */
export const HatchBars: React.FC<{
  rows: {label: string; w: number; value?: string}[];
  delay?: number;
  accent?: string;
  hatch?: string;
  barHeight?: number;
  gap?: number;
  labelWidth?: number;
  trackWidth?: number;
  style?: React.CSSProperties;
}> = ({
  rows,
  delay = 0,
  accent = colors.forest,
  hatch = colors.pencil,
  barHeight = 46,
  gap = 26,
  labelWidth = 240,
  trackWidth = 620,
  style,
}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{display: 'grid', gap, ...style}}>
      {rows.map((r, i) => {
        const grow = seg(frame, delay + i * 7, delay + i * 7 + 20);
        // 全部长完之后才换材质，不能边长边换
        const solid = seg(frame, delay + rows.length * 7 + 24, delay + rows.length * 7 + 40);
        return (
          <div key={r.label} style={{display: 'flex', alignItems: 'center', gap: 20}}>
            <div style={{width: labelWidth, opacity: grow}}>{r.label}</div>
            <div style={{position: 'relative', width: trackWidth, height: barHeight}}>
              <div
                style={{
                  position: 'absolute',
                  left: 0,
                  top: 0,
                  height: barHeight,
                  width: trackWidth * r.w * grow,
                  // 45° 斜纹占位
                  backgroundImage: `repeating-linear-gradient(45deg, ${hatch} 0 6px, transparent 6px 13px)`,
                  opacity: 1 - solid,
                }}
              />
              <div
                style={{
                  position: 'absolute',
                  left: 0,
                  top: 0,
                  height: barHeight,
                  width: trackWidth * r.w * grow,
                  background: accent,
                  opacity: solid,
                }}
              />
            </div>
            {r.value && <div style={{opacity: solid}}>{r.value}</div>}
          </div>
        );
      })}
    </div>
  );
};

/* BeforeAfterWipe —— 分割杆先猛甩后慢扫
 *
 * 原卡（before-after-slider-scrub）的节奏关键是**快慢对比**：
 * 12 帧冲到 76%，然后 48 帧慢慢扫回 40%。匀速扫会读成加载条。
 * 慢扫段才是给观众看清的时间，快甩只是把注意力拽过去。 */
export const BeforeAfterWipe: React.FC<{
  before: React.ReactNode;
  after: React.ReactNode;
  width: number;
  height: number;
  handle?: string;
  delay?: number;
  style?: React.CSSProperties;
}> = ({before, after, width, height, handle = colors.forest, delay = 0, style}) => {
  const frame = useCurrentFrame();
  const f = frame - delay;
  const pct =
    f < 26
      ? interpolate(f, [14, 26], [8, 76], {...CLAMP, easing: Easing.out(Easing.cubic)})
      : f < 38
        ? interpolate(f, [26, 38], [76, 70], {...CLAMP, easing: Easing.out(Easing.cubic)})
        : f < 56
          ? 70
          : interpolate(f, [56, 104], [70, 40], {...CLAMP, easing: Easing.inOut(Easing.quad)});
  const x = (width * pct) / 100;
  return (
    <div style={{position: 'relative', width, height, overflow: 'hidden', ...style}}>
      <div style={{position: 'absolute', inset: 0}}>{before}</div>
      <div style={{position: 'absolute', inset: 0, clipPath: `inset(0 ${100 - pct}% 0 0)`}}>{after}</div>
      <div style={{position: 'absolute', left: x - 2, top: 0, width: 4, height, background: handle}} />
      <div
        style={{
          position: 'absolute',
          left: x - 22,
          top: height / 2 - 22,
          width: 44,
          height: 44,
          borderRadius: 999,
          background: handle,
        }}
      />
    </div>
  );
};

/* SandFillBars —— 柱状图不长高，是方点一颗一颗落下来堆出来的
 *
 * 原卡（particle-sand-fill）讲「积累/汇聚」。堆积高度是**闭式预解析**的
 * ——第 k 层顶面 = 基线 - (k+1)×粒径，没有真碰撞检测，所以每一帧
 * 都能独立算出来，并行渲染安全。
 *
 * 原卡的教训照抄：粒径宁大勿小，4px 在竖版里根本看不见。 */
export const SandFillBars: React.FC<{
  bars: {label: string; grains: number}[];
  delay?: number;
  grain?: number;
  perLayer?: number;
  gapX?: number;
  baseline?: number;
  color?: string;
  /** 各柱错峰启动帧 */
  stagger?: number;
  /** 颗间出发间隔（帧） */
  rate?: number;
  style?: React.CSSProperties;
}> = ({
  bars,
  delay = 0,
  grain = 14,
  perLayer = 9,
  gapX = 60,
  baseline = 620,
  color = colors.forest,
  stagger = 6,
  rate = 0.28,
  style,
}) => {
  const frame = useCurrentFrame();
  const barW = grain * perLayer;
  const GRAV = 1.6;
  const DROP_FROM = 230;
  return (
    <div style={{position: 'relative', ...style}}>
      {bars.map((b, bi) => {
        const x0 = bi * (barW + gapX);
        const start = delay + bi * stagger;
        // 每颗的落点由序号闭式反解：第 k 层顶面 = baseline - (k+1)*grain
        const nodes: React.ReactNode[] = [];
        let done = 0;
        for (let g = 0; g < b.grains; g++) {
          const layer = Math.floor(g / perLayer);
          const col = g % perLayer;
          const landY = baseline - (layer + 1) * grain;
          const launch = start + g * rate + hash01(g * 3.7) * 2;
          const fall = Math.sqrt((2 * DROP_FROM) / GRAV);
          const tt = frame - launch;
          if (tt < 0) continue;
          if (tt >= fall) {
            done++;
            nodes.push(
              <div key={g} style={{position: 'absolute', left: x0 + col * grain, top: landY, width: grain, height: grain, background: color}} />,
            );
          } else {
            const y = landY - DROP_FROM + 0.5 * GRAV * tt * tt;
            nodes.push(
              <div key={g} style={{position: 'absolute', left: x0 + col * grain, top: y, width: grain, height: grain, background: color, opacity: 0.75}} />,
            );
          }
        }
        const finished = done >= b.grains;
        return (
          <div key={b.label}>
            {nodes}
            {finished && (
              <div style={{position: 'absolute', left: x0, top: baseline + 16, width: barW, textAlign: 'center'}}>{b.label}</div>
            )}
          </div>
        );
      })}
    </div>
  );
};

/* ───────── 四、开场与品牌 ───────── */

/* InkOpen —— 墨线准星描画 → 字标逐字压印 → 打字机副标 → 静满一秒 → 上浮消散
 *
 * 原卡（brand-ink-open）有两条硬底线，都是用户返工换来的：
 *   ① 准星画完必须淡出 —— 残留会和字标抢焦点
 *   ② 品牌 hold 必须满 1 秒（30 帧）—— 短于 1s 必返工
 * 还有一条能量曲线的要求：开场必须低起步，炫技会压死后面的爬升。
 *
 * 退场快于入场（7 帧）：观众已经读完了，拖长反而泄气。 */
export const InkOpen: React.FC<{
  wordmark: string;
  kicker?: string;
  accent?: string;
  ink?: string;
  /** 品牌落定后静止帧数，硬底线 30 */
  hold?: number;
  /** 准星尺寸，0 = 不画 */
  crosshair?: number;
  style?: React.CSSProperties;
  kickerStyle?: React.CSSProperties;
}> = ({wordmark, kicker, accent = colors.terracotta, ink = colors.forest, hold = 30, crosshair = 120, style, kickerStyle}) => {
  const frame = useCurrentFrame();
  const chars = Array.from(wordmark);
  const vLine = seg(frame, 0, 9, (t) => t);
  const hLine = seg(frame, 8, 18, (t) => t);
  const crossFade = 1 - seg(frame, 24, 34);
  const lockAt = 10 + chars.length * 3 + 12;
  const outAt = lockAt + hold;
  const out = seg(frame, outAt, outAt + 7);

  return (
    <div
      style={{
        position: 'relative',
        display: 'inline-flex',
        flexDirection: 'column',
        alignItems: 'center',
        opacity: 1 - out,
        transform: `translateY(${-out * 40}px) scale(${1 - out * 0.12})`,
        ...style,
      }}
    >
      {crosshair > 0 && crossFade > 0.01 && (
        <svg width={crosshair} height={crosshair} style={{position: 'absolute', top: -crosshair - 24, opacity: crossFade}}>
          <line x1={crosshair / 2} y1={0} x2={crosshair / 2} y2={crosshair * vLine} stroke={ink} strokeWidth={3} />
          <line x1={0} y1={crosshair / 2} x2={crosshair * hLine} y2={crosshair / 2} stroke={ink} strokeWidth={3} />
        </svg>
      )}
      <div style={{display: 'flex', color: ink}}>
        {chars.map((c, i) => {
          const p = seg(frame, 10 + i * 3, 22 + i * 3);
          return (
            <span
              key={i}
              style={{
                opacity: p,
                // origin center bottom —— 压印是往下压，不是从中心缩
                transform: `scale(${1.6 - 0.6 * p})`,
                transformOrigin: 'center bottom',
                filter: p > 0.995 ? undefined : `blur(${(1 - p) * 6}px)`,
                whiteSpace: 'pre',
              }}
            >
              {c}
            </span>
          );
        })}
      </div>
      {kicker && (
        <div style={{marginTop: 14, color: accent, ...kickerStyle}}>
          {/* 0.7 帧/字符只适用于装饰性小字；正文交互打字要 3 帧/字符 */}
          {kicker.slice(0, Math.max(0, Math.floor((frame - 28) / 0.7)))}
          {frame > 28 && frame < 74 && Math.floor(frame / 2) % 2 === 0 ? '▌' : ''}
        </div>
      )}
    </div>
  );
};

/* StrokeSegments —— 断笔成字：前 70% 读不出，末段落位语义突然成立
 *
 * 原卡（stroke-segment-build）把拉丁字母拆成 16 段手工线段。中文没法这么拆
 * ——笔画数差异太大，一个「一」和一个「囊」没法用同一套段表。
 *
 * 改写方案：不拆笔画，拆**条带**。每个字被水平切成 N 条，按种子乱序逐条揭开。
 * 效果一样成立：前面的条带各自孤立读不出字，最后几条补上瞬间「啪」地可读。
 * 好处是对任何字符都成立，中英混排也不用改。
 *
 * 一支片最多用一次 —— 这是吊悬念的手法，重复即贬值。 */
export const StrokeSegments: React.FC<{
  text: string;
  /** 每个字切几条 */
  bands?: number;
  delay?: number;
  /** 条间隔帧 */
  step?: number;
  /** 单条入场帧数 */
  dur?: number;
  seed?: number;
  style?: React.CSSProperties;
}> = ({text, bands = 8, delay = 14, step = 4, dur = 6, seed = 3, style}) => {
  const frame = useCurrentFrame();
  const chars = Array.from(text);
  const total = chars.length * bands;
  // 乱序表：种子排序，保证同一次渲染每帧一致
  const order = Array.from({length: total}, (_, i) => i).sort((a, b) => hash01(a * 7 + seed) - hash01(b * 7 + seed));
  const rank = new Array(total);
  order.forEach((v, i) => (rank[v] = i));
  const lastLand = delay + (total - 1) * step + dur;
  const pulse = interpolate(frame, [lastLand, lastLand + 4, lastLand + 8], [1, 1.06, 1], CLAMP);

  return (
    <div style={{display: 'flex', transform: `scale(${pulse})`, ...style}}>
      {chars.map((c, ci) => (
        <span key={ci} style={{position: 'relative', display: 'inline-block', whiteSpace: 'pre'}}>
          {/* 占位撑开尺寸，不可见 */}
          <span style={{opacity: 0}}>{c}</span>
          {Array.from({length: bands}, (_, bi) => {
            const id = ci * bands + bi;
            const start = delay + rank[id] * step;
            const p = seg(frame, start, start + dur);
            if (p <= 0.002) return null;
            const top = (bi / bands) * 100;
            const bot = 100 - ((bi + 1) / bands) * 100;
            return (
              <span
                key={bi}
                style={{
                  position: 'absolute',
                  inset: 0,
                  clipPath: `inset(${top}% 0 ${bot}% 0)`,
                  opacity: p,
                  // 沿笔画方向滑入
                  transform: `translateX(${(1 - p) * 12 * (bi % 2 ? 1 : -1)}px)`,
                }}
              >
                {c}
              </span>
            );
          })}
        </span>
      ))}
    </div>
  );
};

/* TextMask —— 超粗大字内部透出画面，结尾字形放大溢出接管全屏
 *
 * 原卡（text-as-mask）的坑写得很清楚：放大原点必须落在**实心笔画内**，
 * 落在字的空隙里会先看到一片空白再看到内容。中文字的重心一般在中偏左，
 * 默认原点给 46%。
 *
 * 内容层用 1/S 反向抵消 mask 的放大，否则里面的画面会跟着一起畸变。 */
export const TextMask: React.FC<{
  text: string;
  children: React.ReactNode;
  width?: number;
  height?: number;
  fontSize?: number;
  fontFamily?: string;
  /** 开始放大溢出的帧，不给就不溢出 */
  breakoutAt?: number;
  breakoutDur?: number;
  origin?: string;
  bg?: string;
}> = ({
  text,
  children,
  width = 1080,
  height = 1080,
  fontSize = 300,
  fontFamily = 'Helvetica, Arial, sans-serif',
  breakoutAt,
  breakoutDur = 30,
  origin = '46% 50%',
  bg = colors.cream,
}) => {
  const frame = useCurrentFrame();
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"><text x="${width / 2}" y="${height / 2 + fontSize * 0.36}" font-family="${fontFamily}" font-size="${fontSize}" font-weight="900" letter-spacing="-4" text-anchor="middle" fill="white">${text}</text></svg>`;
  const url = `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
  const S = breakoutAt === undefined ? 1 : interpolate(frame, [breakoutAt, breakoutAt + breakoutDur], [1, 26], {...CLAMP, easing: Easing.in(Easing.cubic)});
  const takeover = breakoutAt === undefined ? 0 : seg(frame, breakoutAt + breakoutDur * 0.7, breakoutAt + breakoutDur);

  return (
    <div style={{position: 'relative', width, height, overflow: 'hidden', background: bg}}>
      <div
        style={{
          position: 'absolute',
          inset: 0,
          maskImage: url,
          WebkitMaskImage: url,
          maskRepeat: 'no-repeat',
          WebkitMaskRepeat: 'no-repeat',
          transform: `scale(${S})`,
          transformOrigin: origin,
        }}
      >
        {/* 反向抵消，保证内部画面不被 mask 的放大拉变形 */}
        <div style={{position: 'absolute', inset: 0, transform: `scale(${1 / S})`, transformOrigin: origin}}>{children}</div>
      </div>
      {takeover > 0 && <div style={{position: 'absolute', inset: 0, opacity: takeover}}>{children}</div>}
    </div>
  );
};

/* PathDraw —— SVG 路径全字符并行描画，同帧起笔同帧齐收
 *
 * 原卡（letterspace-materialize）v3 的修正很关键：**去掉逐字错峰**。
 * v2 每个字母错开起笔，看着像逐字出现；v3 全字符同一帧起笔，
 * pathLength 归一保证不同长度的笔画同帧收束——出来的是「一起结晶」。
 *
 * 中文没有现成骨架字形，所以做成通用的：吃一组 SVG path，
 * logo、图标、手写签名、简单字形都能用。 */
export const PathDraw: React.FC<{
  paths: string[];
  width: number;
  height: number;
  start?: number;
  dur?: number;
  color?: string;
  strokeWidth?: number;
  style?: React.CSSProperties;
}> = ({paths, width, height, start = 16, dur = 52, color = colors.forest, strokeWidth = 4, style}) => {
  const frame = useCurrentFrame();
  const p = seg(frame, start, start + dur, (t) => t);
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={style}>
      {paths.map((d, i) => (
        <path
          key={i}
          d={d}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeLinejoin="round"
          pathLength={1}
          strokeDasharray={1}
          strokeDashoffset={1 - p}
        />
      ))}
    </svg>
  );
};

/* ───────── 五、收尾 ───────── */

/* GrainCondense —— 整行字砂化成颗粒，再凝聚成更短的字标
 *
 * 原卡（grain-dissolve）用 feTurbulence + feDisplacementMap 双向动画：
 * scale 冲高把字打散，再回落把颗粒收拢。
 *
 * 这个卡跟你的收尾规则天然对上——「长句压缩成一句格言」，
 * 视觉上就是长句爆裂、短句凝聚。 */
export const GrainCondense: React.FC<{
  /** 爆裂的长句 */
  from: string;
  /** 凝聚成的短句 */
  to: string;
  /** 爆裂起始帧 */
  burstAt?: number;
  /** 凝聚完成帧 */
  settleAt?: number;
  color?: string;
  width?: number;
  height?: number;
  fromSize?: number;
  toSize?: number;
  fontFamily?: string;
  seed?: number;
}> = ({
  from,
  to,
  burstAt = 6,
  settleAt = 52,
  color = colors.forest,
  width = 1080,
  height = 400,
  fromSize = 64,
  toSize = 110,
  fontFamily = 'Helvetica, Arial, sans-serif',
  seed = 11,
}) => {
  const frame = useCurrentFrame();
  const mid = (burstAt + settleAt) / 2;
  // 位移量：冲高再归零。峰值 34 是「认不出但还看得见轮廓」的甜点
  const disp = interpolate(frame, [burstAt, mid, settleAt], [0, 34, 0], CLAMP);
  const fromOp = 1 - seg(frame, burstAt, mid);
  const toOp = seg(frame, mid, settleAt);
  const fid = `grain${seed}`;
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      <defs>
        <filter id={fid}>
          {/* seed 逐帧推进 —— 颗粒要「沸腾」，不动就只是一张糊图 */}
          <feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="2" seed={seed + Math.floor(frame)} result="n" />
          <feDisplacementMap in="SourceGraphic" in2="n" scale={disp} />
        </filter>
      </defs>
      <g filter={disp > 0.4 ? `url(#${fid})` : undefined}>
        <text x={width / 2} y={height / 2} textAnchor="middle" dominantBaseline="middle" fontFamily={fontFamily} fontSize={fromSize} fontWeight={700} fill={color} opacity={fromOp}>
          {from}
        </text>
        <text x={width / 2} y={height / 2} textAnchor="middle" dominantBaseline="middle" fontFamily={fontFamily} fontSize={toSize} fontWeight={800} fill={color} opacity={toOp}>
          {to}
        </text>
      </g>
    </svg>
  );
};

/* LockupShrink —— 图标收束落位，字母逐个滑入完成 lockup
 *
 * 原卡（logo-shrink-wordmark-lockup）的顺序不能颠倒：
 * 先把图标收到位并**过冲刹车**，图标才有「停稳了」的读感；
 * 然后它左移让位，字母才一个个进来。同时进行会读成一团乱。 */
export const LockupShrink: React.FC<{
  wordmark: string;
  tagline?: string;
  mark?: React.ReactNode;
  delay?: number;
  accent?: string;
  style?: React.CSSProperties;
  taglineStyle?: React.CSSProperties;
}> = ({wordmark, tagline, mark, delay = 0, accent = colors.terracotta, style, taglineStyle}) => {
  const frame = useCurrentFrame();
  const chars = Array.from(wordmark);
  const shrink = seg(frame, delay, delay + 26, (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2));
  // 过冲刹车的尾巴
  const brake = dampedSettle(frame - (delay + 26), 0.14, 0.28) * 6;
  const shift = seg(frame, delay + 28, delay + 42);
  const tagP = seg(frame, delay + 42 + chars.length * 3 + 10, delay + 60 + chars.length * 3);

  return (
    <div style={{display: 'inline-flex', flexDirection: 'column', alignItems: 'center', ...style}}>
      <div style={{display: 'flex', alignItems: 'center'}}>
        {mark && (
          <div
            style={{
              transform: `scale(${interpolate(shrink, [0, 1], [3.4, 1])}) translateX(${(brake + shift * -12) / Math.max(0.2, shrink)}px)`,
              marginRight: shift * 18,
            }}
          >
            {mark}
          </div>
        )}
        <div style={{display: 'flex'}}>
          {chars.map((c, i) => {
            const p = seg(frame, delay + 42 + i * 3, delay + 54 + i * 3);
            return (
              <span key={i} style={{opacity: p, transform: `translateX(${(1 - p) * 8}px)`, whiteSpace: 'pre'}}>
                {c}
              </span>
            );
          })}
        </div>
      </div>
      {tagline && <div style={{opacity: tagP, color: accent, marginTop: 16, ...taglineStyle}}>{tagline}</div>}
    </div>
  );
};

/* StingButton —— 片尾定住让观众以为结束，突插 12 帧彩蛋，再硬切回来
 *
 * 原卡（logo-sting-button）的节奏就是全部：彩蛋段必须短促得像眨眼。
 * 定住 30 帧是观众「以为结束了」需要的时间，短了这个反转不成立。
 * 12 帧彩蛋 + 收尾真静止 ≥40 帧。 */
export const StingButton: React.FC<{
  /** 定住的字标 */
  children: React.ReactNode;
  /** 12 帧彩蛋 */
  egg: React.ReactNode;
  /** 字标入场帧 */
  logoAt?: number;
  /** 定住帧数 */
  hold?: number;
  /** 彩蛋帧数 */
  eggFrames?: number;
  bg?: string;
}> = ({children, egg, logoAt = 8, hold = 30, eggFrames = 12, bg = colors.cream}) => {
  const frame = useCurrentFrame();
  const inP = seg(frame, logoAt, logoAt + 10);
  const eggStart = logoAt + 10 + hold;
  const inEgg = frame >= eggStart && frame < eggStart + eggFrames;
  if (inEgg) return <AbsoluteFill>{egg}</AbsoluteFill>;
  return (
    <AbsoluteFill style={{background: bg, alignItems: 'center', justifyContent: 'center'}}>
      <div style={{opacity: inP, transform: `scale(${interpolate(inP, [0, 1], [0.94, 1])})`}}>{children}</div>
    </AbsoluteFill>
  );
};

/* GroupPhoto —— 全片元素四方飞来围住字标合影
 *
 * 原卡（outro-group-photo-launch）能量是全片峰值。两条教训直接照抄：
 *   ① 飞入缓动 y1 必须 >1（bezier(0.34,1.4,0.44,1)）—— 旧版没有真过冲，
 *      落地不弹，读成「贴上去」而不是「飞过来」
 *   ② 字标登场时全员必须退后排（opacity −12%），不让位就压不住
 *
 * 原卡还加了舞台光和金尘，纸面风格里不成立，去掉。
 * 结构（四方飞入 + 字标压轴）本身就够，特效是加分不是骨架。 */
export const GroupPhoto: React.FC<{
  /** 参与合影的元素，每个已展示过的功能都该有一个 */
  items: React.ReactNode[];
  /** 字标 */
  wordmark: React.ReactNode;
  width?: number;
  height?: number;
  /** 第一个元素起飞帧 */
  from?: number;
  /** 元素间错开帧 */
  cue?: number;
  /** 字标登场帧 */
  markAt?: number;
  seed?: number;
  style?: React.CSSProperties;
}> = ({items, wordmark, width = 1080, height = 1200, from = 4, cue = 3, markAt = 42, seed = 5, style}) => {
  const frame = useCurrentFrame();
  const demote = seg(frame, markAt, markAt + 8);
  const markP = seg(frame, markAt, markAt + 18);
  // crane：整体落机位，4° 已经够读感，大了会晕
  const crane = seg(frame, 0, 40);
  const rotX = (1 - crane) * 4;
  const scale = interpolate(crane, [0, 1], [1.06, 1]);

  return (
    <div style={{position: 'relative', width, height, perspective: 1400, ...style}}>
      <div style={{position: 'absolute', inset: 0, transform: `rotateX(${rotX}deg) scale(${scale})`}}>
        {items.map((node, i) => {
          const start = from + i * cue;
          const p = seg(frame, start, start + 12, (t) => {
            // 带真过冲的弹入
            const c = 1.4;
            return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2);
          });
          const ang = (i / items.length) * Math.PI * 2 + hash01(i + seed) * 0.7;
          const dist = 360 + hash01(i * 3 + seed) * 140;
          // 合影圈半径按画布走：太小会盖住字标，字标压不住就白做了
          const cx = width / 2 + Math.cos(ang) * width * 0.33;
          const cy = height / 2 + Math.sin(ang) * height * 0.32;
          const rot = (hash01(i * 5 + seed) - 0.5) * 10;
          return (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: cx,
                top: cy,
                // 锚点必须是元素中心，否则元素越宽越往右漂，合影会歪成一边倒
                transform: `translate(-50%, -50%) translate(${Math.cos(ang) * dist * (1 - p)}px, ${Math.sin(ang) * dist * (1 - p)}px) rotate(${rot * p + (1 - p) * rot * 2}deg) scale(${1.12 - 0.12 * p})`,
                opacity: p * (1 - demote * 0.12),
              }}
            >
              {node}
            </div>
          );
        })}
        <div
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: '50%',
            display: 'flex',
            justifyContent: 'center',
            opacity: markP,
            transform: `translateY(-50%) scale(${interpolate(markP, [0, 1], [0.92, 1])})`,
            zIndex: 10,
          }}
        >
          {wordmark}
        </div>
      </div>
    </div>
  );
};
