import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {BracketLabel, DarkStage, MassiveHeadline} from '../style-b/ComponentsB';
import {bColors, bFonts} from '../style-b/themeB';
import {CapsLabelC, SerifHeadlineC, WarmStage} from '../style-c/ComponentsC';
import {cColors, cFonts} from '../style-c/themeC';
import {DigitRoll} from './DigitRoll';
import {ListReveal, MarkerUnderline, StackPress, TextStagger, TitleDemote} from './MotionKit';

/**
 * 同一套 MotionKit 在风格 B 和 C 下的样子。
 *
 * 六个组件的颜色、字体、内容全走 props，没有 import 任何风格库——
 * 换风格只换传进去的 token，动效逻辑一行都不用改。
 */

export const MOTION_KIT_BC_DURATION = 6 * 90;

/* ── 风格 B：深黑底 + 奶油白大字 ───────────────── */

const RowB: React.FC<{children: React.ReactNode; accent?: boolean}> = ({children, accent}) => (
  <div
    style={{
      fontSize: 58,
      fontWeight: 650,
      color: accent ? bColors.orange : bColors.cream,
      borderBottom: `2px solid ${bColors.hairline}`,
      paddingBottom: 12,
    }}
  >
    {children}
  </div>
);

const SlideB: React.FC<{label: string; children: React.ReactNode}> = ({label, children}) => (
  <DarkStage>
    <div style={{position: 'absolute', left: 90, top: 92}}>
      <BracketLabel color={bColors.blue}>{label}</BracketLabel>
    </div>
    <div style={{position: 'absolute', left: 90, top: 320, right: 90}}>{children}</div>
  </DarkStage>
);

const B1 = () => (
  <SlideB label="STYLE B / DigitRoll">
    <DigitRoll value={11} delay={6} duration={26} stagger={5} fontSize={240} color={bColors.green} fontFamily={bFonts.main} />
    <div style={{marginTop: 30, fontSize: 28, color: bColors.orange}}>同一个组件，只换了 color 和 fontFamily</div>
  </SlideB>
);

const B2 = () => (
  <SlideB label="STYLE B / StackPress">
    <StackPress
      delay={8}
      step={9}
      items={['选题定', '人群定', '角度定', '结构定', '标题定'].map((t, i) => (
        <RowB key={t} accent={i === 1}>{t}</RowB>
      ))}
    />
  </SlideB>
);

const B3 = () => (
  <SlideB label="STYLE B / MarkerUnderline">
    <MassiveHeadline size={92}>连接才是重点</MassiveHeadline>
    <MarkerUnderline width={520} delay={22} duration={10} color={bColors.green} style={{marginTop: 6}} />
    <div style={{marginTop: 40, fontSize: 27, color: bColors.orange}}>笔触颜色改成品牌绿</div>
  </SlideB>
);

/* ── 风格 C：奶油底 + 蓝黄橙 ─────────────────── */

const RowC: React.FC<{children: React.ReactNode; accent?: boolean}> = ({children, accent}) => (
  <div
    style={{
      fontSize: 58,
      fontWeight: 650,
      color: accent ? cColors.orange : cColors.ink,
      borderBottom: `2px solid ${cColors.creamDeep}`,
      paddingBottom: 12,
    }}
  >
    {children}
  </div>
);

const SlideC: React.FC<{label: string; children: React.ReactNode}> = ({label, children}) => (
  <WarmStage>
    <div style={{position: 'absolute', left: 90, top: 92}}>
      <CapsLabelC>{label}</CapsLabelC>
    </div>
    <div style={{position: 'absolute', left: 90, top: 320, right: 90}}>{children}</div>
  </WarmStage>
);

const C1 = () => (
  <SlideC label="STYLE C / ListReveal">
    <ListReveal
      delay={8}
      step={13}
      items={['状态不靠追问', '方法不靠记忆', '结果能够回流'].map((t, i) => (
        <RowC key={t} accent={i === 2}>{t}</RowC>
      ))}
    />
  </SlideC>
);

const C2 = () => (
  <SlideC label="STYLE C / TextStagger">
    <div style={{fontFamily: cFonts.body, fontSize: 84, fontWeight: 800, color: cColors.ink}}>
      <TextStagger text="每条都要重来一遍" delay={8} within={26} />
    </div>
    <div style={{marginTop: 40, fontSize: 27, color: cColors.orange}}>逐字入场，字数多自动收紧</div>
  </SlideC>
);

const C3 = () => {
  const frame = useCurrentFrame();
  return (
    <WarmStage>
      <TitleDemote
        hold={38}
        duration={24}
        from={88}
        to={26}
        origin={{left: 90, top: 320}}
        target={{left: 90, top: 92}}
        style={{fontFamily: cFonts.body, fontWeight: 800, color: cColors.ink}}
      >
        四层之间只有三条关系
      </TitleDemote>
      <div
        style={{
          position: 'absolute',
          left: 90,
          top: 200,
          right: 90,
          opacity: Math.min(1, Math.max(0, (frame - 60) / 16)),
        }}
      >
        <RowC>页面 · 把状态显示给人</RowC>
        <div style={{height: 18}} />
        <RowC accent>数据 · 存放全部状态</RowC>
      </div>
      <div style={{position: 'absolute', left: 90, bottom: 300, fontSize: 27, color: cColors.orange}}>
        标题降格成角标，B/C 表现一致
      </div>
    </WarmStage>
  );
};

const slides = [B1, B2, B3, C1, C2, C3];

export const MotionKitDemoBC: React.FC = () => (
  <AbsoluteFill style={{background: bColors.black}}>
    {slides.map((C, i) => (
      <Sequence key={i} from={i * 90} durationInFrames={90}>
        <C />
      </Sequence>
    ))}
  </AbsoluteFill>
);
