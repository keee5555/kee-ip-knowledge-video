/**
 * 动效数学工具。
 *
 * 三个函数移植自 video-shotcraft（Apache License 2.0）
 * https://github.com/Vincentwei1021/video-shotcraft
 * assets/lib/helpers/motion.ts
 *
 * 只拿了纯数学部分——它们与视觉风格完全解耦，A/B/C 三套风格都能用。
 *
 * 2026-08-10 修订：原来这里写着「其余 106 张都是横屏产品语法，没有引入」。
 * 前半句仍然成立，后半句已经不成立了——横屏的是**视觉**，时序和缓动
 * 与画幅无关。第二批已按这个口径收编 22 张，见 MotionKit.tsx。
 * 排除标准改成「是否需要真实产品页面截图」：ui-entrance / interaction /
 * camera 三类共 52 张仍然不引入，它们的前提是有网页可截。
 *
 * ─────────────────────────────────────────────
 * 核心约束（来自原作者，我们照单接受）：
 *
 *   Never accumulate state across rendered frames —
 *   every layer stays a pure function of the frame number.
 *
 * Remotion 是逐帧独立渲染的，渲染时多帧可能并行。任何跨帧累积的状态
 * 都会在并行渲染下出错。所有动效必须写成「给定帧号 → 算出该帧状态」
 * 的纯函数，不能依赖上一帧的结果。
 * ─────────────────────────────────────────────
 */

/**
 * 对任意纯轨迹函数做中心差分，得到该帧的速度、速率和朝向。
 *
 * 用途：用 speed 驱动拉伸、拖影、模糊或抖动强度——动得快的时候形变大，
 * 停下来自动归位，不需要手写关键帧。振幅记得按主体尺寸归一化。
 */
export const velocityAt = (
  posAt: (f: number) => {x: number; y: number},
  frame: number,
  dt = 0.5,
): {vx: number; vy: number; speed: number; direction: number} => {
  const before = posAt(frame - dt);
  const after = posAt(frame + dt);
  const vx = (after.x - before.x) / (2 * dt);
  const vy = (after.y - before.y) / (2 * dt);
  return {vx, vy, speed: Math.hypot(vx, vy), direction: Math.atan2(vy, vx)};
};

/**
 * 跟随层 = 主体状态延后 N 帧采样。
 *
 * 想做多层拖尾就给每层不同的延迟和递减的振幅（影子 2 帧、残像 4 帧……）。
 * 因为是重新采样而不是累积状态，并行渲染安全。
 */
export const lagged = <T>(
  stateAt: (f: number) => T,
  frame: number,
  delayFrames: number,
): T => stateAt(frame - delayFrames);

/**
 * 闭式阻尼振荡，用于回弹和落定的尾巴。
 *
 * t 是从冲击点起算的帧数，返回衰减到 0 的有符号偏移系数，乘上目标峰值振幅即可。
 * freq 单位是「周期/帧」（约 0.1），damping 是每帧衰减（约 0.15）。
 *
 * 和 Remotion 的 spring 的区别：spring 是从 0 到 1 的入场曲线，
 * 这个是绕着终点来回摆的落定曲线，适合「砸下去再弹两下」。
 */
export const dampedSettle = (t: number, freq: number, damping: number): number =>
  t <= 0 ? 0 : Math.exp(-damping * t) * Math.sin(2 * Math.PI * freq * t);
