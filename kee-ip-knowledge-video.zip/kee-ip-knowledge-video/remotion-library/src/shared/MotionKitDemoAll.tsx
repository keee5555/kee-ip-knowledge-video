import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {BracketLabel, DarkStage} from '../style-b/ComponentsB';
import {MicroLabel, PaperStage} from '../components/EditorialComponents';
import {bColors} from '../style-b/themeB';
import {CapsLabelC, WarmStage} from '../style-c/ComponentsC';
import {cColors} from '../style-c/themeC';
import {colors} from '../theme';
import {
  SKIN_A as TOKENS_A,
  SKIN_B as TOKENS_B,
  SKIN_C as TOKENS_C,
  type Skin as SkinTokens,
} from './skins';
import {
  BeatStepList,
  BeforeAfterWipe,
  BlackoutSlam,
  BlurSlide,
  CounterBurst,
  GrainCondense,
  GroupPhoto,
  HandCircle,
  HatchBars,
  InkOpen,
  KaraokeFill,
  LockupShrink,
  OdometerRoll,
  PaperTitleCard,
  PathDraw,
  PillSlotCycle,
  SandFillBars,
  SmearGhosts,
  StingButton,
  StrokeSegments,
  TextMask,
  WordRelay,
  useFreezeRemap,
} from './MotionKit';

/**
 * 第二批 22 个动效的验收片，A / B / C 三套风格连着跑一遍。
 *
 * 22 张 slide **只写了一份**，用 skin 对象参数化——这本身就是测试：
 * 如果某个组件藏着风格假设，它在别的皮肤下会直接崩样，不需要靠眼力找。
 *
 * 2026-08-11 合并：原来风格 A 单独有一个 MotionKitDemo2.tsx，把同样 22 张
 * slide 又手写了一遍（442 行）。两份定义改一处要同步两次，漏改的地方
 * 正好是会藏 bug 的地方。现在 A 并进来当第三张皮，Demo2 已删。
 */

const SLIDE = 72;

/**
 * 颜色令牌全部来自 shared/skins.ts —— 这里只补 demo 自己要用的舞台和标签
 * 这两个组件。令牌不在这里定义，否则「契约」会有两份。
 */
type Skin = SkinTokens & {
  Stage: React.FC<{children: React.ReactNode}>;
  Label: React.FC<{children: React.ReactNode}>;
};

const SKIN_A: Skin = {
  ...TOKENS_A,
  Stage: PaperStage,
  Label: ({children}) => <MicroLabel>{children}</MicroLabel>,
};

const SKIN_B: Skin = {
  ...TOKENS_B,
  Stage: DarkStage,
  Label: ({children}) => <BracketLabel color={bColors.blue}>{children}</BracketLabel>,
};

const SKIN_C: Skin = {
  ...TOKENS_C,
  Stage: WarmStage,
  Label: ({children}) => <CapsLabelC color={cColors.blue}>{children}</CapsLabelC>,
};

const Slide: React.FC<{skin: Skin; label: string; children: React.ReactNode}> = ({skin, label, children}) => (
  <skin.Stage>
    <div style={{position: 'absolute', left: 90, top: 92}}>
      <skin.Label>{label}</skin.Label>
    </div>
    <div style={{position: 'absolute', left: 90, top: 300, right: 90}}>{children}</div>
  </skin.Stage>
);

const h = (s: Skin): React.CSSProperties => ({fontSize: 68, fontWeight: 700, color: s.ink, fontFamily: s.display, lineHeight: 1.3});
const note = (s: Skin): React.CSSProperties => ({marginTop: 36, fontFamily: s.mono, fontSize: 25, color: s.accent2});

/** 22 张 slide 的唯一定义。换风格只换 skin。 */
const build = (s: Skin): React.FC[] => [
  () => (
    <Slide skin={s} label={`${s.key} 01 / BlurSlide`}>
      <BlurSlide words={['爆款', '不是', '写出来的', '是', '数出来的']} style={h(s)} />
      <div style={note(s)}>三通道同缓动</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 02 / PaperTitleCard`}>
      <PaperTitleCard words={['三十一篇', '逐字稿', '喂出来的', '判断']} accentAt={2} accent={s.accent} style={h(s)} />
      <div style={note(s)}>压印 + 一个强调词</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 03 / PillSlotCycle`}>
      <PillSlotCycle
        prefix="AI 帮你"
        pills={['写稿', '配音', '分镜']}
        settle="跑完整条产线"
        beat={12}
        pillBg={s.surface}
        pillColor={s.onSurface}
        style={{...h(s), fontSize: 56}}
      />
      <div style={note(s)}>句干钉死不动</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 04 / WordRelay`}>
      <WordRelay
        fixed="这套产线"
        words={['自己写稿', '自己配音', '自己出片']}
        switches={[6, 28, 50]}
        fadeColor={s.muted}
        style={h(s)}
        wordStyle={{height: 96, color: s.accent}}
      />
      <div style={note(s)}>动词原位接力</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 05 / KaraokeFill`}>
      <KaraokeFill
        words={[
          {text: '越长', start: 6, end: 18},
          {text: '越爆', start: 20, end: 32},
          {text: '拐点', start: 34, end: 46},
          {text: '一百八十秒', start: 48, end: 64},
        ]}
        read={s.ink}
        unread={s.muted}
        style={h(s)}
      />
      <div style={note(s)}>绑 CosyVoice 时间轴</div>
    </Slide>
  ),
  () => {
    const src = useFreezeRemap([0, 20, 48, 72], [0, 20, 20, 52]);
    return (
      <Slide skin={s} label={`${s.key} 06 / FreezeRemap`}>
        <div style={{position: 'relative', height: 400, overflow: 'hidden'}}>
          {Array.from({length: 8}, (_, i) => (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: 560 + i * 300 - src * 25,
                top: 30,
                width: 260,
                height: 310,
                border: `3px solid ${s.muted}`,
                background: i === 3 ? s.surface : 'transparent',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 40,
                color: i === 3 ? s.onSurface : s.ink,
                fontFamily: s.display,
              }}
            >
              {i + 1}
            </div>
          ))}
          <HandCircle cx={450} cy={185} rx={168} ry={188} from={26} to={36} w={900} h={400} color={s.accent} rough={s.rough} />
        </div>
        <div style={note(s)}>斜率 0 的平台 = 定格</div>
      </Slide>
    );
  },
  () => (
    <Sequence durationInFrames={SLIDE}>
      <BlackoutSlam
        blackAt={22}
        blackFrames={12}
        bg={s.bg}
        before={<div style={{position: 'absolute', left: 90, top: 300, ...h(s)}}>先放着让人以为还在讲…</div>}
      >
        <div style={{fontSize: 130, fontWeight: 800, color: s.accent, fontFamily: s.display}}>都错了</div>
      </BlackoutSlam>
      <div style={{position: 'absolute', left: 90, top: 92}}>
        <s.Label>{`${s.key} 07 / BlackoutSlam`}</s.Label>
      </div>
    </Sequence>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 08 / BeatStepList`}>
      <BeatStepList
        words={['具体', '反直觉', '有数据', '能落地']}
        beat={14}
        delay={8}
        rowHeight={125}
        pill={s.surface}
        activeColor={s.onSurface}
        idleColor={s.muted}
        style={{fontSize: 58, fontWeight: 700, fontFamily: s.display}}
      />
      <div style={note(s)}>行 + 胶囊同拍跳变</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 09 / SmearGhosts`}>
      <div style={{position: 'relative', height: 400}}>
        <SmearGhosts posAt={(f) => ({x: f < 36 ? Math.max(0, (f - 14) * 28) : 616, y: 110})} lag={2}>
          <div style={{width: 260, height: 180, background: s.surface, border: `3px solid ${s.ink}`}} />
        </SmearGhosts>
      </div>
      <div style={note(s)}>分身清晰可数 · 速度门控</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 10 / OdometerRoll`}>
      <OdometerRoll value="3243" delay={2} digitWidth={106} rowHeight={148} color={s.ink} style={{fontSize: 128, fontWeight: 800, fontFamily: s.display}} />
      <div style={note(s)}>逐位错峰停稳</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 11 / CounterBurst`}>
      <div style={{fontSize: 148, fontWeight: 800, color: s.ink, fontFamily: s.display}}>
        <CounterBurst to={31} delay={4} arrive={42} bits={40} palette={s.palette} />
      </div>
      <div style={note(s)}>纸屑抢在到位前 5 帧炸</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 12 / HatchBars`}>
      <HatchBars
        rows={[
          {label: '爆款', w: 0.95, value: '77'},
          {label: '中位', w: 0.58, value: '48'},
          {label: '平款', w: 0.36, value: '29'},
        ]}
        delay={4}
        accent={s.accent}
        hatch={s.muted}
        labelWidth={160}
        trackWidth={500}
        style={{fontSize: 34, fontFamily: s.mono, color: s.ink}}
      />
      <div style={note(s)}>几何不跳变，只换纹理</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 13 / BeforeAfterWipe`}>
      <BeforeAfterWipe
        width={900}
        height={400}
        delay={-24}
        handle={s.ink}
        before={
          <div style={{width: '100%', height: '100%', background: s.muted, display: 'flex', alignItems: 'center', justifyContent: 'flex-end', paddingRight: 50, boxSizing: 'border-box', fontSize: 48, color: s.bg, fontFamily: s.display}}>
            手搓 4 小时
          </div>
        }
        after={
          <div style={{width: '100%', height: '100%', background: s.surface, display: 'flex', alignItems: 'center', justifyContent: 'flex-start', paddingLeft: 50, boxSizing: 'border-box', fontSize: 48, color: s.onSurface, fontFamily: s.display}}>
            产线 11 分钟
          </div>
        }
      />
      <div style={note(s)}>快甩 → 慢扫</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 14 / SandFillBars`}>
      <div style={{position: 'relative', height: 440}}>
        <SandFillBars
          bars={[
            {label: '爆款', grains: 84},
            {label: '中位', grains: 49},
            {label: '平款', grains: 28},
          ]}
          delay={2}
          grain={16}
          perLayer={7}
          gapX={110}
          baseline={370}
          rate={0.16}
          color={s.accent}
          style={{fontSize: 27, fontFamily: s.mono, color: s.ink}}
        />
      </div>
      <div style={note(s)}>堆积高度闭式预解析</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 15 / InkOpen`}>
      <div style={{marginTop: 110, display: 'flex', justifyContent: 'center'}}>
        <InkOpen
          wordmark="使用者"
          kicker="内容生产系统"
          hold={22}
          ink={s.ink}
          accent={s.accent}
          style={{fontSize: 100, fontWeight: 700, fontFamily: s.display}}
          kickerStyle={{fontSize: 28, fontFamily: s.mono}}
        />
      </div>
      <div style={note(s)}>hold 满 22 帧再退场</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 16 / StrokeSegments`}>
      <StrokeSegments text="数出来的" bands={6} delay={4} step={2} style={{fontSize: 120, fontWeight: 800, color: s.ink, fontFamily: s.display}} />
      <div style={note(s)}>中文改切条带</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 17 / TextMask`}>
      <TextMask text="产线" width={900} height={400} fontSize={270} breakoutAt={50} breakoutDur={18} bg={s.bg}>
        <div style={{width: '100%', height: '100%', background: `repeating-linear-gradient(45deg, ${s.accent} 0 22px, ${s.surface} 22px 44px)`}} />
      </TextMask>
      <div style={note(s)}>原点必须在实心笔画内</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 18 / PathDraw`}>
      <PathDraw
        paths={[
          'M 450 60 C 596 60, 700 164, 700 210 C 700 316, 596 360, 450 360 C 304 360, 200 316, 200 210 C 200 104, 304 60, 450 60 Z',
          'M 340 210 L 420 285 L 570 140',
        ]}
        width={900}
        height={420}
        start={6}
        dur={40}
        color={s.accent}
        strokeWidth={12}
      />
      <div style={note(s)}>同帧起笔同帧齐收</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 19 / GrainCondense`}>
      <div style={{marginTop: 70}}>
        <GrainCondense
          from="数据不会告诉你该做什么"
          to="但会告诉你别做什么"
          burstAt={6}
          settleAt={52}
          width={900}
          height={320}
          fromSize={44}
          toSize={54}
          color={s.ink}
          fontFamily={s.display}
        />
      </div>
      <div style={note(s)}>长句爆裂 → 短句凝聚</div>
    </Slide>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 20 / LockupShrink`}>
      <div style={{marginTop: 90, display: 'flex', justifyContent: 'center'}}>
        <LockupShrink
          wordmark="使用者"
          tagline="把内容做成产线"
          accent={s.accent}
          mark={<div style={{width: 54, height: 54, borderRadius: 999, background: s.accent}} />}
          style={{fontSize: 90, fontWeight: 800, color: s.ink, fontFamily: s.display}}
          taglineStyle={{fontSize: 28, fontFamily: s.mono}}
        />
      </div>
      <div style={note(s)}>图标先刹车，字母才进</div>
    </Slide>
  ),
  () => (
    <Sequence durationInFrames={SLIDE}>
      <StingButton
        logoAt={4}
        hold={24}
        eggFrames={12}
        bg={s.bg}
        egg={
          <AbsoluteFill style={{background: s.accent, alignItems: 'center', justifyContent: 'center'}}>
            <div style={{fontSize: 72, color: s.bg, fontFamily: s.display}}>还有一件事</div>
          </AbsoluteFill>
        }
      >
        <div style={{fontSize: 100, fontWeight: 800, color: s.ink, fontFamily: s.display}}>使用者 AI Lab</div>
      </StingButton>
      <div style={{position: 'absolute', left: 90, top: 92}}>
        <s.Label>{`${s.key} 21 / StingButton`}</s.Label>
      </div>
    </Sequence>
  ),
  () => (
    <Slide skin={s} label={`${s.key} 22 / GroupPhoto`}>
      <GroupPhoto
        width={900}
        height={760}
        from={2}
        cue={3}
        markAt={36}
        items={['选题', '素材', '口播稿', '分镜', '配音', '字幕', '动效', '成片'].map((t) => (
          <div
            key={t}
            style={{
              padding: '12px 24px',
              background: s.bg,
              border: `3px solid ${s.ink}`,
              fontSize: 28,
              color: s.ink,
              fontFamily: s.mono,
              whiteSpace: 'nowrap',
            }}
          >
            {t}
          </div>
        ))}
        wordmark={<div style={{fontSize: 82, fontWeight: 800, color: s.accent, fontFamily: s.display}}>使用者 AI Lab</div>}
      />
    </Slide>
  ),
];

const ALL = [...build(SKIN_A), ...build(SKIN_B), ...build(SKIN_C)];
export const MOTION_KIT_DEMO_ALL_DURATION = SLIDE * ALL.length;

export const MotionKitDemoAll: React.FC = () => (
  <AbsoluteFill style={{background: colors.cream}}>
    {ALL.map((C, i) => (
      <Sequence key={i} from={i * SLIDE} durationInFrames={SLIDE}>
        <C />
      </Sequence>
    ))}
  </AbsoluteFill>
);
