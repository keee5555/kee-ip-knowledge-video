import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Img,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
} from 'remotion';
import {SafeCaption} from '../shared/SafeCaption';
import {TEXT_WRAP} from '../layout';
import {BRAND_CONTENT_HEIGHT, BRAND_CONTENT_WIDTH, BRAND_LAYOUT} from './brandLayout';
import type {BrandMediaCue, BrandStageProps, BrandTheme, MediaMotion} from './types';

/**
 * 临时色值只用于组件开发。拿到 Logo 后必须取样替换并把 needsLogoSampling 改为 false，
 * 否则 suyan-brand-video 的正式渲染闸门不得放行。
 */
export const SUYAN_THEME_PLACEHOLDER: BrandTheme = {
  background: '#F7F5F1',
  surface: '#FFFFFF',
  ink: '#161616',
  muted: '#6D6D6D',
  red: '#D8263F',
  green: '#2A9A72',
  blue: '#2C70C9',
  needsLogoSampling: true,
};

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const motionTransform = (frame: number, duration: number, motion: MediaMotion) => {
  const p = interpolate(frame, [0, Math.max(1, duration - 1)], [0, 1], clamp);
  if (motion === 'push-in') return `scale(${1 + p * 0.075})`;
  if (motion === 'pan-left') return `scale(1.08) translateX(${-p * 4}%)`;
  if (motion === 'pan-right') return `scale(1.08) translateX(${p * 4 - 4}%)`;
  return 'scale(1)';
};

const MediaCard: React.FC<{cue: BrandMediaCue; theme: BrandTheme}> = ({cue, theme}) => {
  const frame = useCurrentFrame();
  const duration = Math.max(1, cue.to - cue.from);
  const fade = interpolate(frame, [0, 8, Math.max(9, duration - 8), duration], [0, 1, 1, 0], clamp);
  const isIllustration = cue.truth === 'illustration';
  const label = cue.label ?? (isIllustration ? '业务示意' : undefined);

  return (
    <div
      data-media-id={cue.id}
      data-narration-anchor={cue.narrationAnchor}
      data-truth={cue.truth}
      style={{
        position: 'absolute',
        left: cue.x ?? BRAND_LAYOUT.contentLeft,
        top: cue.y ?? BRAND_LAYOUT.contentTop,
        width: cue.width ?? BRAND_CONTENT_WIDTH,
        height: cue.height ?? BRAND_CONTENT_HEIGHT,
        overflow: 'hidden',
        borderRadius: BRAND_LAYOUT.mediaRadius,
        border: `${BRAND_LAYOUT.mediaBorder}px solid rgba(22,22,22,0.12)`,
        background: theme.surface,
        boxShadow: '0 28px 80px rgba(20,20,20,0.18)',
        opacity: fade,
      }}
    >
      <Img
        src={staticFile(cue.assetPath)}
        style={{
          width: '100%',
          height: '100%',
          objectFit: cue.fit,
          objectPosition: `${cue.focalX ?? 50}% ${cue.focalY ?? 50}%`,
          transform: motionTransform(frame, duration, cue.motion ?? 'push-in'),
        }}
      />
      {(cue.dim ?? 0) > 0 ? (
        <AbsoluteFill style={{background: `rgba(0,0,0,${cue.dim})`}} />
      ) : null}
      {label ? (
        <div
          style={{
            position: 'absolute',
            right: BRAND_LAYOUT.evidenceLabelInset,
            bottom: BRAND_LAYOUT.evidenceLabelInset,
            padding: '8px 14px',
            borderRadius: 999,
            background: isIllustration ? 'rgba(22,22,22,0.78)' : 'rgba(255,255,255,0.9)',
            color: isIllustration ? '#FFFFFF' : theme.ink,
            fontFamily: '"Noto Sans SC Variable", "PingFang SC", sans-serif',
            fontSize: 24,
            fontWeight: 700,
          }}
        >
          {label}
        </div>
      ) : null}
    </div>
  );
};

export const BrandMediaTrack: React.FC<{cues: BrandMediaCue[]; theme: BrandTheme}> = ({cues, theme}) => (
  <>
    {cues.map((cue) => (
      <Sequence key={cue.id} from={cue.from} durationInFrames={Math.max(1, cue.to - cue.from)}>
        <MediaCard cue={cue} theme={theme} />
      </Sequence>
    ))}
  </>
);

export const BrandBackdrop: React.FC<{theme: BrandTheme}> = ({theme}) => (
  <AbsoluteFill
    style={{
      background: `
        radial-gradient(circle at 18% 28%, ${theme.green}20 0, transparent 30%),
        radial-gradient(circle at 86% 42%, ${theme.blue}1C 0, transparent 34%),
        linear-gradient(155deg, ${theme.background} 0%, #FFFFFF 52%, ${theme.red}0F 100%)
      `,
    }}
  >
    <AbsoluteFill
      style={{
        opacity: 0.16,
        backgroundImage:
          'linear-gradient(rgba(22,22,22,.16) 1px, transparent 1px), linear-gradient(90deg, rgba(22,22,22,.16) 1px, transparent 1px)',
        backgroundSize: '72px 72px',
        maskImage: 'linear-gradient(to bottom, transparent, black 28%, black 72%, transparent)',
      }}
    />
  </AbsoluteFill>
);

export const BrandStage: React.FC<BrandStageProps> = ({theme, media, captions, audioPath, children}) => (
  <AbsoluteFill style={{background: theme.background, color: theme.ink}}>
    <BrandBackdrop theme={theme} />
    {audioPath ? <Audio src={staticFile(audioPath)} /> : null}
    <BrandMediaTrack cues={media} theme={theme} />
    {children}
    <SafeCaption cues={captions} />
  </AbsoluteFill>
);

export const BusinessThread: React.FC<{
  theme: BrandTheme;
  active: 0 | 1 | 2;
  labels?: [string, string, string];
}> = ({theme, active, labels = ['文旅', '数字运营', 'AIGC']}) => {
  const colors = [theme.green, theme.blue, theme.red];
  return (
    <div
      style={{
        position: 'absolute',
        top: BRAND_LAYOUT.businessRailY,
        left: BRAND_LAYOUT.contentLeft,
        right: BRAND_LAYOUT.contentRight,
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: 12,
      }}
    >
      {labels.map((label, index) => (
        <div
          key={label}
          style={{
            height: 58,
            borderRadius: 999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: index === active ? colors[index] : 'rgba(255,255,255,0.82)',
            color: index === active ? '#FFFFFF' : theme.muted,
            border: `2px solid ${index === active ? colors[index] : 'rgba(22,22,22,0.12)'}`,
            fontFamily: '"Noto Sans SC Variable", "PingFang SC", sans-serif',
            fontSize: 28,
            fontWeight: 800,
          }}
        >
          {label}
        </div>
      ))}
    </div>
  );
};

export const DataHero: React.FC<{
  value: string;
  label: string;
  color: string;
  source?: string;
}> = ({value, label, color, source}) => {
  const frame = useCurrentFrame();
  const enter = interpolate(frame, [0, 16], [0.88, 1], clamp);
  const opacity = interpolate(frame, [0, 10], [0, 1], clamp);
  return (
    <div
      style={{
        position: 'absolute',
        left: BRAND_LAYOUT.contentLeft,
        right: BRAND_LAYOUT.contentRight,
        top: BRAND_LAYOUT.contentTop + 260,
        textAlign: 'center',
        opacity,
        transform: `scale(${enter})`,
        fontFamily: '"Noto Sans SC Variable", "PingFang SC", sans-serif',
      }}
    >
      <div style={{fontSize: 156, fontWeight: 950, lineHeight: 1, color, letterSpacing: -8}}>{value}</div>
      <div style={{marginTop: 24, fontSize: 42, fontWeight: 850, textWrap: TEXT_WRAP.balance}}>{label}</div>
      {source ? <div style={{marginTop: 18, fontSize: 24, color: '#6D6D6D'}}>{source}</div> : null}
    </div>
  );
};
