import {SCENE_CONTENT_MAX_Y, SCENE_CONTENT_MIN_Y} from '../layout';

export const BRAND_LAYOUT = {
  contentTop: SCENE_CONTENT_MIN_Y,
  contentBottom: SCENE_CONTENT_MAX_Y,
  contentLeft: 72,
  contentRight: 72,
  mediaRadius: 34,
  mediaBorder: 2,
  evidenceLabelInset: 18,
  businessRailY: SCENE_CONTENT_MIN_Y + 74,
} as const;

export const BRAND_CONTENT_HEIGHT = BRAND_LAYOUT.contentBottom - BRAND_LAYOUT.contentTop;
export const BRAND_CONTENT_WIDTH = 1080 - BRAND_LAYOUT.contentLeft - BRAND_LAYOUT.contentRight;
