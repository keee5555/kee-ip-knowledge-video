import type {CaptionCue} from '../shared/SafeCaption';
import type {ReactNode} from 'react';

export type BrandTheme = {
  background: string;
  surface: string;
  ink: string;
  muted: string;
  red: string;
  green: string;
  blue: string;
  needsLogoSampling: boolean;
};

export type MediaTruth = 'brand' | 'evidence' | 'photo' | 'case' | 'illustration';
export type MediaFit = 'contain' | 'cover';
export type MediaMotion = 'still' | 'push-in' | 'pan-left' | 'pan-right';

export type BrandMediaCue = {
  id: string;
  /** 对应口播原文短句，用来审计素材是否放在正确语义位置。 */
  narrationAnchor: string;
  from: number;
  to: number;
  /** 相对于 Remotion public/ 的路径。 */
  assetPath: string;
  truth: MediaTruth;
  fit: MediaFit;
  motion?: MediaMotion;
  focalX?: number;
  focalY?: number;
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  label?: string;
  dim?: number;
};

export type BrandStageProps = {
  theme: BrandTheme;
  media: BrandMediaCue[];
  captions: CaptionCue[];
  audioPath?: string;
  children?: ReactNode;
};
