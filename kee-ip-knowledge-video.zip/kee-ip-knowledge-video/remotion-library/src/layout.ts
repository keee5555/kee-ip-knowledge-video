/**
 * 布局契约 — 唯一来源。
 *
 * 生产文件和组件库禁止再出现裸的 top / bottom 数字。
 * 任何一处布局值要改，只改这里。
 *
 * 背景：2026-08-04 之前字幕位散在四处且互不相认——
 * 风格A PlainCaption bottom:80、风格B CreamCaption bottom:72、
 * 风格C 没有字幕组件、生产文件内联 CaptionB bottom:190，
 * 导致场景底部文字被字幕压掉且反复返工。
 */

export const CANVAS = {
  width: 1080,
  height: 1920,
  fps: 30,
} as const;

/**
 * 视频号安全区：
 * - 顶部发布后会叠加返回、倍速、搜索等播放控件；实机截图确认 150px 不够，
 *   标题会被直接遮挡，因此主内容统一从 360px 以下开始。
 * - 底部有账号栏和按钮，字幕不得低于 bottom 安全线。
 */
export const SAFE_AREA = {
  top: 360,
  bottom: 240,
  left: 90,
  right: 90,
} as const;

export const CAPTION = {
  /** 字幕块底边距画布底部的距离，必须 >= SAFE_AREA.bottom */
  bottom: SAFE_AREA.bottom,
  left: 78,
  right: 78,
  maxWidth: 910,
  fontSize: 38,
  lineHeight: 1.5,
  /** 上下内边距合计 */
  paddingY: 27,
  borderRadius: 12,
  maxLines: 2,
  /** 字幕必须与主画面区分：浅底深字，且用系统无衬线，不跟随风格主字体 */
  background: 'rgba(255,252,225,0.95)',
  color: '#121212',
  fontFamily: '"PingFang SC", "Helvetica Neue", Arial, sans-serif',
  fontWeight: 600,
} as const;

/** 字幕块在最大行数下的高度 */
export const CAPTION_BLOCK_HEIGHT = Math.round(
  CAPTION.fontSize * CAPTION.lineHeight * CAPTION.maxLines + CAPTION.paddingY,
);

/** 字幕块顶边的 y 坐标 */
export const CAPTION_TOP = CANVAS.height - CAPTION.bottom - CAPTION_BLOCK_HEIGHT;

/** 字幕与场景内容之间的最小留白 */
export const CAPTION_CLEARANCE = 24;

/**
 * 场景内容底边不得越过这条线。
 * 闸门3 用它做静态校验，不做像素识别。
 */
export const SCENE_CONTENT_MAX_Y = CAPTION_TOP - CAPTION_CLEARANCE;

/** 场景内容顶边不得高于这条线 */
export const SCENE_CONTENT_MIN_Y = SAFE_AREA.top;

/** 画面元素出现时间与对应口播句起始的最大偏差 */
export const SYNC_TOLERANCE_FRAMES = 15;

/** 成片时长窗口：30-60 秒 */
export const DURATION_RANGE_FRAMES = {
  min: 30 * CANVAS.fps,
  max: 60 * CANVAS.fps,
} as const;

/** IP 整片出现次数上限 */
export const IP_MAX_APPEARANCES = 2;

/**
 * 画面文案与口播允许的最长连续重合汉字数。
 * 口径是「可以有重复，但大部分不可以」——真正该管的是占比（见闸门 G1b/G7 的
 * COVERAGE_THRESHOLD），单个短语重合放宽到整句级别才判违规。
 */
export const MAX_TEXT_OVERLAP_CHARS = 12;

/** IP 立绘的高宽比，闸门用它把 width 换算成底边，判断是否压住字幕 */
export const IP_ASPECT_RATIO = 1672 / 941;

/**
 * 排版契约：禁止单字成行。
 *
 * 任何会自动折行的文本都必须带上 TEXT_WRAP，否则末行可能只剩一个字，
 * 在竖屏大字号下极其扎眼。手写 <br /> 控制的多行文本不受影响。
 *
 * balance —— 均分各行长度，适合 1-3 行的标题和字幕
 * pretty  —— 只保证末行不落单，适合较长段落
 */
export const TEXT_WRAP = {
  balance: 'balance' as const,
  pretty: 'pretty' as const,
};

/** 中文避头尾：不让标点落在行首 */
export const LINE_BREAK = 'strict' as const;
