import React from 'react';
import {
  AbsoluteFill,
  Img,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {colors, fonts} from '../theme';
import {KeeIP, KeePose} from '../shared/KeeIP';

const appear = (frame: number, delay = 0, duration = 14) =>
  interpolate(frame, [delay, delay + duration], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

export const PaperStage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill
    style={{
      overflow: 'hidden',
      background: colors.cream,
      color: colors.forest,
      fontFamily: fonts.body,
    }}
  >
    <div
      style={{
        position: 'absolute',
        inset: 0,
        opacity: 0.18,
        backgroundImage:
          'linear-gradient(91deg, transparent 0%, rgba(26,51,0,0.035) 49.8%, transparent 50.2%), linear-gradient(2deg, transparent 0%, rgba(26,51,0,0.025) 49.8%, transparent 50.2%)',
        backgroundSize: '330px 470px, 520px 390px',
      }}
    />
    {children}
  </AbsoluteFill>
);

export const MicroLabel: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div
    style={{
      display: 'inline-flex',
      width: 'fit-content',
      alignItems: 'center',
      gap: 10,
      fontFamily: fonts.mono,
      fontSize: 22,
      lineHeight: 1,
      textTransform: 'uppercase',
      letterSpacing: 1.2,
      ...style,
    }}
  >
    <span style={{width: 11, height: 11, background: colors.yellow, border: `2px solid ${colors.forest}`, borderRadius: '50%'}} />
    {children}
  </div>
);

export const MarkerHighlight: React.FC<{
  children: React.ReactNode;
  delay?: number;
  color?: string;
  style?: React.CSSProperties;
}> = ({children, delay = 0, color = colors.yellow, style}) => {
  const frame = useCurrentFrame();
  const progress = appear(frame, delay, 12);
  return (
    <span style={{position: 'relative', display: 'inline-block', zIndex: 0, ...style}}>
      <span
        style={{
          position: 'absolute',
          zIndex: -1,
          left: '-0.06em',
          right: '-0.06em',
          bottom: '0.02em',
          height: '0.48em',
          background: color,
          transformOrigin: 'left center',
          transform: `scaleX(${progress}) rotate(-1.4deg)`,
          borderRadius: 3,
        }}
      />
      {children}
    </span>
  );
};

export const DisplayHeadline: React.FC<{
  children: React.ReactNode;
  size?: number;
  align?: 'left' | 'center';
  style?: React.CSSProperties;
}> = ({children, size = 100, align = 'left', style}) => (
  <div
    style={{
      fontFamily: fonts.display,
      fontWeight: 800,
      fontSize: size,
      lineHeight: 1.02,
      letterSpacing: size * 0.035,
      textAlign: align,
      ...style,
    }}
  >
    {children}
  </div>
);

export const SketchUnderline: React.FC<{
  width?: number;
  delay?: number;
  style?: React.CSSProperties;
}> = ({width = 420, delay = 0, style}) => {
  const frame = useCurrentFrame();
  const progress = appear(frame, delay, 18);
  return (
    <svg width={width} height="40" viewBox="0 0 420 40" style={style}>
      <path
        d="M7 22 C68 7 126 34 196 18 C266 4 328 31 413 12"
        fill="none"
        stroke={colors.forest}
        strokeWidth="6"
        strokeLinecap="round"
        pathLength="1"
        strokeDasharray="1"
        strokeDashoffset={1 - progress}
      />
    </svg>
  );
};

export const SketchArrow: React.FC<{
  width?: number;
  direction?: 'right' | 'down';
  delay?: number;
  opacity?: number;
  style?: React.CSSProperties;
}> = ({width = 300, direction = 'right', delay = 0, opacity = 1, style}) => {
  const frame = useCurrentFrame();
  const progress = appear(frame, delay, 18);
  const transform = direction === 'down' ? 'rotate(90deg)' : undefined;
  return (
    <svg width={width} height="100" viewBox="0 0 300 100" style={{transform, opacity, ...style}}>
      <path
        d="M8 62 C78 12 165 90 264 44 M244 23 L267 44 L244 66"
        fill="none"
        stroke={colors.forest}
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
        pathLength="1"
        strokeDasharray="1"
        strokeDashoffset={1 - progress}
      />
    </svg>
  );
};

export const StickyNote: React.FC<{
  children: React.ReactNode;
  tone?: 'mint' | 'teal' | 'blush' | 'yellow';
  rotate?: number;
  delay?: number;
  style?: React.CSSProperties;
}> = ({children, tone = 'mint', rotate = -2, delay = 0, style}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pop = spring({frame: Math.max(0, frame - delay), fps, config: {damping: 17, stiffness: 105}});
  const background = {mint: colors.mint, teal: colors.teal, blush: colors.blush, yellow: colors.yellow}[tone];
  return (
    <div
      style={{
        background,
        borderRadius: 12,
        padding: '26px 30px',
        fontSize: 30,
        lineHeight: 1.35,
        transform: `translateY(${(1 - pop) * 40}px) rotate(${rotate}deg)`,
        opacity: pop,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

export const WordFlow: React.FC<{
  words: string[];
  startFrame?: number;
  fontSize?: number;
  style?: React.CSSProperties;
}> = ({words, startFrame = 0, fontSize = 58, style}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 21, flexWrap: 'wrap', ...style}}>
      {words.map((word, index) => {
        const t = appear(frame, startFrame + index * 10, 12);
        return (
          <React.Fragment key={word}>
            <div
              style={{
                fontFamily: fonts.display,
                fontSize,
                fontWeight: 800,
                letterSpacing: fontSize * 0.025,
                transform: `translateY(${(1 - t) * 28}px)`,
                opacity: t,
              }}
            >
              {index === words.length - 1 ? <MarkerHighlight delay={startFrame + index * 10}>{word}</MarkerHighlight> : word}
            </div>
            {index < words.length - 1 ? <div style={{fontFamily: fonts.mono, fontSize: fontSize * 0.55, opacity: t}}>→</div> : null}
          </React.Fragment>
        );
      })}
    </div>
  );
};

export const LooseChecklist: React.FC<{
  items: string[];
  startFrame?: number;
  style?: React.CSSProperties;
}> = ({items, startFrame = 0, style}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{display: 'grid', gap: 22, ...style}}>
      {items.map((item, index) => {
        const t = appear(frame, startFrame + index * 8, 12);
        return (
          <div key={item} style={{display: 'grid', gridTemplateColumns: '46px 1fr', gap: 14, alignItems: 'start', opacity: t, transform: `translateX(${(1 - t) * -24}px)`}}>
            <div style={{fontFamily: fonts.mono, fontSize: 30, color: index === 1 ? colors.terracotta : colors.forest}}>✓</div>
            <div style={{fontSize: 30, lineHeight: 1.4, borderBottom: `1px solid ${colors.pencil}`, paddingBottom: 12}}>{item}</div>
          </div>
        );
      })}
    </div>
  );
};

/** 风格A 的 IP：奶油纸底，人物本身线条足，不描边 */
export const KeeCutout: React.FC<{
  action: KeePose;
  width?: number;
  delay?: number;
  style?: React.CSSProperties;
}> = ({action, width = 450, delay = 0, style}) => (
  <KeeIP action={action} width={width} delay={delay} rise={65} damping={18} stiffness={90} style={style} />
);

