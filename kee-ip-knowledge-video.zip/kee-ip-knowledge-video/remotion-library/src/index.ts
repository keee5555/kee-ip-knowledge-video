import '@fontsource-variable/bricolage-grotesque';
import '@fontsource-variable/inter';
import '@fontsource-variable/inter-tight';
import '@fontsource-variable/noto-sans-sc';
import '@fontsource/roboto-mono/400.css';
import {registerRoot} from 'remotion';
import {Root} from './Root';

registerRoot(Root);
