import React from 'react';
import {BlueBlockTextC, BodyCopyC, BrandStripC, CapsLabelC, CircleTextC, DoodleArrowC, MarkerTextC, OversizedNumberC, PastelIpC, SerifHeadlineC, WarmStage, WavyTextC} from './ComponentsC';
import {cColors} from './themeC';

export const BoardC: React.FC = () => (
  <WarmStage>
    <div style={{position: 'absolute', inset: '76px 72px 60px'}}>
      <CapsLabelC>Style C / Esther-inspired</CapsLabelC>

      <div style={{position: 'absolute', left: 0, right: 0, top: 125}}>
        <SerifHeadlineC size={105} style={{width: 760}}>
          把复杂知识<br />说得<MarkerTextC>更简单</MarkerTextC>
        </SerifHeadlineC>
        <BodyCopyC style={{width: 580, marginTop: 42}}>
          暖底、衬线大标题、蓝黄红三色，以及克制的手绘感。
        </BodyCopyC>
        <DoodleArrowC style={{position: 'absolute', left: 475, top: 325, transform: 'rotate(6deg)'}} />
        <div style={{position: 'absolute', right: -20, top: 25}}><PastelIpC width={315} /></div>
      </div>

      <div style={{position: 'absolute', left: 0, right: 0, top: 705, minHeight: 490, background: cColors.creamDeep, borderRadius: 22, padding: '58px 52px'}}>
        <OversizedNumberC style={{position: 'absolute', right: 20, top: 20}}>01</OversizedNumberC>
        <CapsLabelC color={cColors.orange}>Core language</CapsLabelC>
        <SerifHeadlineC size={68} style={{marginTop: 35, width: 700}}>
          标题用衬线，<br />重点用<BlueBlockTextC>蓝色块</BlueBlockTextC>或<MarkerTextC>荧光笔</MarkerTextC>
        </SerifHeadlineC>
        <BodyCopyC style={{width: 720, marginTop: 45}}>
          一屏只保留一个视觉重点；IP仅在需要解释或陪伴时出现。
        </BodyCopyC>
        <div style={{fontFamily: '"Hannotate SC", "Yuanti SC", sans-serif', fontSize: 27, color: cColors.ink, marginTop: 34, display: 'flex', gap: 30, alignItems: 'center'}}>
          <MarkerTextC>荧光笔</MarkerTextC>
          <WavyTextC>波浪线</WavyTextC>
          <CircleTextC>手绘圈</CircleTextC>
        </div>
      </div>

      <div style={{position: 'absolute', left: 0, right: 0, top: 1435}}>
        <CapsLabelC>Color ratio / 60 · 30 · 10</CapsLabelC>
        <div style={{display: 'grid', gridTemplateColumns: '1.5fr 1fr 0.75fr', gap: 20, marginTop: 34}}>
          {[
            {name: '使用者蓝', hex: '#2452A4', color: cColors.blue},
            {name: '使用者黄', hex: '#FFD43B', color: cColors.yellow},
            {name: '活力橙', hex: '#FF7A1A', color: cColors.orange},
          ].map((item) => (
            <div key={item.name}>
              <div style={{height: 92, borderRadius: '44% 56% 48% 52% / 54% 45% 55% 46%', background: item.color}} />
              <div style={{fontSize: 23, fontWeight: 650, marginTop: 16}}>{item.name}</div>
              <div style={{fontSize: 18, color: cColors.inkLight, marginTop: 5}}>{item.hex}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
    <BrandStripC style={{position: 'absolute', left: 0, right: 0, bottom: 0}} />
  </WarmStage>
);
