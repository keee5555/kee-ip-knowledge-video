export const cColors = {
  cream: '#FFF9E8',
  creamDeep: '#FFF1B8',
  ink: '#173F78',
  inkLight: '#4A5771',
  blue: '#2452A4',
  yellow: '#FFD43B',
  orange: '#FF7A1A',
  white: '#FFFDF2',
};

export const cFonts = {
  title: '"Hannotate SC", "Yuanti SC", "Microsoft YaHei", "Noto Sans SC Variable", sans-serif',
  body: '"Microsoft YaHei", "Noto Sans SC Variable", "PingFang SC", sans-serif',
  accent: '"Arial Rounded MT Bold", "Hannotate SC", sans-serif',
};
