import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {BlueBlockTextC, BodyCopyC, BrandStripC, CapsLabelC, DoodleArrowC, FadeUpC, KeyInsightC, MarkerTextC, OversizedNumberC, PastelIpC, SerifHeadlineC, WarmStage} from './ComponentsC';
import {cColors} from './themeC';

const SceneOneC: React.FC = () => (
  <WarmStage>
    <div style={{position: 'absolute', inset: '86px 70px 68px'}}>
      <CapsLabelC>Knowledge / 01</CapsLabelC>
      <OversizedNumberC style={{position: 'absolute', right: -15, top: 40}}>01</OversizedNumberC>

      <FadeUpC delay={4} style={{position: 'absolute', left: 0, top: 190, width: 760}}>
        <SerifHeadlineC size={112}>
          知识不是<br /><MarkerTextC>收藏品</MarkerTextC>
        </SerifHeadlineC>
      </FadeUpC>

      <BodyCopyC style={{position: 'absolute', left: 4, top: 575, width: 535}}>
        收藏让信息停下，行动才让知识继续走。
      </BodyCopyC>
      <DoodleArrowC style={{position: 'absolute', left: 420, top: 650, transform: 'rotate(12deg)'}} />
      <div style={{position: 'absolute', right: -38, bottom: 125}}><PastelIpC width={500} delay={12} /></div>
    </div>
    <BrandStripC style={{position: 'absolute', left: 0, right: 0, bottom: 0}} />
  </WarmStage>
);

const SceneTwoC: React.FC = () => (
  <WarmStage>
    <div style={{position: 'absolute', inset: '86px 70px 68px'}}>
      <CapsLabelC color={cColors.orange}>Process / 02</CapsLabelC>
      <OversizedNumberC color={cColors.yellow} style={{position: 'absolute', left: -25, top: 95}}>02</OversizedNumberC>

      <FadeUpC delay={3} style={{position: 'absolute', right: 0, top: 185, width: 760, textAlign: 'right'}}>
        <SerifHeadlineC size={101}>
          让信息<br /><BlueBlockTextC>持续流动</BlueBlockTextC>
        </SerifHeadlineC>
      </FadeUpC>

      <div style={{position: 'absolute', left: 8, top: 730}}><PastelIpC width={470} delay={13} /></div>
      <div style={{position: 'absolute', right: 0, top: 975, width: 430}}>
        <CapsLabelC>Collect · Refine · Publish</CapsLabelC>
        <KeyInsightC
          style={{marginTop: 28}}
          body="收集只是起点，真正重要的是继续加工。"
          conclusion="每条信息都有下一步，知识才会产生结果。"
        />
        <div style={{fontFamily: '"Arial Rounded MT Bold", sans-serif', fontSize: 34, color: cColors.orange, marginTop: 38}}>make knowledge useful.</div>
      </div>
    </div>
    <BrandStripC style={{position: 'absolute', left: 0, right: 0, bottom: 0}} />
  </WarmStage>
);

export const SampleC: React.FC = () => (
  <AbsoluteFill>
    <Sequence from={0} durationInFrames={90} premountFor={30}><SceneOneC /></Sequence>
    <Sequence from={90} durationInFrames={90} premountFor={30}><SceneTwoC /></Sequence>
  </AbsoluteFill>
);
