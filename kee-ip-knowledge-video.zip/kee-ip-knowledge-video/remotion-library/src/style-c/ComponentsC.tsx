import React from 'react';
import {AbsoluteFill, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {cColors, cFonts} from './themeC';
import {KeeIP, KeePose} from '../shared/KeeIP';

const enter = (frame: number, delay = 0, duration = 14) =>
  interpolate(frame, [delay, delay + duration], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

export const WarmStage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill
    style={{
      overflow: 'hidden',
      backgroundColor: cColors.cream,
      backgroundImage: 'radial-gradient(rgba(255,174,0,0.16) 1.5px, transparent 1.5px)',
      backgroundSize: '20px 20px',
      color: cColors.ink,
      fontFamily: cFonts.body,
    }}
  >
    {children}
  </AbsoluteFill>
);

export const CapsLabelC: React.FC<{children: React.ReactNode; color?: string; style?: React.CSSProperties}> = ({children, color = cColors.blue, style}) => (
  <div style={{fontSize: 19, lineHeight: 1.2, fontWeight: 600, letterSpacing: 2.4, color, textTransform: 'uppercase', ...style}}>
    {children}
  </div>
);

export const SerifHeadlineC: React.FC<{children: React.ReactNode; size?: number; style?: React.CSSProperties}> = ({children, size = 108, style}) => (
  <div style={{fontFamily: cFonts.title, fontSize: size, fontWeight: 900, lineHeight: 1.22, letterSpacing: -0.5, color: cColors.ink, ...style}}>
    {children}
  </div>
);

export const MarkerTextC: React.FC<{children: React.ReactNode; color?: string}> = ({children, color = cColors.yellow}) => (
  <span
    style={{
      padding: '0 10px 3px',
      background: `linear-gradient(to top, ${color} 43%, transparent 43%)`,
      WebkitBoxDecorationBreak: 'clone',
      boxDecorationBreak: 'clone',
    }}
  >
    {children}
  </span>
);

export const BlueBlockTextC: React.FC<{children: React.ReactNode}> = ({children}) => (
  <span style={{display: 'inline-block', background: cColors.blue, color: cColors.white, padding: '2px 14px 9px', margin: '7px 0', lineHeight: 1.12, borderRadius: 7, WebkitBoxDecorationBreak: 'clone', boxDecorationBreak: 'clone'}}>
    {children}
  </span>
);

export const WavyTextC: React.FC<{children: React.ReactNode}> = ({children}) => (
  <span style={{textDecoration: `underline wavy ${cColors.blue}`, textUnderlineOffset: 9, textDecorationThickness: 3}}>{children}</span>
);

export const CircleTextC: React.FC<{children: React.ReactNode}> = ({children}) => (
  <span style={{display: 'inline-block', border: `4px solid ${cColors.orange}`, borderRadius: '50% 44% 55% 42% / 48% 45% 57% 43%', padding: '0 12px 5px', transform: 'rotate(-1deg)'}}>
    {children}
  </span>
);

export const BodyCopyC: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div style={{fontSize: 31, lineHeight: 1.7, fontWeight: 450, letterSpacing: 0.2, color: cColors.inkLight, ...style}}>{children}</div>
);

export const KeyInsightC: React.FC<{body: React.ReactNode; conclusion: React.ReactNode; style?: React.CSSProperties}> = ({body, conclusion, style}) => (
  <div style={{textAlign: 'left', ...style}}>
    <div style={{fontSize: 27, lineHeight: 1.65, fontWeight: 500, color: cColors.inkLight}}>{body}</div>
    <div style={{width: 70, height: 7, borderRadius: 8, background: cColors.yellow, margin: '30px 0 26px'}} />
    <div style={{fontFamily: cFonts.title, fontSize: 38, lineHeight: 1.5, fontWeight: 800, color: cColors.blue}}>{conclusion}</div>
  </div>
);

export const OversizedNumberC: React.FC<{children: React.ReactNode; color?: string; style?: React.CSSProperties}> = ({children, color = cColors.blue, style}) => (
  <div style={{fontFamily: cFonts.accent, fontStyle: 'italic', fontSize: 230, lineHeight: 0.8, fontWeight: 700, color, opacity: 0.12, ...style}}>{children}</div>
);

export const DoodleArrowC: React.FC<{color?: string; style?: React.CSSProperties}> = ({color = cColors.orange, style}) => (
  <svg width="210" height="105" viewBox="0 0 210 105" fill="none" style={style}>
    <path d="M12 21C59 12 118 26 171 66" stroke={color} strokeWidth="7" strokeLinecap="round" />
    <path d="M146 68C159 69 172 70 190 63" stroke={color} strokeWidth="7" strokeLinecap="round" />
    <path d="M174 45C177 53 183 59 190 63" stroke={color} strokeWidth="7" strokeLinecap="round" />
  </svg>
);

/**
 * 风格C 的 IP：奶油底。
 * 底色浅、人物本身是暖调（蓝裤黄鞋正好落在本风格的蓝黄橙里），不需要描边。
 * 只有当立绘压在 creamDeep 色块或图片上时才传 outline。
 */
export const PastelIpC: React.FC<{
  action?: KeePose;
  width?: number;
  delay?: number;
  outline?: string;
  style?: React.CSSProperties;
}> = ({action = 'explaining', width = 430, delay = 0, outline, style}) => (
  <KeeIP
    action={action}
    width={width}
    delay={delay}
    outline={outline}
    rise={48}
    damping={17}
    stiffness={78}
    style={style}
  />
);

export const BrandStripC: React.FC<{style?: React.CSSProperties}> = ({style}) => (
  <div style={{display: 'grid', gridTemplateColumns: '6fr 3fr 1fr', height: 22, ...style}}>
    <div style={{background: cColors.blue}} />
    <div style={{background: cColors.yellow}} />
    <div style={{background: cColors.orange}} />
  </div>
);

export const FadeUpC: React.FC<{children: React.ReactNode; delay?: number; distance?: number; style?: React.CSSProperties}> = ({children, delay = 0, distance = 35, style}) => {
  const frame = useCurrentFrame();
  const t = enter(frame, delay, 16);
  return <div style={{opacity: t, transform: `translateY(${(1 - t) * distance}px)`, ...style}}>{children}</div>;
};
