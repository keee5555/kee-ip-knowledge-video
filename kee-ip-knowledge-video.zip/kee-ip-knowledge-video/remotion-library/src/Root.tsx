import React from 'react';
import {Composition} from 'remotion';
import {MotionKitDemo, MOTION_KIT_DEMO_DURATION} from './shared/MotionKitDemo';
import {MotionKitDemoBC, MOTION_KIT_BC_DURATION} from './shared/MotionKitDemoBC';
import {MotionKitDemoAll, MOTION_KIT_DEMO_ALL_DURATION} from './shared/MotionKitDemoAll';
import {Board} from './Board';
import {Sample} from './Sample';
import {BoardB} from './style-b/BoardB';
import {SampleB} from './style-b/SampleB';
import {BoardC} from './style-c/BoardC';
import {SampleC} from './style-c/SampleC';

export const Root: React.FC = () => (
  <>
    <Composition id="MotionKitDemoAll" component={MotionKitDemoAll} width={1080} height={1920} fps={30} durationInFrames={MOTION_KIT_DEMO_ALL_DURATION} />
    <Composition id="MotionKitDemoBC" component={MotionKitDemoBC} width={1080} height={1920} fps={30} durationInFrames={MOTION_KIT_BC_DURATION} />
    <Composition id="MotionKitDemo" component={MotionKitDemo} width={1080} height={1920} fps={30} durationInFrames={MOTION_KIT_DEMO_DURATION} />
    <Composition id="SayBrieflyBoard" component={Board} width={1080} height={1920} fps={30} durationInFrames={60} />
    <Composition id="SayBrieflySample" component={Sample} width={1080} height={1920} fps={30} durationInFrames={180} />
    <Composition id="GsapStyleBoard" component={BoardB} width={1080} height={1920} fps={30} durationInFrames={60} />
    <Composition id="GsapStyleSample" component={SampleB} width={1080} height={1920} fps={30} durationInFrames={180} />
    <Composition id="RetroStyleBoard" component={BoardC} width={1080} height={1920} fps={30} durationInFrames={60} />
    <Composition id="RetroStyleSample" component={SampleC} width={1080} height={1920} fps={30} durationInFrames={180} />
  </>
);
