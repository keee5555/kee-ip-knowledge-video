import React from 'react';
import {AbsoluteFill, interpolate, Sequence, useCurrentFrame} from 'remotion';
import {colors, fonts} from './theme';
import {StaticCaption} from './shared/SafeCaption';
import {
  DisplayHeadline,
  KeeCutout,
  MarkerHighlight,
  MicroLabel,
  PaperStage,
  SketchArrow,
  SketchUnderline,
  StickyNote,
  WordFlow,
} from './components/EditorialComponents';

const NoteScraps: React.FC = () => {
  const frame = useCurrentFrame();
  const notes = [
    {text: '收藏 128篇', color: colors.teal, left: 35, top: 35, rotate: -7},
    {text: '以后再看', color: colors.blush, left: 190, top: 145, rotate: 5},
    {text: '灵感很多', color: colors.mint, left: 55, top: 265, rotate: -3},
  ];
  return (
    <div style={{position: 'relative', width: 430, height: 430}}>
      {notes.map((note, index) => {
        const t = interpolate(frame, [8 + index * 7, 20 + index * 7], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
        return (
          <div
            key={note.text}
            style={{
              position: 'absolute',
              left: note.left,
              top: note.top,
              padding: '22px 26px',
              minWidth: 190,
              background: note.color,
              borderRadius: 10,
              fontSize: 28,
              fontWeight: 600,
              transform: `translateY(${(1 - t) * -35}px) rotate(${note.rotate}deg)`,
              opacity: t,
            }}
          >
            {note.text}
          </div>
        );
      })}
    </div>
  );
};

const ProblemScene: React.FC = () => (
  <PaperStage>
    <div style={{position: 'absolute', inset: '84px 78px 70px'}}>
      <MicroLabel>知识库误区 / 01</MicroLabel>
      <DisplayHeadline size={104} style={{marginTop: 62, width: 850}}>
        收藏很多，
        <br />
        为什么还是
        <br />
        <MarkerHighlight delay={7}>用不起来？</MarkerHighlight>
      </DisplayHeadline>
      <SketchUnderline width={520} delay={10} style={{position: 'absolute', left: 5, top: 438}} />

      <div style={{position: 'absolute', left: -10, top: 610}}>
        <NoteScraps />
      </div>
      <SketchArrow width={330} delay={30} style={{position: 'absolute', left: 270, top: 855, transform: 'rotate(10deg)'}} />
      <div style={{position: 'absolute', left: 420, top: 960, fontFamily: fonts.display, fontSize: 47, fontWeight: 800, transform: 'rotate(-3deg)'}}>
        没有下一步
      </div>

      <div style={{position: 'absolute', right: -92, bottom: 35}}>
        <KeeCutout action="confused" width={530} delay={15} />
      </div>
      <StaticCaption>问题不在收藏，而在信息没有继续流动。</StaticCaption>
    </div>
  </PaperStage>
);

const ReframeScene: React.FC = () => {
  const frame = useCurrentFrame();
  const wipe = interpolate(frame, [0, 5, 12], [1, 0.92, 0], {extrapolateRight: 'clamp'});
  return (
    <PaperStage>
      <div style={{position: 'absolute', inset: '84px 78px 70px'}}>
        <MicroLabel>认知反转 / 02</MicroLabel>
        <DisplayHeadline size={96} style={{marginTop: 62, width: 900}}>
          知识库不是仓库，
          <br />
          而是一条<MarkerHighlight delay={6}>生产线</MarkerHighlight>
        </DisplayHeadline>
        <SketchUnderline width={560} delay={10} style={{position: 'absolute', left: 250, top: 360}} />

        <WordFlow words={['收集', '加工', '输出']} startFrame={12} fontSize={68} style={{position: 'absolute', left: 0, top: 600, width: 830}} />

        <StickyNote tone="mint" rotate={-2} delay={36} style={{position: 'absolute', left: 25, top: 830, width: 475}}>
          每条信息都要有下一步：
          <br />
          变观点、变方法、变成作品。
        </StickyNote>
        <SketchArrow width={270} delay={45} style={{position: 'absolute', left: 390, top: 1030, transform: 'rotate(4deg)'}} />

        <div style={{position: 'absolute', right: -110, bottom: 22}}>
          <KeeCutout action="pointing" width={550} delay={18} />
        </div>
        <StaticCaption>知识的价值，发生在它被继续使用的时候。</StaticCaption>
      </div>
      <AbsoluteFill style={{background: colors.yellow, opacity: wipe, pointerEvents: 'none'}} />
    </PaperStage>
  );
};

export const Sample: React.FC = () => (
  <AbsoluteFill>
    <Sequence from={0} durationInFrames={90} premountFor={30}>
      <ProblemScene />
    </Sequence>
    <Sequence from={90} durationInFrames={90} premountFor={30}>
      <ReframeScene />
    </Sequence>
  </AbsoluteFill>
);
