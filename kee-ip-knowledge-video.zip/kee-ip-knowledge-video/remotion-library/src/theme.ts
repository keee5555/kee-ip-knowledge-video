export const colors = {
  forest: '#1A3300',
  yellow: '#FFE95C',
  cream: '#FCFAF5',
  pencil: '#B6B6B6',
  whisper: '#E8E7E2',
  teal: '#A8E5E5',
  mint: '#D5F5C2',
  blush: '#F6D0FF',
  terracotta: '#CB5521',
};

export const fonts = {
  display: '"Bricolage Grotesque Variable", "Noto Sans SC Variable", sans-serif',
  body: '"Inter Variable", "Noto Sans SC Variable", sans-serif',
  mono: '"Roboto Mono", monospace',
};
