import React from 'react';
import {AbsoluteFill, interpolate, Sequence, useCurrentFrame} from 'remotion';
import {bColors} from './themeB';
import {StaticCaption} from '../shared/SafeCaption';
import {
  BracketLabel,
  CategoryWord,
  ChibiPastel,
  DarkStage,
  GhostPill,
  Hairline,
  MassiveHeadline,
} from './ComponentsB';

const SceneOne: React.FC = () => (
  <DarkStage>
    <div style={{position: 'absolute', inset: '78px 62px 68px'}}>
      <BracketLabel>Knowledge / 01</BracketLabel>
      <CategoryWord color={bColors.lilac} size={30} style={{marginTop: 44}}>TEXT</CategoryWord>
      <MassiveHeadline size={143} style={{marginTop: 28, width: 850}}>
        知识库
        <br />
        不是仓库
      </MassiveHeadline>
      <div style={{position: 'absolute', right: 8, top: 650, width: 7, height: 150, background: bColors.lilac}} />
      <div style={{position: 'absolute', right: -28, bottom: 120}}><ChibiPastel width={480} delay={12} /></div>
      <GhostPill style={{position: 'absolute', left: 5, top: 765}}>看见问题 →</GhostPill>
      <Hairline style={{position: 'absolute', left: 0, right: 0, top: 935}} />
      <div style={{position: 'absolute', left: 5, top: 980, width: 500, fontSize: 39, lineHeight: 1.5, color: bColors.muted}}>
        收藏让信息停下，<br />生产才让知识继续走。
      </div>
    </div>
    <StaticCaption>当信息没有下一步，它就只是静止的库存。</StaticCaption>
  </DarkStage>
);

const SceneTwo: React.FC = () => {
  const frame = useCurrentFrame();
  const words = [
    {text: '收集', color: bColors.green, delay: 12},
    {text: '加工', color: bColors.orange, delay: 23},
    {text: '输出', color: bColors.blue, delay: 34},
  ];
  return (
    <DarkStage>
      <div style={{position: 'absolute', inset: '78px 62px 68px'}}>
        <BracketLabel>Flow / 02</BracketLabel>
        <CategoryWord color={bColors.orange} size={30} style={{marginTop: 44}}>FLOW</CategoryWord>
        <MassiveHeadline size={132} style={{marginTop: 28, width: 900}}>
          让信息
          <br />
          持续流动
        </MassiveHeadline>

        <div style={{position: 'absolute', left: 0, right: 0, top: 610, display: 'flex', alignItems: 'center', gap: 24}}>
          {words.map((word, index) => {
            const t = interpolate(frame, [word.delay, word.delay + 12], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
            return (
              <React.Fragment key={word.text}>
                <div style={{fontSize: 69, fontWeight: 600, color: word.color, opacity: t, transform: `translateY(${(1 - t) * 40}px)`}}>{word.text}</div>
                {index < words.length - 1 ? <div style={{fontSize: 34, color: bColors.muted}}>→</div> : null}
              </React.Fragment>
            );
          })}
        </div>

        <div style={{position: 'absolute', left: 5, top: 850, width: 7, height: 170, background: bColors.green}} />
        <div style={{position: 'absolute', right: -28, bottom: 120}}><ChibiPastel width={480} delay={14} /></div>
        <GhostPill style={{position: 'absolute', left: 5, top: 1115}}>从一个动作开始 →</GhostPill>
        <Hairline style={{position: 'absolute', left: 0, right: 0, top: 1270}} />
      </div>
      <StaticCaption>每条信息都有下一步，知识才会真正产生结果。</StaticCaption>
    </DarkStage>
  );
};

export const SampleB: React.FC = () => (
  <AbsoluteFill>
    <Sequence from={0} durationInFrames={90} premountFor={30}><SceneOne /></Sequence>
    <Sequence from={90} durationInFrames={90} premountFor={30}><SceneTwo /></Sequence>
  </AbsoluteFill>
);
