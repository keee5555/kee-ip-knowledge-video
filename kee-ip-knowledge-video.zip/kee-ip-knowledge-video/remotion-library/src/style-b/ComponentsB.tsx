import React from 'react';
import {
  AbsoluteFill,
  Img,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {bColors, bFonts} from './themeB';
import {KeeIP, KeePose} from '../shared/KeeIP';

const enter = (frame: number, delay = 0, duration = 14) =>
  interpolate(frame, [delay, delay + duration], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

export const DarkStage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{overflow: 'hidden', background: bColors.black, color: bColors.cream, fontFamily: bFonts.main}}>
    {children}
  </AbsoluteFill>
);

export const BracketLabel: React.FC<{children: React.ReactNode; color?: string; style?: React.CSSProperties}> = ({children, color = bColors.cream, style}) => (
  <div style={{fontSize: 24, lineHeight: 1.25, fontWeight: 450, letterSpacing: -0.2, color, ...style}}>
    {'{ '}{children}{' }'}
  </div>
);

export const MassiveHeadline: React.FC<{
  children: React.ReactNode;
  size?: number;
  color?: string;
  style?: React.CSSProperties;
}> = ({children, size = 150, color = bColors.cream, style}) => (
  <div
    style={{
      fontSize: size,
      fontWeight: 650,
      lineHeight: 1.08,
      letterSpacing: -size * 0.012,
      color,
      ...style,
    }}
  >
    {children}
  </div>
);

export const CategoryWord: React.FC<{children: React.ReactNode; color: string; size?: number; style?: React.CSSProperties}> = ({children, color, size = 34, style}) => (
  <div style={{fontSize: size, fontWeight: 520, lineHeight: 1.2, letterSpacing: -0.2, color, ...style}}>{children}</div>
);

export const GhostPill: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div
    style={{
      width: 'fit-content',
      border: `2px solid ${bColors.cream}`,
      borderRadius: 100,
      padding: '17px 28px 18px',
      fontSize: 25,
      fontWeight: 600,
      lineHeight: 1,
      ...style,
    }}
  >
    {children}
  </div>
);

export const GradientStrokePill: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div
    style={{
      width: 'fit-content',
      borderRadius: 100,
      padding: 2,
      background: `linear-gradient(114deg, ${bColors.green}, ${bColors.lightGreen})`,
      ...style,
    }}
  >
    <div style={{borderRadius: 98, background: bColors.black, padding: '16px 27px 17px', fontSize: 25, fontWeight: 600, lineHeight: 1}}>
      {children}
    </div>
  </div>
);

export const Hairline: React.FC<{style?: React.CSSProperties}> = ({style}) => <div style={{height: 1, background: bColors.hairline, ...style}} />;

/**
 * 风格B 的 IP：深黑底。
 * 人物的黑西装外套压在 #0E100F 上会糊成一片，必须描边把轮廓拔出来，
 * 描边色用本风格的奶油白 #FFFCE1。
 */
export const ChibiPastel: React.FC<{
  action?: KeePose;
  width?: number;
  delay?: number;
  style?: React.CSSProperties;
}> = ({action = 'explaining', width = 470, delay = 0, style}) => (
  <KeeIP
    action={action}
    width={width}
    delay={delay}
    outline={bColors.cream}
    outlineWidth={5}
    rise={54}
    damping={17}
    stiffness={78}
    style={style}
  />
);

export const ColorWordTrack: React.FC<{
  words: Array<{text: string; color: string}>;
  startFrame?: number;
  style?: React.CSSProperties;
}> = ({words, startFrame = 0, style}) => {
  const frame = useCurrentFrame();
  return (
    <div style={{display: 'grid', gap: 16, ...style}}>
      {words.map((word, index) => {
        const t = enter(frame, startFrame + index * 10, 12);
        return (
          <React.Fragment key={word.text}>
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', opacity: t, transform: `translateX(${(1 - t) * -45}px)`}}>
              <CategoryWord color={word.color} size={54}>{word.text}</CategoryWord>
              <div style={{fontSize: 21, color: bColors.muted}}>0{index + 1}</div>
            </div>
            {index < words.length - 1 ? <Hairline /> : null}
          </React.Fragment>
        );
      })}
    </div>
  );
};

