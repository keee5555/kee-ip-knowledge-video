export const bColors = {
  black: '#0E100F',
  offBlack: '#191919',
  cream: '#FFFCE1',
  muted: '#7C7C6F',
  hairline: '#42433D',
  green: '#0AE448',
  lightGreen: '#ABFF84',
  orange: '#FF8709',
  pink: '#FEC5FB',
  lilac: '#9D95FF',
  blue: '#00BAE2',
  lipstick: '#F100CB',
};

export const bFonts = {
  main: '"Inter Tight Variable", "Noto Sans SC Variable", sans-serif',
};
