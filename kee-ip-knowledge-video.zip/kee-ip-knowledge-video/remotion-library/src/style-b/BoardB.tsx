import React from 'react';
import {bColors} from './themeB';
import {
  BracketLabel,
  CategoryWord,
  ChibiPastel,
  ColorWordTrack,
  DarkStage,
  GradientStrokePill,
  Hairline,
  MassiveHeadline,
} from './ComponentsB';

export const BoardB: React.FC = () => (
  <DarkStage>
    <div style={{position: 'absolute', inset: '68px 64px'}}>
      <BracketLabel>Style B / Motion Library</BracketLabel>
      <MassiveHeadline size={150} style={{marginTop: 48, width: 920}}>
        让知识
        <br />
        动起来
      </MassiveHeadline>
      <div style={{position: 'absolute', right: -12, top: 175}}>
        <ChibiPastel width={310} />
      </div>
      <GradientStrokePill style={{marginTop: 52}}>Explore the system →</GradientStrokePill>

      <Hairline style={{position: 'absolute', left: 0, right: 0, top: 675}} />

      <div style={{position: 'absolute', left: 0, right: 0, top: 735}}>
        <BracketLabel>Color is taxonomy</BracketLabel>
        <MassiveHeadline size={67} style={{marginTop: 28, width: 850}}>颜色不是装饰，<br />而是告诉观众现在看什么。</MassiveHeadline>
        <div style={{display: 'flex', gap: 30, marginTop: 46, flexWrap: 'wrap'}}>
          <CategoryWord color={bColors.green} size={42}>观点 / CORE</CategoryWord>
          <CategoryWord color={bColors.orange} size={42}>步骤 / FLOW</CategoryWord>
          <CategoryWord color={bColors.pink} size={42}>案例 / STORY</CategoryWord>
          <CategoryWord color={bColors.lilac} size={42}>文字 / TEXT</CategoryWord>
          <CategoryWord color={bColors.blue} size={42}>界面 / UI</CategoryWord>
        </div>
      </div>

      <Hairline style={{position: 'absolute', left: 0, right: 0, top: 1160}} />

      <div style={{position: 'absolute', left: 0, right: 0, top: 1218, display: 'grid', gridTemplateColumns: '0.92fr 1.08fr', gap: 64}}>
        <div style={{position: 'relative', minHeight: 510}}>
          <BracketLabel color={bColors.orange}>Spacing</BracketLabel>
          <div style={{fontSize: 68, fontWeight: 620, lineHeight: 1.2, marginTop: 42, color: bColors.cream}}>
            留白<br />让信息呼吸
          </div>
          <Hairline style={{width: 250, marginTop: 48, background: bColors.orange}} />
        </div>
        <div>
          <BracketLabel>Components</BracketLabel>
          <ColorWordTrack
            startFrame={0}
            words={[
              {text: 'Massive Type', color: bColors.cream},
              {text: 'Color Label', color: bColors.lilac},
              {text: 'Ghost Pill', color: bColors.green},
              {text: 'Pastel IP', color: bColors.blue},
            ]}
            style={{marginTop: 34}}
          />
        </div>
      </div>

      <div style={{position: 'absolute', left: 0, right: 0, bottom: 16}}>
        <BracketLabel color={bColors.muted}>Design rule</BracketLabel>
        <div style={{fontSize: 46, lineHeight: 1.35, fontWeight: 560, marginTop: 20, width: 920}}>
          不把知识装进框里。让文字、颜色和形状直接发生运动。
        </div>
      </div>
    </div>
  </DarkStage>
);
