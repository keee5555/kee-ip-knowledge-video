import React from 'react';
import {colors, fonts} from './theme';
import {
  DisplayHeadline,
  KeeCutout,
  LooseChecklist,
  MarkerHighlight,
  MicroLabel,
  PaperStage,
  SketchArrow,
  SketchUnderline,
  StickyNote,
  WordFlow,
} from './components/EditorialComponents';

const BrushSwatch: React.FC<{color: string; name: string; hex: string; rotate: number}> = ({color, name, hex, rotate}) => (
  <div style={{display: 'grid', gap: 10, transform: `rotate(${rotate}deg)`}}>
    <div
      style={{
        height: 58,
        background: color,
        borderRadius: '40% 12% 36% 9% / 42% 29% 52% 18%',
        boxShadow: color === colors.cream ? `inset 0 0 0 1px ${colors.pencil}` : 'none',
      }}
    />
    <div style={{fontSize: 22, fontWeight: 650}}>{name}</div>
    <div style={{fontFamily: fonts.mono, fontSize: 17, color: colors.pencil}}>{hex}</div>
  </div>
);

export const Board: React.FC = () => (
  <PaperStage>
    <div style={{position: 'absolute', inset: '68px 72px'}}>
      <MicroLabel>STYLE 01 / CREATIVE SKETCHBOOK</MicroLabel>

      <DisplayHeadline size={106} align="center" style={{marginTop: 68}}>
        把复杂知识
        <br />
        说得<MarkerHighlight delay={5}>更简单</MarkerHighlight>
      </DisplayHeadline>
      <div style={{fontSize: 28, textAlign: 'center', lineHeight: 1.55, width: 710, margin: '34px auto 0'}}>
        奶油纸、森林绿、荧光笔和手绘线稿。
        <br />
        内容像工作室草稿，而不是软件界面。
      </div>
      <SketchUnderline width={520} delay={8} style={{display: 'block', margin: '12px auto 0'}} />

      <div style={{position: 'absolute', right: -10, top: 250}}>
        <KeeCutout action="explaining" width={260} />
      </div>
      <SketchArrow width={240} delay={12} style={{position: 'absolute', right: 185, top: 500, transform: 'rotate(154deg)'}} />

      <div style={{position: 'absolute', left: 0, right: 0, top: 690}}>
        <MicroLabel>COLOR NOTES</MicroLabel>
        <div style={{display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 22, marginTop: 22}}>
          <BrushSwatch color={colors.forest} name="森林墨绿" hex="#1A3300" rotate={-2} />
          <BrushSwatch color={colors.yellow} name="荧光笔黄" hex="#FFE95C" rotate={1} />
          <BrushSwatch color={colors.cream} name="奶油纸" hex="#FCFAF5" rotate={-1} />
          <BrushSwatch color={colors.mint} name="便签薄荷" hex="#D5F5C2" rotate={2} />
          <BrushSwatch color={colors.blush} name="便签粉" hex="#F6D0FF" rotate={-2} />
        </div>
      </div>

      <div style={{position: 'absolute', left: 0, right: 0, top: 940}}>
        <MicroLabel>COMPONENT LANGUAGE</MicroLabel>
        <div style={{display: 'grid', gridTemplateColumns: '1.06fr 0.94fr', gap: 50, marginTop: 30}}>
          <div>
            <DisplayHeadline size={61}>
              重点词只用
              <br />
              <MarkerHighlight delay={6}>荧光笔划出来</MarkerHighlight>
            </DisplayHeadline>
            <div style={{marginTop: 36}}>
              <WordFlow words={['收集', '加工', '输出']} fontSize={44} />
            </div>
            <StickyNote tone="mint" rotate={-2} style={{width: 420, marginTop: 38}}>
              一页只放一张便签。
              <br />
              它是想法，不是卡片容器。
            </StickyNote>
          </div>
          <LooseChecklist
            items={['大标题负责观点', '手绘线条负责引导', 'IP只在需要时出现', '不用卡片网格组织内容']}
            style={{marginTop: 4}}
          />
        </div>
      </div>

      <div style={{position: 'absolute', left: 0, right: 0, bottom: 15}}>
        <div style={{fontFamily: fonts.display, fontSize: 53, fontWeight: 800, lineHeight: 1.15, width: 800}}>
          “画面不是把信息装进框里，
          <br />
          而是帮观众<MarkerHighlight delay={14}>看见思考过程</MarkerHighlight>。”
        </div>
        <div style={{fontFamily: fonts.mono, fontSize: 18, marginTop: 28, color: colors.pencil}}>
          DISPLAY HEADLINE · MARKER HIGHLIGHT · SKETCH ARROW · STICKY NOTE · WORD FLOW · LOOSE CHECKLIST
        </div>
      </div>
    </div>
  </PaperStage>
);
