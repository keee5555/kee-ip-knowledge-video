#!/usr/bin/env python3
"""用 CosyVoice3 零样本复刻生成配音，并算出全部时间轴。

替代了原来「手算帧数」的环节：换一版配音，重跑一次，
ranges / captions / SRT 全部按新音频重算，不需要人去数帧。

用法:
    python3 tts_cosyvoice.py <分镜脚本.md> --out <输出目录>

输出:
    <out>/voiceover.mp3      合并后的整条配音
    <out>/scene-NN.wav       每镜单独音频
    <out>/timeline.json      ranges + captions（可直接贴进生产 tsx）
    <out>/旁白.srt

参考音配置见下方 PROMPT_*，换人配音改这两项即可。
"""

from __future__ import annotations

import argparse
import os
import json
import re
import subprocess
import sys
from pathlib import Path

TTS_HOME = Path(os.environ.get("TTS_HOME", str(Path.home() / ".local/share/kee-tts")))
COSY_REPO = TTS_HOME / "CosyVoice"
MODEL_DIR = TTS_HOME / "models/Fun-CosyVoice3-0.5B"
# CosyVoice3 强制要求文本里出现 <|endofprompt|>，且必须是系统前缀写法。
# 追加到转写末尾也能跑，但输出会被拉长近一倍（实测 7.9s -> 13.7s）。
PROMPT_PREFIX = "You are a helpful assistant.<|endofprompt|>"

# 多语气参考音。
#
# 用同一段平述参考音配完整条片子，语气必然是平的——这是「一板一眼」的根因。
# 默认整篇连续合成，分镜只切画面；若显式使用 --segmented，
# 每镜可以换不同的参考音。分镜脚本里用 `语气：xxx` 指定，缺省走「平述」。
#
# transcript 必须与录音逐字对应，错字会让音色漂移。
TONES = {
    "平述": (os.environ.get("TTS_PROMPT_WAV", "prompt/reference.wav"),
             os.environ.get("TTS_PROMPT_TEXT", "")),
}
DEFAULT_TONE = "平述"

# instruct 模式：在克隆音色的同时给语气指令。
# 纯 zero_shot + speed 只是重采样，语速快了但没有精神头；
# instruct 是真的换说话方式（实测同句 7.50s -> 4.10s 且更有起伏）。
USE_INSTRUCT = False
INSTRUCT_TEXT = "You are a helpful assistant. 请像跟朋友聊天一样，语速稍快、有起伏地说。<|endofprompt|>"

FPS = 30
# instruct 模式虽然快，但语气被指令带偏，听着不像本人。
# 回到纯 zero_shot 克隆 + 倍速，保真度优先。1.2 与 1.5 都可用。
SPEED = 1.25
# 镜间停顿。CosyVoice 输出末尾有一段渐弱的软尾，实测 0.25 的设定
# 听感是 0.38s；先削软尾落地成实体文件，再补一个确定的小间隔。
#
# 关键：时间轴必须从「削完的文件」算，不能从原始文件算——
# 否则画面按未削的时长走、声音按削完的走，误差会逐镜累积成音画不同步。
GAP_SEC = 0.10
# 只削尾巴。
#
# 坑：silenceremove 的 stop_periods=-1 会把「句子内部的停顿」也一起删掉，
# 实测八镜合计被删 10.71 秒——说话的呼吸和节奏全被抹平，听起来很不自然。
# 正确做法是倒放后削头、再倒回来，这样只动尾部。
# 只削「真数字静音」，绝不碰尾音衰减。
#
# 踩过三次：
#   stop_periods=-1  → 连句内停顿一起删，八镜共删 10.71s，节奏全毁
#   -40dB            → 切在尾音衰减中段，每句像没说完
#   -50dB            → 多数镜可以，但衰减里有低谷的镜仍会被削穿
# 现在只切 -70dB 以下（TTS 输出的尾部是 -91dB 的纯数字静音），衰减一律保留。
TAIL_TRIM = (
    "areverse,"
    "silenceremove=start_periods=1:start_duration=0.05:start_threshold=-70dB,"
    "areverse"
)
# 收尾完整性阈值：末尾必须已经衰减到此值以下。
# 削尾后的终检和 worker 内的截断重试共用它。
TAIL_INTACT_DB = -40.0
# 削掉超过这个时长就说明切到真声音了，直接报错而不是安静地毁掉配音
MAX_TRIM_SEC = 0.6
# 截断检测：CosyVoice 偶发会在句子说完前就结束生成，
# 表现为「满音量 → 直接跳进数字静音」，没有尾音衰减。
#
# 必须和 TAIL_INTACT_DB 用同一个阈值——否则 worker 里判「够好」放行的片段，
# 到削尾后的完整性检查又被打回，白白浪费了重试机会。实测踩过：
# 镜02 在 -35.6dB 通过了 -35 的重试判定，却过不了 -40 的终检。
TRUNCATION_DB = TAIL_INTACT_DB
TRUNCATION_RETRIES = 3
# 片尾留白：最后一镜在口播结束后多停这么久，给观众读完结尾问题的时间
OUTRO_HOLD_FRAMES = 45
FFMPEG = "ffmpeg"
SCENE_HEADER = re.compile(r"^###\s*(\d+)｜")
NARRATION = re.compile(r"^-\s*口播：(.+)$")
TONE = re.compile(r"^-\s*语气：(.+)$")
SENTENCE_END = re.compile(r"(?<=[。？！])")
CLAUSE_END = re.compile(r"(?<=[，、；：])")
EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
# 字幕单行容量 = CAPTION.maxWidth 910 / fontSize 38 ≈ 24 字，留 2 字余量。
# 超过就按逗号再切一层——让每条字幕都不折行，从根上杜绝单字成行和词中断行。
MAX_CAPTION_CHARS = 22


def parse_narration(script: Path) -> list[tuple[str, str, str]]:
    """抽出每镜的 (镜号, 口播, 语气)。语气缺省走 DEFAULT_TONE。"""
    out: list[tuple[str, str, str]] = []
    index: str | None = None
    text: str | None = None
    tone = DEFAULT_TONE
    for line in script.read_text(encoding="utf-8").splitlines():
        m = SCENE_HEADER.match(line)
        if m:
            if index and text:
                out.append((index, text, tone))
            index, text, tone = m.group(1), None, DEFAULT_TONE
            continue
        if not index:
            continue
        stripped = line.strip()
        n = NARRATION.match(stripped)
        if n:
            text = n.group(1).strip()
            continue
        t = TONE.match(stripped)
        if t:
            value = t.group(1).strip().rstrip("。")
            if value not in TONES:
                raise SystemExit(f"镜{index} 的语气「{value}」未定义，可选：{'、'.join(TONES)}")
            tone = value
    if index and text:
        out.append((index, text, tone))
    return out


def duration_sec(path: Path) -> float:
    err = subprocess.run([FFMPEG, "-i", str(path)], capture_output=True, text=True).stderr
    h, m, s = re.search(r"Duration: (\d+):(\d+):([\d.]+)", err).groups()
    return int(h) * 3600 + int(m) * 60 + float(s)


def trim_tail(src: Path, dst: Path) -> None:
    """只削掉末尾的数字静音，落地成实体文件。"""
    subprocess.run(
        [FFMPEG, "-y", "-i", str(src), "-af", TAIL_TRIM, str(dst)],
        check=True, capture_output=True,
    )


def tail_level_db(path: Path, window: float = 0.10) -> float:
    """末尾 window 秒的平均电平。"""
    err = subprocess.run(
        [FFMPEG, "-sseof", f"-{window}", "-i", str(path), "-t", str(window),
         "-af", "volumedetect", "-f", "null", "-"],
        capture_output=True, text=True,
    ).stderr
    m = re.search(r"mean_volume: ([-\d.]+)", err)
    return float(m.group(1)) if m else -99.0


def synthesize(lines: list[tuple[str, str, str]], out_dir: Path) -> None:
    """在 CosyVoice 的 venv 里跑合成——本进程不需要 import torch。"""
    payload = json.dumps(
        {
            "lines": lines,
            "out_dir": str(out_dir),
            "model": str(MODEL_DIR),
            "tones": {
                name: [str(TTS_HOME / wav), PROMPT_PREFIX + transcript]
                for name, (wav, transcript) in TONES.items()
            },
            "speed": SPEED,
            "truncation_db": TRUNCATION_DB,
            "retries": TRUNCATION_RETRIES,
            "use_instruct": USE_INSTRUCT,
            "instruct_text": INSTRUCT_TEXT,
        },
        ensure_ascii=False,
    )
    worker = COSY_REPO / "_kee_tts_worker.py"
    worker.write_text(WORKER_SRC, encoding="utf-8")
    env_pythonpath = f"{COSY_REPO}:{COSY_REPO / 'third_party/Matcha-TTS'}"
    result = subprocess.run(
        [str(TTS_HOME / "venv/bin/python"), str(worker)],
        input=payload,
        text=True,
        cwd=str(COSY_REPO),
        env={"PYTHONPATH": env_pythonpath, "PATH": "/usr/bin:/bin", "HOME": str(Path.home())},
        capture_output=True,
    )
    if result.returncode != 0:
        print(result.stdout[-2000:], file=sys.stderr)
        print(result.stderr[-2000:], file=sys.stderr)
        raise SystemExit("合成失败")
    print(result.stdout.strip()[-1200:])
    stuck = [l for l in result.stderr.splitlines() if l.startswith("TRUNCATED")]
    if stuck:
        for line in stuck:
            _, tag, db = line.split("\t")
            print(f"镜{tag} 重试 {TRUNCATION_RETRIES} 次仍被截断（尾部 {db}dB）", file=sys.stderr)
        raise SystemExit("配音被截断，别拿这版去渲染")


WORKER_SRC = '''
import json, math, sys, warnings, pathlib
warnings.filterwarnings("ignore")
import torch, torchaudio
from cosyvoice.cli.cosyvoice import CosyVoice3

cfg = json.loads(sys.stdin.read())
out = pathlib.Path(cfg["out_dir"]); out.mkdir(parents=True, exist_ok=True)
model = CosyVoice3(cfg["model"], load_trt=False, fp16=False)

def tail_db(wav, sr):
    """硬切点之前 0.15 秒的电平。正常收尾已衰减，截断时仍是满音量。"""
    x = wav.abs().squeeze(0)
    voiced = (x > 1e-4).nonzero()
    if voiced.numel() == 0:
        return -99.0
    end = int(voiced[-1].item())
    start = max(0, end - int(0.15 * sr))
    seg = wav.squeeze(0)[start:end + 1]
    if seg.numel() == 0:
        return -99.0
    rms = float(torch.sqrt(torch.mean(seg.float() ** 2)))
    return 20.0 * math.log10(max(rms, 1e-9))


for tag, text, tone in cfg["lines"]:
    prompt_wav, prompt_text = cfg["tones"][tone]
    # prompt_wav 传路径，这版 API 不接受已加载的张量
    if cfg["use_instruct"]:
        gen = model.inference_instruct2(
            text, cfg["instruct_text"], prompt_wav, stream=False, speed=cfg["speed"])
    else:
        gen = model.inference_zero_shot(
            text, prompt_text, prompt_wav, stream=False, speed=cfg["speed"])
    chunks = [c["tts_speech"] for c in gen]
    wav = torch.concat(chunks, dim=1)

    # 截断重试：模型偶发会在句子说完前收尾，重跑通常就好了
    for attempt in range(cfg["retries"]):
        db = tail_db(wav, model.sample_rate)
        if db <= cfg["truncation_db"]:
            break
        print(f"{tag} 尾部 {db:.1f}dB，疑似截断，第 {attempt + 1} 次重试")
        if cfg["use_instruct"]:
            gen = model.inference_instruct2(
                text, cfg["instruct_text"], prompt_wav, stream=False, speed=cfg["speed"])
        else:
            gen = model.inference_zero_shot(
                text, prompt_text, prompt_wav, stream=False, speed=cfg["speed"])
        wav = torch.concat([c["tts_speech"] for c in gen], dim=1)
    else:
        db = tail_db(wav, model.sample_rate)
        if db > cfg["truncation_db"]:
            print(f"TRUNCATED\t{tag}\t{db:.1f}", file=sys.stderr)

    dst = out / f"scene-{tag}.wav"
    torchaudio.save(str(dst), wav, model.sample_rate)
    print(f"{tag} [{tone}] -> {dst.name} {wav.shape[1]/model.sample_rate:.2f}s")
'''


def split_sentences(text: str) -> list[str]:
    """先按句号切，过长的再按逗号切，保证每条字幕一行放得下。"""
    out: list[str] = []
    for sentence in (p.strip() for p in SENTENCE_END.split(text) if p.strip()):
        if len(sentence) <= MAX_CAPTION_CHARS:
            out.append(sentence)
            continue
        buf = ""
        clauses: list[str] = []
        for clause in (c for c in CLAUSE_END.split(sentence) if c):
            # 邮箱前通常没有中文标点；整段塞进一条字幕会超宽。
            # 在邮箱起点拆开，地址本身保持完整，避免视觉上断成两截。
            match = EMAIL.search(clause)
            if len(clause) > MAX_CAPTION_CHARS and match and match.start() > 0:
                clauses.extend([clause[:match.start()], clause[match.start():]])
            else:
                clauses.append(clause)
        for clause in clauses:
            if buf and len(buf) + len(clause) > MAX_CAPTION_CHARS:
                out.append(buf.strip())
                buf = clause
            else:
                buf += clause
        if buf.strip():
            out.append(buf.strip())
    return out


def build_timeline(lines: list[tuple[str, str, str]], out_dir: Path) -> dict:
    ranges, cues, srt = [], [], []
    cursor = 0.0
    n = 1
    for i, (tag, text, _tone) in enumerate(lines):
        wav = out_dir / f"scene-{tag}-trimmed.wav"
        dur = duration_sec(wav)
        gap = GAP_SEC if i < len(lines) - 1 else 0.0
        start_f = round(cursor * FPS)

        pieces = split_sentences(text)
        weights = [len(p) for p in pieces] or [1]
        local = cursor
        for piece, w in zip(pieces, weights):
            d = dur * w / sum(weights)
            cues.append({"from": round(local * FPS), "to": round((local + d) * FPS), "text": piece})

            def ts(t: float) -> str:
                return f"{int(t//3600):02d}:{int(t%3600//60):02d}:{t%60:06.3f}".replace(".", ",")

            srt.append(f"{n}\n{ts(local)} --> {ts(local + d)}\n{piece}\n")
            n += 1
            local += d

        cursor += dur + gap
        ranges.append({"from": start_f, "duration": round(cursor * FPS) - start_f})

    # 片尾多停一会，别让结尾问题一闪而过
    ranges[-1]["duration"] += OUTRO_HOLD_FRAMES
    total = ranges[-1]["from"] + ranges[-1]["duration"]
    (out_dir / "旁白.srt").write_text("\n".join(srt), encoding="utf-8")
    timeline = {
        "fps": FPS,
        "total_frames": total,
        "duration_sec": round(total / FPS, 2),
        "ranges": ranges,
        "captions": cues,
    }
    (out_dir / "timeline.json").write_text(
        json.dumps(timeline, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return timeline


def merge_audio(lines: list[tuple[str, str, str]], out_dir: Path) -> None:
    # 用削完尾的文件合并——和算时间轴用的是同一批文件
    parts = [out_dir / f"scene-{tag}-trimmed.wav" for tag, _, _ in lines]
    cmd = [FFMPEG, "-y"]
    for p in parts:
        cmd += ["-i", str(p)]
    # 最后一镜后面不补间隔——build_timeline 里它的 gap 也是 0，
    # 补了就会多出 GAP_SEC，累积成音画偏差
    filt = "".join(
        f"[{i}:a]apad=pad_dur={GAP_SEC}[a{i}];" if i < len(parts) - 1 else f"[{i}:a]anull[a{i}];"
        for i in range(len(parts))
    )
    filt += "".join(f"[a{i}]" for i in range(len(parts))) + f"concat=n={len(parts)}:v=0:a=1[out]"
    cmd += ["-filter_complex", filt, "-map", "[out]", "-ar", "48000", "-b:a", "160k",
            str(out_dir / "voiceover.mp3")]
    subprocess.run(cmd, check=True, capture_output=True)


def build_continuous_timeline(lines: list[tuple[str, str, str]], out_dir: Path) -> dict:
    """整篇连续合成后，按各镜文本长度估算视觉分镜与字幕时间。

    声音不再在镜头边界切开；ranges 只控制画面切换。这样逗号连接的两个镜头
    会保留同一次合成里的连续语气，不产生人为句尾和固定间隔。
    """
    wav = out_dir / "continuous-trimmed.wav"
    voice_sec = duration_sec(wav)
    total_weight = sum(max(1, len(text)) for _, text, _ in lines)
    ranges, cues, srt = [], [], []
    cursor = 0.0
    n = 1

    for i, (tag, text, _tone) in enumerate(lines):
        scene_dur = voice_sec * max(1, len(text)) / total_weight
        scene_start = cursor
        scene_end = voice_sec if i == len(lines) - 1 else cursor + scene_dur
        start_f = round(scene_start * FPS)
        end_f = round(scene_end * FPS)
        ranges.append({"from": start_f, "duration": end_f - start_f})

        pieces = split_sentences(text)
        weights = [len(p) for p in pieces] or [1]
        local = scene_start
        for piece, weight in zip(pieces, weights):
            d = (scene_end - scene_start) * weight / sum(weights)
            cues.append({"from": round(local * FPS), "to": round((local + d) * FPS), "text": piece})

            def ts(t: float) -> str:
                return f"{int(t//3600):02d}:{int(t%3600//60):02d}:{t%60:06.3f}".replace(".", ",")

            srt.append(f"{n}\n{ts(local)} --> {ts(local + d)}\n{piece}\n")
            n += 1
            local += d

        cursor = scene_end

    voice_frames = round(voice_sec * FPS)
    ranges[-1]["duration"] = voice_frames - ranges[-1]["from"] + OUTRO_HOLD_FRAMES
    total = ranges[-1]["from"] + ranges[-1]["duration"]
    (out_dir / "旁白.srt").write_text("\n".join(srt), encoding="utf-8")
    timeline = {
        "fps": FPS,
        "mode": "continuous",
        "total_frames": total,
        "duration_sec": round(total / FPS, 2),
        "ranges": ranges,
        "captions": cues,
    }
    (out_dir / "timeline.json").write_text(
        json.dumps(timeline, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return timeline


def encode_continuous_audio(out_dir: Path) -> None:
    subprocess.run(
        [FFMPEG, "-y", "-i", str(out_dir / "continuous-trimmed.wav"),
         "-ar", "48000", "-b:a", "160k", str(out_dir / "voiceover.mp3")],
        check=True, capture_output=True,
    )


def slice_continuous_scenes(
    lines: list[tuple[str, str, str]], timeline: dict, out_dir: Path
) -> None:
    """保留逐镜 wav 交付物，但它们只用于检查；正式音轨始终使用连续版本。"""
    ranges = timeline["ranges"]
    for i, (tag, _text, _tone) in enumerate(lines):
        start = ranges[i]["from"] / FPS
        duration_frames = ranges[i]["duration"]
        if i == len(lines) - 1:
            duration_frames -= OUTRO_HOLD_FRAMES
        duration = duration_frames / FPS
        for suffix in ("", "-trimmed"):
            dst = out_dir / f"scene-{tag}{suffix}.wav"
            subprocess.run(
                [FFMPEG, "-y", "-ss", f"{start:.6f}",
                 "-i", str(out_dir / "continuous-trimmed.wav"),
                 "-t", f"{duration:.6f}", str(dst)],
                check=True, capture_output=True,
            )


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("script", type=Path)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--skip-synth", action="store_true", help="音频已存在，只重算时间轴")
    mode = ap.add_mutually_exclusive_group()
    mode.add_argument(
        "--continuous", dest="continuous", action="store_true",
        help="整篇一次合成；分镜只切画面，不切断语气（默认）",
    )
    mode.add_argument(
        "--segmented", dest="continuous", action="store_false",
        help="逐镜合成；仅用于多语气且镜间没有跨句的稿件",
    )
    ap.set_defaults(continuous=True)
    args = ap.parse_args()

    # 合成 worker 以 cwd=COSY_REPO 运行（见 synthesize），相对路径会落进
    # ~/.local/share/kee-tts/CosyVoice/ 里，而父进程随后按自己的 cwd 找同一个
    # 相对路径，于是 ffmpeg 报 "No such file"，且 wav 静静躺在仓库里没人发现。
    # 两边都转绝对路径，路径含中文或空格时同样安全。
    args.script = args.script.resolve()
    args.out = args.out.resolve()

    lines = parse_narration(args.script)
    if not lines:
        print("没有从分镜脚本解析到口播", file=sys.stderr)
        return 2
    print("解析到 " + str(len(lines)) + " 镜口播：" + "、".join(f"{t}[{tn}]" for t, _, tn in lines))

    args.out.mkdir(parents=True, exist_ok=True)
    if args.continuous:
        tones = {tone for _, _, tone in lines}
        if len(tones) != 1:
            print("连续模式要求整篇使用同一种语气；当前包含：" + "、".join(sorted(tones)), file=sys.stderr)
            return 2
        continuous_lines = [("continuous", "".join(text for _, text, _ in lines), next(iter(tones)))]
        if not args.skip_synth:
            synthesize(continuous_lines, args.out)

        raw = args.out / "scene-continuous.wav"
        cut = args.out / "continuous-trimmed.wav"
        trim_tail(raw, cut)
        removed = duration_sec(raw) - duration_sec(cut)
        if removed > MAX_TRIM_SEC:
            print(f"连续音轨削掉了 {removed:.2f}s，超过 {MAX_TRIM_SEC}s", file=sys.stderr)
            return 2
        db = tail_level_db(cut)
        if db > TAIL_INTACT_DB:
            print(f"连续音轨收尾不完整：末尾 0.10s 仍有 {db:.1f}dB", file=sys.stderr)
            return 2
        print(f"  连续音轨削 {removed:.2f}s，收尾 {db:.1f}dB ✓")

        timeline = build_continuous_timeline(lines, args.out)
        encode_continuous_audio(args.out)
        slice_continuous_scenes(lines, timeline, args.out)
    else:
        if not args.skip_synth:
            synthesize(lines, args.out)

        # 削尾落地：时间轴和合并音轨必须基于同一批文件
        for tag, _, _ in lines:
            raw = args.out / f"scene-{tag}.wav"
            cut = args.out / f"scene-{tag}-trimmed.wav"
            trim_tail(raw, cut)
            removed = duration_sec(raw) - duration_sec(cut)
            if removed > MAX_TRIM_SEC:
                print(
                    f"镜{tag} 削掉了 {removed:.2f}s，超过 {MAX_TRIM_SEC}s——"
                    f"多半切到真声音了，调高 TAIL_TRIM 的阈值",
                    file=sys.stderr,
                )
                return 2
            # 收尾完整性：末尾还是满音量就说明这句被切断了
            db = tail_level_db(cut)
            if db > TAIL_INTACT_DB:
                print(
                    f"镜{tag} 收尾不完整：末尾 0.10s 仍有 {db:.1f}dB"
                    f"（阈值 {TAIL_INTACT_DB}dB），这句话被切断了",
                    file=sys.stderr,
                )
                return 2
            print(f"  镜{tag} 削 {removed:.2f}s，收尾 {db:.1f}dB ✓")

        timeline = build_timeline(lines, args.out)
        merge_audio(lines, args.out)

    # 硬校验：合并音轨时长必须和时间轴对得上，否则就是音画不同步
    audio_sec = duration_sec(args.out / "voiceover.mp3")
    expect_sec = (timeline["total_frames"] - OUTRO_HOLD_FRAMES) / FPS
    drift = abs(audio_sec - expect_sec)
    print(f"音轨 {audio_sec:.2f}s vs 时间轴 {expect_sec:.2f}s，偏差 {drift:.3f}s")
    if drift > 0.10:
        print("音画不同步：时间轴与实际音轨对不上", file=sys.stderr)
        return 2

    print(f"\n总帧 {timeline['total_frames']}（{timeline['duration_sec']}s）")
    ok = 30 <= timeline["duration_sec"] <= 60
    print("时长窗口:", "✅ 在 30-60s 内" if ok else "❌ 超窗，需要改口播稿")
    print("ranges:", ", ".join(f"{r['from']}+{r['duration']}" for r in timeline["ranges"]))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
