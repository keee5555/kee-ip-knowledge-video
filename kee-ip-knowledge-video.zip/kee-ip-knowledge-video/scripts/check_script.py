#!/usr/bin/env python3
"""闸门1 — 分镜闸门。在生成配音和渲染之前跑，秒级。

用法:
    python3 check_script.py <分镜脚本.md> [--json]

检查项:
    G1a 长串复述 — 任一画面文案与本镜口播的最长公共子串超过阈值
    G1b 密集复述 — 本镜口播被画面文案覆盖的汉字占比超过阈值
    G2  时间轴   — 分镜区间连续、无缺口无重叠、总时长在 30-60 秒窗口内
    G3  IP 次数  — 整片出现镜数不超过上限
    G4  截图处理 — 引用截图的镜必须整张放入，不得裁切
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

# 与 remotion-library/src/layout.ts 保持一致
MAX_TEXT_OVERLAP_CHARS = 12
COVERAGE_THRESHOLD = 0.35
IP_MAX_APPEARANCES = 2
DURATION_MIN_SEC = 30
DURATION_MAX_SEC = 60

# 这些字段的内容会真的出现在画面上
ON_SCREEN_KEYS = {
    "画面主信息",
    "补充信息",
    "收束句",
    "结尾问题",
    "四层作用",
    "飞书操作类",
    "内容生产类",
}

# 这些字段是给制作看的说明，不上屏
DIRECTIVE_KEYS = {
    "口播",
    "画面",
    "构图",
    "动效",
    "IP",
    "图片",
    "参考",
    "合规口径",
}

SCENE_HEADER = re.compile(r"^###\s*(\d+)｜(\d+):(\d+)[–\-~](\d+):(\d+)｜(.*)$")
BULLET = re.compile(r"^(\s*)-\s*(.+)$")
CJK = re.compile(r"[一-鿿]")
# 截图必须整张放入，出现这些词说明做了裁切
CROP_WORDS = ("裁切", "只展示", "局部", "截取")



def cjk_only(text: str) -> str:
    return "".join(CJK.findall(text))


def longest_common_substring(a: str, b: str) -> str:
    """短字符串直接暴力找，分镜文案都在几十字以内。"""
    best = ""
    for start in range(len(a)):
        for end in range(len(a), start + len(best), -1):
            chunk = a[start:end]
            if chunk in b:
                if len(chunk) > len(best):
                    best = chunk
                break
    return best


def coverage_ratio(fragments: list[str], narration: str) -> tuple[float, list[str]]:
    """口播里有多少汉字被画面文案原样命中。"""
    target = cjk_only(narration)
    if not target:
        return 0.0, []
    covered = [False] * len(target)
    hits: list[str] = []
    for fragment in fragments:
        piece = cjk_only(fragment)
        if len(piece) < 2:
            continue
        for match in re.finditer(re.escape(piece), target):
            for i in range(match.start(), match.end()):
                covered[i] = True
            if piece not in hits:
                hits.append(piece)
    return sum(covered) / len(target), hits


def parse_scenes(text: str) -> list[dict]:
    scenes: list[dict] = []
    current: dict | None = None
    active_key: str | None = None

    for raw in text.splitlines():
        header = SCENE_HEADER.match(raw)
        if header:
            index, m1, s1, m2, s2, title = header.groups()
            current = {
                "index": int(index),
                "title": title.strip(),
                "start": int(m1) * 60 + int(s1),
                "end": int(m2) * 60 + int(s2),
                "narration": "",
                "on_screen": [],
                "ip": False,
                "images": [],
                "notes": [],
            }
            scenes.append(current)
            active_key = None
            continue

        if current is None:
            continue
        if raw.startswith("#"):
            current = None
            continue

        bullet = BULLET.match(raw)
        if not bullet:
            continue
        indent, body = bullet.groups()
        nested = len(indent) > 0

        if nested:
            if active_key in ON_SCREEN_KEYS:
                current["on_screen"].append(body.strip())
            elif active_key == "图片":
                current["images"].append(body.strip())
            continue

        if "：" in body:
            key, _, value = body.partition("：")
        elif ":" in body:
            key, _, value = body.partition(":")
        else:
            key, value = body, ""
        key = key.strip().strip("`")
        value = value.strip()
        active_key = key

        if key == "口播":
            current["narration"] = value
        elif key in ON_SCREEN_KEYS:
            if value:
                current["on_screen"].append(value)
        elif key == "IP":
            current["ip"] = "出现" in value and "不出现" not in value
        elif key == "图片":
            if value:
                current["images"].append(value)
        elif key in DIRECTIVE_KEYS:
            current["notes"].append(f"{key}：{value}")

    return scenes


def split_fragments(chunk: str) -> list[str]:
    """把 `A` / `B` 或 `A`：B 这类写法拆成独立的上屏片段。

    反引号内外都会上屏——`lark-base`：多维表格 里的「多维表格」
    同样出现在画面上，不能只取反引号内的部分。
    """
    parts = [p for p in re.split(r"`", chunk) if p.strip()]
    out: list[str] = []
    for part in parts:
        out.extend(p.strip() for p in re.split(r"[/、，,：:]|→|与", part) if p.strip())
    return out


NEGATIONS = ("不", "勿", "未", "非", "禁止", "避免")


def positive_hit(text: str, word: str) -> bool:
    """出现该词、且不是「不裁切」这类否定式才算命中。

    构图里写「整张完整放入，不裁切」是正确写法，
    naive 子串匹配会把它误判成违规。
    """
    for m in re.finditer(re.escape(word), text):
        before = text[max(0, m.start() - 2):m.start()]
        if not any(neg in before for neg in NEGATIONS):
            return True
    return False


def check(path: Path) -> tuple[list[dict], dict]:
    text = path.read_text(encoding="utf-8")
    scenes = parse_scenes(text)
    failures: list[dict] = []

    if not scenes:
        failures.append({"gate": "G2", "scene": None, "message": "没有解析到任何分镜"})
        return failures, {"scenes": 0}

    # G1 复述检查
    for scene in scenes:
        fragments: list[str] = []
        for chunk in scene["on_screen"]:
            fragments.extend(split_fragments(chunk))
        narration = scene["narration"]
        if not narration or not fragments:
            continue

        for fragment in fragments:
            common = longest_common_substring(cjk_only(fragment), cjk_only(narration))
            if len(common) > MAX_TEXT_OVERLAP_CHARS:
                failures.append({
                    "gate": "G1a",
                    "scene": scene["index"],
                    "message": f"画面「{fragment}」与口播连续重合 {len(common)} 字：「{common}」",
                })

        ratio, hits = coverage_ratio(fragments, narration)
        if ratio >= COVERAGE_THRESHOLD:
            failures.append({
                "gate": "G1b",
                "scene": scene["index"],
                "message": (
                    f"口播被画面文案覆盖 {ratio:.0%}（阈值 {COVERAGE_THRESHOLD:.0%}）"
                    f"，命中：{'、'.join(hits)}"
                ),
            })

    # G2 时间轴
    cursor = scenes[0]["start"]
    if cursor != 0:
        failures.append({"gate": "G2", "scene": scenes[0]["index"], "message": f"首镜未从 0:00 开始，实际 {cursor}s"})
    for scene in scenes:
        if scene["start"] != cursor:
            failures.append({
                "gate": "G2",
                "scene": scene["index"],
                "message": f"时间轴不连续：上一镜结束 {cursor}s，本镜开始 {scene['start']}s",
            })
        if scene["end"] <= scene["start"]:
            failures.append({"gate": "G2", "scene": scene["index"], "message": "结束时间不大于开始时间"})
        cursor = max(cursor, scene["end"])

    total = cursor
    if not (DURATION_MIN_SEC <= total <= DURATION_MAX_SEC):
        failures.append({
            "gate": "G2",
            "scene": None,
            "message": f"成片时长 {total}s 超出 {DURATION_MIN_SEC}-{DURATION_MAX_SEC}s 窗口",
        })

    # G3 IP 次数
    ip_scenes = [s["index"] for s in scenes if s["ip"]]
    # Explicit per-production user request; decorative IP keeps the default cap.
    frontmatter = text.split("---", 2)[1] if text.startswith("---\n") else ""
    persistent = bool(re.search(r"^ip_mode: persistent_narrator\s*$", frontmatter, re.M))
    authorized = bool(re.search(r"^ip_mode_authorization: \S.+$", frontmatter, re.M))
    ip_limit = len(scenes) if persistent and authorized else IP_MAX_APPEARANCES
    if persistent and not authorized:
        failures.append({"gate": "G3", "scene": None, "message": "常驻讲解角色缺少用户授权记录 ip_mode_authorization"})
    if len(ip_scenes) > ip_limit:
        failures.append({
            "gate": "G3",
            "scene": None,
            "message": f"IP 出现 {len(ip_scenes)} 镜（{ip_scenes}），上限 {ip_limit}",
        })

    # G4 截图处理
    for scene in scenes:
        if not scene["images"]:
            continue
        blob = " ".join(scene["notes"])
        hit = [w for w in CROP_WORDS if positive_hit(blob, w)]
        if hit:
            failures.append({
                "gate": "G4",
                "scene": scene["index"],
                "message": f"截图必须整张放入，构图里出现了{'/'.join(hit)}",
            })

    summary = {
        "scenes": len(scenes),
        "duration_sec": total,
        "ip_scenes": ip_scenes,
    }
    return failures, summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("script", type=Path)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if not args.script.exists():
        print(f"找不到文件：{args.script}", file=sys.stderr)
        return 2

    failures, summary = check(args.script)

    if args.json:
        print(json.dumps({"ok": not failures, "failures": failures, "summary": summary}, ensure_ascii=False, indent=2))
    else:
        print(f"分镜数 {summary.get('scenes')}｜时长 {summary.get('duration_sec')}s｜IP 镜 {summary.get('ip_scenes')}")
        if not failures:
            print("闸门1 通过")
        else:
            print(f"闸门1 未通过，{len(failures)} 项：")
            for item in failures:
                scene = f"镜{item['scene']:02d}" if item["scene"] else "全片"
                print(f"  [{item['gate']}] {scene} {item['message']}")

    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
