#!/usr/bin/env python3
"""闸门2.5 — 成片自检。渲染之后、交给人看之前，先判「片子是不是坏的」。

    R1 文件      — 存在且非空
    R2 轨道      — 视频流和音频流都在
    R3 时长      — 成片时长与生产 tsx 的 ranges 推算值一致
    R4 音频      — 不是静音；顺带报削顶
    R5 黑帧      — 全片无黑帧段
    R6 末态帧    — 每镜末态帧不是空白（素材没加载出来的典型症状）

为什么要有这一道：
    闸门1 查文本、闸门2 查代码、闸门3 查单帧——三道全部发生在成片**之前**，
    没有任何一道碰过最终那个 mp4。音轨没挂上、渲染中途素材加载失败、
    帧率漂移导致成片和 timeline 对不上，这三类问题前面三道一道都看不见。

    这些都是机器 3 秒能判的事，不该占用使用者的眼睛。人的注意力要留给
    闸门3 那层——截图字段可读性、IP 压不压字幕、计算式动效对不对得上。

本机没有 ffprobe（ffmpeg 是 imageio_ffmpeg 的单文件二进制，
不带 ffprobe），所以全部信息从 `ffmpeg -i` 的 stderr 和滤镜输出里解析。

用法:
    check_render.py <成片.mp4> <生产.tsx> [--frames-dir DIR] [--sheet PATH]
"""

from __future__ import annotations

import argparse
import re
import subprocess
from pathlib import Path

FFMPEG = "ffmpeg"

# 与 tts_cosyvoice.py 的 FPS 保持一致
EXPECTED_FPS = 30

# 成片时长与 tsx ranges 推算值的最大允许偏差（秒）。
# 容器时长会比帧数算出来的略长一点点（末帧要占满一个帧时长），
# 0.5s 足够容纳它，又能挡住帧率漂移这类真问题。
DURATION_TOLERANCE_SEC = 0.5

# 交付窗口。这条只警告不阻断——超窗是内容判断不是损坏，
# 而且已知有例外（CNT-EXAMPLE-001 为 62s，作为闸门回归用例保留不重渲）。
MIN_SEC, MAX_SEC = 30, 60

# 静音判定。实测一条正常成片 mean −30.3 dB / max −4.5 dB，
# ffmpeg 对纯静音轨报 −91 dB。−50 落在两者之间，留足余量。
SILENT_MEAN_DB = -50.0
# 超过这个值说明电平顶到天花板，可能削顶。只警告。
CLIP_MAX_DB = -0.5

# 末态帧空白判定：整帧灰度标准差低于此值即视为「一片死色」。
# 正常成片的末态帧有标题+支撑信息+IP，标准差都在 30 以上（见 --calibrate）。
BLANK_STD_THRESHOLD = 8.0

RANGES = re.compile(r"const\s+(?:scene)?[Rr]anges\s*=\s*\[(.*?)\];", re.S)
ITEM = re.compile(r"\{from:\s*(\d+),\s*duration:\s*(\d+)\}")

DURATION_RE = re.compile(r"Duration:\s*(\d+):(\d+):(\d+\.?\d*)")
VIDEO_RE = re.compile(r"Stream #\d+:\d+.*: Video: ")
AUDIO_RE = re.compile(r"Stream #\d+:\d+.*: Audio: ")
FPS_RE = re.compile(r"(\d+(?:\.\d+)?)\s*fps")
MEAN_RE = re.compile(r"mean_volume:\s*(-?\d+\.?\d*)\s*dB")
MAX_RE = re.compile(r"max_volume:\s*(-?\d+\.?\d*)\s*dB")
BLACK_RE = re.compile(r"black_start:(\d+\.?\d*)\s+black_end:(\d+\.?\d*)")


def run(args: list[str]) -> str:
    """跑 ffmpeg，把 stdout+stderr 合并返回。ffmpeg 的探测信息都在 stderr。"""
    proc = subprocess.run(args, capture_output=True, text=True)
    return proc.stdout + proc.stderr


def probe(video: Path) -> dict:
    out = run([FFMPEG, "-i", str(video)])
    info: dict = {"has_video": bool(VIDEO_RE.search(out)), "has_audio": bool(AUDIO_RE.search(out))}
    m = DURATION_RE.search(out)
    if m:
        h, mm, s = m.groups()
        info["duration"] = int(h) * 3600 + int(mm) * 60 + float(s)
    vline = next((ln for ln in out.splitlines() if VIDEO_RE.search(ln)), "")
    f = FPS_RE.search(vline)
    if f:
        info["fps"] = float(f.group(1))
    return info


def expected_frames(production: Path) -> int | None:
    """从生产 tsx 解析 ranges，算出总帧数。与 _scene_mids.py 用同一套正则。"""
    block = RANGES.search(production.read_text(encoding="utf-8"))
    if not block:
        return None
    items = ITEM.findall(block.group(1))
    if not items:
        return None
    start, duration = items[-1]
    return int(start) + int(duration)


def end_state_frames(production: Path) -> list[int]:
    """每镜末态帧号。退 4 帧避开退场淡出——与 _scene_mids.py 完全一致，
    这样自检抽的帧和闸门3 看的帧是同一批，两边不会各说各话。"""
    block = RANGES.search(production.read_text(encoding="utf-8"))
    if not block:
        return []
    return [
        int(s) + max(0, int(d) - 4) for s, d in ITEM.findall(block.group(1))
    ]


def extract_frames(video: Path, frames: list[int], out_dir: Path) -> list[Path]:
    """一次解码抽出所有末态帧。用 select 多条件而不是逐帧 -ss，
    既准确（不走关键帧近似）又只解一遍。"""
    out_dir.mkdir(parents=True, exist_ok=True)
    for old in out_dir.glob("f*.png"):
        old.unlink()
    expr = "+".join(f"eq(n\\,{n})" for n in frames)
    run([
        FFMPEG, "-y", "-i", str(video),
        "-vf", f"select='{expr}'",
        "-vsync", "0",
        str(out_dir / "f%02d.png"),
    ])
    return sorted(out_dir.glob("f*.png"))


def frame_stddev(path: Path) -> float:
    from PIL import Image
    import numpy as np

    with Image.open(path) as im:
        arr = np.asarray(im.convert("L"), dtype="float32")
    return float(arr.std())


def contact_sheet(frames: list[Path], dst: Path) -> bool:
    """自检抽帧拼版。这是从成片里抽的，不重新渲染，
    所以不替代 qa_shot.sh——那边是 remotion still，用途是逐镜边写边看。"""
    if not frames:
        return False
    from PIL import Image

    thumbs = []
    for f in frames:
        with Image.open(f) as im:
            im = im.convert("RGB")
            thumbs.append(im.resize((270, round(270 * im.height / im.width))))
    half = max(1, len(thumbs) // 2)
    rows = [thumbs[:half], thumbs[half:]] if len(thumbs) > half else [thumbs]
    rows = [r for r in rows if r]
    width = max(sum(t.width for t in r) for r in rows)
    height = sum(max(t.height for t in r) for r in rows)
    sheet = Image.new("RGB", (width, height), (20, 20, 20))
    y = 0
    for row in rows:
        x = 0
        for t in row:
            sheet.paste(t, (x, y))
            x += t.width
        y += max(t.height for t in row)
    dst.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(dst)
    return True


def check(video: Path, production: Path,
          frames_dir: Path, sheet: Path | None) -> tuple[list[dict], list[dict], dict]:
    failures: list[dict] = []
    warnings: list[dict] = []
    stats: dict = {}

    # R1 文件
    if not video.exists():
        return [{"gate": "R1", "message": f"成片不存在：{video}"}], warnings, stats
    size = video.stat().st_size
    stats["size_mb"] = round(size / 1024 / 1024, 2)
    if size == 0:
        return [{"gate": "R1", "message": "成片是 0 字节"}], warnings, stats

    info = probe(video)

    # R2 轨道
    if not info.get("has_video"):
        failures.append({"gate": "R2", "message": "成片没有视频流"})
    if not info.get("has_audio"):
        failures.append({"gate": "R2", "message": "成片没有音频流——配音没挂进去"})

    # R3 时长
    dur = info.get("duration")
    fps = info.get("fps")
    stats["duration"] = dur
    stats["fps"] = fps
    total = expected_frames(production)
    if dur is None:
        failures.append({"gate": "R3", "message": "解析不到成片时长，文件可能损坏"})
    else:
        if fps and abs(fps - EXPECTED_FPS) > 0.01:
            failures.append({"gate": "R3", "message": f"帧率是 {fps}，应为 {EXPECTED_FPS}"})
        if total:
            expect = total / (fps or EXPECTED_FPS)
            stats["expect_duration"] = round(expect, 2)
            if abs(dur - expect) > DURATION_TOLERANCE_SEC:
                failures.append({
                    "gate": "R3",
                    "message": f"成片 {dur:.2f}s 与 tsx ranges 推算的 {expect:.2f}s 对不上"
                               f"（差 {abs(dur - expect):.2f}s）",
                })
        else:
            warnings.append({"gate": "R3", "message": "生产 tsx 里没解析到 ranges，跳过时长比对"})
        if not (MIN_SEC <= dur <= MAX_SEC):
            warnings.append({"gate": "R3", "message": f"成片 {dur:.2f}s 不在 {MIN_SEC}-{MAX_SEC}s 交付窗口内"})

    # R4 音频
    if info.get("has_audio"):
        out = run([FFMPEG, "-i", str(video), "-af", "volumedetect", "-f", "null", "-"])
        mean = MEAN_RE.search(out)
        mx = MAX_RE.search(out)
        if mean:
            stats["mean_db"] = float(mean.group(1))
            if float(mean.group(1)) < SILENT_MEAN_DB:
                failures.append({
                    "gate": "R4",
                    "message": f"音轨基本是静音（mean {mean.group(1)} dB）",
                })
        else:
            warnings.append({"gate": "R4", "message": "解析不到音量，跳过静音判定"})
        if mx:
            stats["max_db"] = float(mx.group(1))
            if float(mx.group(1)) > CLIP_MAX_DB:
                warnings.append({
                    "gate": "R4",
                    "message": f"峰值 {mx.group(1)} dB，可能削顶",
                })

    # R5 黑帧
    if info.get("has_video"):
        out = run([
            FFMPEG, "-i", str(video),
            "-vf", "blackdetect=d=0.05:pix_th=0.10",
            "-f", "null", "-",
        ])
        blacks = BLACK_RE.findall(out)
        stats["black_segments"] = len(blacks)
        for start, end in blacks:
            failures.append({
                "gate": "R5",
                "message": f"检出黑帧段 {start}s → {end}s",
            })

    # R6 末态帧
    wanted = end_state_frames(production)
    if not wanted:
        warnings.append({"gate": "R6", "message": "解析不到 ranges，跳过末态帧检查"})
    elif info.get("has_video"):
        got = extract_frames(video, wanted, frames_dir)
        stats["frames"] = len(got)
        if len(got) != len(wanted):
            warnings.append({
                "gate": "R6",
                "message": f"预期抽 {len(wanted)} 帧，实际抽到 {len(got)} 帧",
            })
        stds = []
        for i, f in enumerate(got, 1):
            std = frame_stddev(f)
            stds.append(round(std, 1))
            if std < BLANK_STD_THRESHOLD:
                failures.append({
                    "gate": "R6",
                    "message": f"镜{i:02d} 末态帧接近纯色（标准差 {std:.1f}）——素材大概率没加载出来",
                })
        stats["frame_std"] = stds
        if sheet:
            if contact_sheet(got, sheet):
                stats["sheet"] = str(sheet)

    return failures, warnings, stats


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("video", type=Path)
    ap.add_argument("production", type=Path)
    ap.add_argument("--frames-dir", type=Path, default=None)
    ap.add_argument("--sheet", type=Path, default=None)
    args = ap.parse_args()

    frames_dir = args.frames_dir or args.video.parent / "selfcheck" / args.video.stem
    sheet = args.sheet if args.sheet is not None else frames_dir / "contact-sheet.png"

    failures, warnings, stats = check(args.video, args.production, frames_dir, sheet)

    if stats.get("duration") is not None:
        line = f"时长 {stats['duration']:.2f}s"
        if stats.get("expect_duration") is not None:
            line += f"（tsx 推算 {stats['expect_duration']}s）"
        if stats.get("fps"):
            line += f" · {stats['fps']:g}fps"
        line += f" · {stats.get('size_mb', '?')}MB"
        print(line)
    if "mean_db" in stats:
        print(f"音频 mean {stats['mean_db']} dB · max {stats.get('max_db', '?')} dB")
    if "frame_std" in stats:
        print(f"末态帧 {stats.get('frames', 0)} 张 · 标准差 {stats['frame_std']}")
    if stats.get("sheet"):
        print(f"自检抽帧 {stats['sheet']}")

    for w in warnings:
        print(f"\033[33m! {w['gate']} {w['message']}\033[0m")

    if failures:
        print(f"\n\033[31m✗ 成片自检未通过（{len(failures)} 项）\033[0m")
        for f in failures:
            print(f"  \033[31m{f['gate']}\033[0m {f['message']}")
        return 1

    print("\n\033[32m✓ 成片自检通过\033[0m")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
