#!/usr/bin/env python3
"""从生产 tsx 里解析 ranges，输出每镜的**末态帧**，一行一个。

给 qa_shot.sh 用。

原来取的是中点。中点错的原因：画面按字幕逐句推进（见 motion-scheduling.md），
中点时后半段元素根本还没入场，代表帧看起来大片空白——既误导人去"修留白"，
也没法判断这一镜最终长什么样。

末态（末帧前 4 帧，避开退场淡出）才是元素到齐的完整画面，
也是「每镜必须能独立成图」这条规则的检查对象——使用者会把它们转成小绿书图文发。
"""

import pathlib
import re
import sys

RANGES = re.compile(r"const\s+(?:scene)?[Rr]anges\s*=\s*\[(.*?)\];", re.S)
ITEM = re.compile(r"\{from:\s*(\d+),\s*duration:\s*(\d+)\}")


def main() -> int:
    if len(sys.argv) < 2:
        print("用法: _scene_mids.py <生产.tsx>", file=sys.stderr)
        return 2
    src = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
    block = RANGES.search(src)
    if not block:
        print("没有解析到 ranges", file=sys.stderr)
        return 2
    for start, duration in ITEM.findall(block.group(1)):
        # 退 4 帧避开可能的退场淡出，同时保证所有入场都已落定
        print(int(start) + max(0, int(duration) - 4))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
