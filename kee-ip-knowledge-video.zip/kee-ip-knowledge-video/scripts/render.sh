#!/bin/bash
# 出片唯一入口。闸门是渲染的前置和后置条件，不是可选步骤。
#
# 用法:
#   ./scripts/render.sh <分镜脚本.md> <ProductionVideoX.tsx> <CompositionId> <输出.mp4>
#
# 为什么要有这个脚本：
#   settings.json 的 hook 只在 Claude Code 里生效，Codex 和别的 agent 没有
#   同等机制。但「渲染」是任何 agent 都绕不过的一步——把闸门焊在渲染前面，
#   就跟具体 harness 无关了。
#
#   同一条理由也适用于渲染之后：成片自检要是做成独立脚本，就又回到
#   「靠人记得调用」。所以「渲完不自检就不算出片」也焊在这里。
#
# 闸门1/2 不通过即中止，不会产出片子。
# 闸门2.5 不通过则片子停在 .pending 上，拿不到正式文件名，归档不走它。

set -uo pipefail

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LIB="$SKILL_DIR/remotion-library"

SCRIPT_MD="${1:?用法: render.sh <分镜稿.md> <生产.tsx> <CompositionId> <输出.mp4>}"
PRODUCTION="${2:?缺少生产 tsx}"
COMPOSITION="${3:?缺少 Composition id}"
OUTPUT="${4:?缺少输出路径}"

fail() { printf '\n\033[31m✗ %s\033[0m\n' "$1" >&2; exit 1; }
step() { printf '\n\033[36m▌%s\033[0m\n' "$1"; }

# 渲染要 cd 进 remotion-library，所以输出路径必须先转成绝对路径。
# 否则相对路径会解析成 remotion-library/<相对路径>，片子落在错的地方，
# 而末尾的成功提示打印的还是调用者给的那个路径——报一个不存在的位置。
case "$OUTPUT" in
  /*) ;;
  *) OUTPUT="$(pwd)/$OUTPUT" ;;
esac
mkdir -p "$(dirname "$OUTPUT")"

step "闸门1 — 分镜"
python3 "$SKILL_DIR/scripts/check_script.py" "$SCRIPT_MD" || fail "闸门1 未通过，修完再渲染"

step "闸门2 — 构建"
python3 "$SKILL_DIR/scripts/check_sync.py" "$PRODUCTION" || fail "闸门2 未通过，修完再渲染"

step "类型检查"
(cd "$LIB" && npx tsc --noEmit) || fail "tsc 未通过"

step "渲染"
# 先渲进隐藏的 .pending/ 隔离目录，自检过了才搬到正式位置。
#
# 前置闸门失败是「片子没产生」，干净；成片自检失败时片子已经在磁盘上了，
# exit 1 撤不回它。只打印一行红字提醒，等于把「别归档这个」交给记性——
# 而归档规则是默认全量覆盖不问，一次手滑就会用坏片盖掉上一版好的。
# 关在 .pending/ 里，归档那步物理上就拿不到它。
#
# 文件名必须保留 .mp4：remotion 校验输出扩展名，h264+aac 只认
# mp4/mkv/mov，叫 xxx.mp4.pending 会在渲染前就被拒。所以隔离靠目录，
# 不靠后缀——而且 .pending/ 以点开头，`*.mp4` 通配和 Finder 都不会碰它。
PENDING_DIR="$(dirname "$OUTPUT")/.pending"
PENDING="$PENDING_DIR/$(basename "$OUTPUT")"
rm -rf "$PENDING_DIR"
mkdir -p "$PENDING_DIR"
(cd "$LIB" && npx remotion render src/index.ts "$COMPOSITION" "$PENDING" --log=error) \
  || fail "渲染失败"

step "闸门2.5 — 成片自检"
SELFCHECK_DIR="$(dirname "$OUTPUT")/selfcheck/$(basename "${OUTPUT%.mp4}")"
SHEET="$SELFCHECK_DIR/contact-sheet.png"
if ! python3 "$SKILL_DIR/scripts/check_render.py" "$PENDING" "$PRODUCTION" \
       --frames-dir "$SELFCHECK_DIR" --sheet "$SHEET"; then
  printf '\n\033[31m✗ 成片未通过自检，扣在 %s\033[0m\n' "$PENDING" >&2
  printf '  没搬到正式位置，不得归档。修完重跑本脚本。\n' >&2
  exit 1
fi

mv -f "$PENDING" "$OUTPUT"
rmdir "$PENDING_DIR" 2>/dev/null

printf '\n\033[32m✓ 已出片：%s\033[0m\n' "$OUTPUT"
printf '\n\033[36m▌轮到人看了 — 闸门3\033[0m\n'
printf '  自检抽帧：%s\n' "$SHEET"
printf '  确认三件事（机器判不了）：\n'
printf '    1 计算式动效（delay={base + i * step}）是否跟口播对上\n'
printf '    2 截图里关键字段是否真的可读\n'
printf '    3 IP 与文字、IP 与字幕是否重叠\n'
printf '  过了才归档到 03-产出/，五项一起覆盖（预览 / sheet / 分镜脚本.md / 字幕 / 音频）。\n'
