#!/bin/bash
# PostToolUse hook：写入分镜脚本或生产 tsx 后自动跑对应闸门。
#
# 闸门本身只要几十毫秒，但它们此前只有 agent 记得跑才会跑——
# 一旦漏掉，坏片就直接出去了。这个 hook 把「记得跑」从自觉变成机制。
#
# 输入：PostToolUse 的 JSON（stdin）
# 输出：闸门失败时吐一段 JSON，把失败原因塞回 agent 的上下文

set -uo pipefail

SKILL_DIR="$HOME/.codex/skills/kee-ip-knowledge-video"
PAYLOAD=$(cat)
FILE=$(printf '%s' "$PAYLOAD" | jq -r '.tool_input.file_path // .tool_response.filePath // empty' 2>/dev/null)

[ -z "$FILE" ] && exit 0
[ -f "$FILE" ] || exit 0

# 回归用例是冻结的问题样本，本来就应该报错，不要在这里刷屏
case "$FILE" in
  */scripts/regression/*) exit 0 ;;
esac

# 按文件名匹配，不按路径——否则 `短视频/` 目录下的任何 md（口播稿、
# 发布记录、数据复盘）都会误触发分镜闸门，去检查一个还不该存在的东西
case "$(basename "$FILE")" in
  分镜脚本*.md|短视频*.md) GATE="check_script.py"; NAME="闸门1（分镜）" ;;
  ProductionVideo*.tsx)  GATE="check_sync.py";   NAME="闸门2（构建）" ;;
  *)                     exit 0 ;;
esac

OUTPUT=$(python3 "$SKILL_DIR/scripts/$GATE" "$FILE" 2>&1)
STATUS=$?

[ $STATUS -eq 0 ] && exit 0

# 用 jq 组装 JSON，避免闸门输出里的引号和换行破坏格式
jq -n --arg name "$NAME" --arg file "$(basename "$FILE")" --arg out "$OUTPUT" \
  '{
     systemMessage: ($name + " 未通过：" + $file),
     hookSpecificOutput: {
       hookEventName: "PostToolUse",
       additionalContext: ($name + " 检出问题，必须修完再往下走：\n\n" + $out)
     }
   }'
exit 0
