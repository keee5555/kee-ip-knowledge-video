#!/usr/bin/env python3
"""闸门2 — 构建闸门。在 Remotion 渲染之前跑，针对生产 tsx。

用法:
    python3 check_sync.py <ProductionVideoX.tsx> [--json]

检查项:
    G5 音画同步 — 具名元素出现帧与对应口播句起始帧的偏差
    G6 帧覆盖   — 场景区间连续、总帧数在 30-60 秒窗口内
    G7 复述复查 — tsx 里的上屏中文串与同期字幕的重合（防设计到实现的漂移）
    G8 布局契约 — 字幕必须走 SafeCaption；场景内容不得越过 SCENE_CONTENT_MAX_Y
    G9 元素重叠 — 同场景内左侧文字块与右侧图元的水平重叠
    G10 图元压字幕 — 右锚图元（IP 立绘）的底边越过字幕顶边
    G11 单字成行  — 会自动折行的长文本未声明 textWrap，末行可能只剩一个字
    G12 字幕折行  — 单条字幕超过一行容量，会在词中间断开甚至单字成行
    G13 轮播过快  — 图片轮播每张停留不足下限，观众看不清
    G14 画面发呆  — 最后一次画面动作之后还有大段口播，屏幕静止太久

已知边界:
    G5 只覆盖写成字面量的具名元素（title="X" + delay={N}）。
    形如 delay={base + i * step} 的行级动画属于计算式，静态解析看不到，
    需要在闸门3 的代表帧里人工确认。
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

FPS = 30
# 与 remotion-library/src/layout.ts 保持一致
SAFE_AREA_BOTTOM = 240
CAPTION_BLOCK_HEIGHT = 141
CAPTION_CLEARANCE = 24
SCENE_CONTENT_MAX_Y = 1920 - SAFE_AREA_BOTTOM - CAPTION_BLOCK_HEIGHT - CAPTION_CLEARANCE
# 单行文字的保守高度，用于把 top 换算成底边
MIN_TEXT_HEIGHT = 60
SYNC_TOLERANCE_FRAMES = 15
MAX_TEXT_OVERLAP_CHARS = 12
COVERAGE_THRESHOLD = 0.35
DURATION_MIN_FRAMES = 30 * FPS
DURATION_MAX_FRAMES = 60 * FPS

CJK = re.compile(r"[一-鿿]")
RANGE_ITEM = re.compile(r"\{from:\s*(\d+),\s*duration:\s*(\d+)\}")
CUE_ITEM = re.compile(r"\{from:\s*(\d+),\s*to:\s*(\d+),\s*text:\s*'([^']*)'\}")
SCENE_BLOCK = re.compile(r"const\s+Scene(\d+)[A-Z]?\s*:\s*React\.FC")
TITLED_DELAY = re.compile(r'title="([^"]+)"[^>]*?delay=\{(\d+)\}')
TOP_LITERAL = re.compile(r"top:\s*(\d+)")
BOTTOM_LITERAL = re.compile(r"bottom:\s*(\d+)")
STRING_LITERAL = re.compile(r"'([^']*)'|\"([^\"]*)\"|>([^<>{}]+)<")
CANVAS_WIDTH = 1080
# IP 立绘 941x1672；闸门用它把 width 换算成高度
IP_ASPECT_RATIO = 1672 / 941
CAPTION_TOP = 1920 - SAFE_AREA_BOTTOM - CAPTION_BLOCK_HEIGHT
# 两个元素竖直方向差在这个范围内才算可能撞上
VERTICAL_PROXIMITY = 300
# 超过这个字数的中文串在 900 宽内必然折行，必须声明 textWrap
WRAP_RISK_CHARS = 14
# 字幕单行容量：maxWidth 910 / fontSize 38 ≈ 24 字，留 2 字余量
MAX_CAPTION_CHARS = 22
# 轮播类画面每张至少要停这么久，否则观众根本看不清
MIN_DWELL_FRAMES = 60
# 一镜里「最后一次画面动作」之后允许的最长静止。
# 超过它就是口播还在说、画面已经不动了。实测 CNT-EXAMPLE-001 首版
# 全片 58% 时间静止，最严重的镜静止 79%。
MAX_STATIC_FRAMES = 75
# 形如 const TABLES = [...] 的轮播数据 + 场景里的 per 计算
CAROUSEL_DATA = re.compile(r"^const\s+(\w+)\s*=\s*\[\s*\n(\s*\{file:.*?)\];", re.S | re.M)
# left + top + width 的定位块
LEFT_BOX = re.compile(r"left:\s*(\d+),\s*top:\s*(\d+),\s*width:\s*(\d+)")
# right + top 容器里裹着一个带 width 的图元（IP 通常是这种写法）
RIGHT_BOX = re.compile(r"right:\s*(-?\d+),\s*top:\s*(\d+)\}\}>\s*<\w+\s+width=\{(\d+)\}")


def cjk_only(text: str) -> str:
    return "".join(CJK.findall(text))


def longest_common_substring(a: str, b: str) -> str:
    best = ""
    for start in range(len(a)):
        for end in range(len(a), start + len(best), -1):
            chunk = a[start:end]
            if chunk in b:
                if len(chunk) > len(best):
                    best = chunk
                break
    return best


def parse_ranges(src: str) -> list[tuple[int, int]]:
    match = re.search(r"const\s+(?:scene)?[Rr]anges\s*=\s*\[(.*?)\];", src, re.S)
    if not match:
        return []
    return [(int(a), int(b)) for a, b in RANGE_ITEM.findall(match.group(1))]


def parse_cues(src: str) -> list[tuple[int, int, str]]:
    # 允许 `const captions: CaptionCue[] = [...]` 这种带类型标注的写法
    match = re.search(r"const\s+(?:captions|subtitles|cues)\s*(?::[^=]+)?=\s*\[(.*?)\];", src, re.S)
    if not match:
        return []
    return [(int(a), int(b), t) for a, b, t in CUE_ITEM.findall(match.group(1))]


def scene_blocks(src: str) -> list[tuple[int, str]]:
    """返回 [(场景序号, 该场景源码), ...]"""
    marks = [(m.start(), int(m.group(1))) for m in SCENE_BLOCK.finditer(src)]
    blocks: list[tuple[int, str]] = []
    for i, (pos, index) in enumerate(marks):
        end = marks[i + 1][0] if i + 1 < len(marks) else len(src)
        blocks.append((index, src[pos:end]))
    return blocks


TOP_LEVEL_CONST = re.compile(r"^const\s+(\w+)\s*=\s*(\[.*?\]);", re.S | re.M)


def top_level_data(src: str) -> dict[str, str]:
    """顶层的数据数组（如 leftSkills / dataItems）也会上屏，
    但它们定义在场景函数之外，必须按引用并回场景里检查。"""
    out: dict[str, str] = {}
    for name, body in TOP_LEVEL_CONST.findall(src):
        if name in {"ranges", "sceneRanges", "captions", "subtitles", "cues", "scenes"}:
            continue
        out[name] = body
    return out


def on_screen_strings(block: str, data: dict[str, str]) -> list[str]:
    """抽出该场景里会上屏的中文串，含它引用的顶层数据数组。"""
    text = block
    for name, body in data.items():
        if re.search(rf"\{{{re.escape(name)}\}}", block) or re.search(rf"\b{re.escape(name)}\b", block):
            text += "\n" + body
    out: list[str] = []
    for groups in STRING_LITERAL.findall(text):
        for value in groups:
            piece = cjk_only(value)
            if len(piece) >= 2:
                out.append(piece)
    return out


def check(path: Path) -> tuple[list[dict], dict]:
    src = path.read_text(encoding="utf-8")
    failures: list[dict] = []

    ranges = parse_ranges(src)
    cues = parse_cues(src)
    blocks = scene_blocks(src)
    data = top_level_data(src)

    if not ranges:
        failures.append({"gate": "G6", "scene": None, "message": "没有解析到 ranges"})
        return failures, {}
    if not cues:
        failures.append({"gate": "G5", "scene": None, "message": "没有解析到字幕数组"})

    # G6 帧覆盖
    cursor = 0
    for i, (start, duration) in enumerate(ranges, 1):
        if start != cursor:
            failures.append({"gate": "G6", "scene": i, "message": f"帧区间不连续：应从 {cursor} 开始，实际 {start}"})
        cursor = start + duration
    total = cursor
    if not (DURATION_MIN_FRAMES <= total <= DURATION_MAX_FRAMES):
        failures.append({
            "gate": "G6",
            "scene": None,
            "message": f"总帧数 {total}（{total / FPS:.1f}s）超出 {DURATION_MIN_FRAMES}-{DURATION_MAX_FRAMES} 帧窗口",
        })

    # G8 布局契约
    if "SafeCaption" not in src:
        failures.append({"gate": "G8", "scene": None, "message": "未使用 SafeCaption，字幕被内联重写"})
    for value in {int(v) for v in BOTTOM_LITERAL.findall(src)}:
        if 0 < value < SAFE_AREA_BOTTOM:
            failures.append({
                "gate": "G8",
                "scene": None,
                "message": f"存在 bottom: {value}，低于安全区下沿 {SAFE_AREA_BOTTOM}",
            })

    for index, block in blocks:
        for raw in {int(v) for v in TOP_LITERAL.findall(block)}:
            if raw + MIN_TEXT_HEIGHT > SCENE_CONTENT_MAX_Y:
                failures.append({
                    "gate": "G8",
                    "scene": index,
                    "message": (
                        f"top: {raw} 的元素底边将越过 {SCENE_CONTENT_MAX_Y}，会被字幕遮挡"
                    ),
                })

    # G9 左锚文字块 与 右锚图元 的水平重叠（典型是正文被 IP 压住）
    #
    # 只比对「左锚 × 右锚」这一种组合：同为左锚的块在一列里上下堆叠是正常排版，
    # 静态解析拿不到元素高度，拿 top 差当垂直重叠的代理会大量误报。
    for index, block in blocks:
        lefts = [
            (int(m.group(1)), int(m.group(1)) + int(m.group(3)), int(m.group(2)))
            for m in LEFT_BOX.finditer(block)
        ]
        rights = [
            (CANVAS_WIDTH - int(m.group(1)) - int(m.group(3)), CANVAS_WIDTH - int(m.group(1)), int(m.group(2)))
            for m in RIGHT_BOX.finditer(block)
        ]
        for a0, a1, top_a in lefts:
            for b0, b1, top_b in rights:
                overlap = min(a1, b1) - max(a0, b0)
                if overlap > 0 and abs(top_a - top_b) < VERTICAL_PROXIMITY:
                    failures.append({
                        "gate": "G9",
                        "scene": index,
                        "message": (
                            f"左锚文字块[{a0},{a1}] 与 右锚图元[{b0},{b1}] 水平重叠 {overlap}px"
                        ),
                    })

    # G10 右锚图元不得压住字幕
    for index, block in blocks:
        for m in RIGHT_BOX.finditer(block):
            top, width = int(m.group(2)), int(m.group(3))
            bottom = top + round(width * IP_ASPECT_RATIO)
            if bottom > CAPTION_TOP:
                failures.append({
                    "gate": "G10",
                    "scene": index,
                    "message": (
                        f"右锚图元 top={top} width={width} 底边到 {bottom}，"
                        f"越过字幕顶边 {CAPTION_TOP}，会压住字幕"
                    ),
                })

    # G11 会折行的长文本必须声明 textWrap，禁止单字成行
    for index, block in blocks:
        # 手写 <br /> 的多行文本由作者自己断行，不在检查范围
        for m in re.finditer(r">\s*([^<>{}]{%d,})\s*<" % WRAP_RISK_CHARS, block):
            text = m.group(1).strip()
            if len(cjk_only(text)) < WRAP_RISK_CHARS:
                continue
            # 往前找最近的 style={{...}}，看有没有 textWrap
            head = block[max(0, m.start() - 700):m.start()]
            if "textWrap" not in head:
                failures.append({
                    "gate": "G11",
                    "scene": index,
                    "message": f"长文本「{text[:18]}…」会自动折行但未声明 textWrap，可能单字成行",
                })

    # G12 字幕必须一行放得下
    for cue_from, _cue_to, text in cues:
        if len(text) > MAX_CAPTION_CHARS:
            failures.append({
                "gate": "G12",
                "scene": None,
                "message": f"字幕「{text}」{len(text)} 字，超过单行容量 {MAX_CAPTION_CHARS}，会折行",
            })

    # G13 轮播每张停留不得低于下限
    carousel = CAROUSEL_DATA.search(src)
    if carousel:
        n_items = carousel.group(2).count("{file:")
        name = carousel.group(1)
        # 顶层常量若定义在两个 Scene 之间，会被切分算进前一个场景的块里。
        # 所以要求「真的用到」（NAME.map / NAME[i] / NAME.length），而不只是出现过。
        used = re.compile(rf"\b{re.escape(name)}\s*[.\[]")
        for index, block in blocks:
            if index > len(ranges) or not used.search(block):
                continue
            duration = ranges[index - 1][1]
            intro = int(m.group(1)) if (m := re.search(r"frame - (\d+)\) / per", block)) else 0
            per = (duration - intro) / max(1, n_items)
            if per < MIN_DWELL_FRAMES:
                failures.append({
                    "gate": "G13",
                    "scene": index,
                    "message": (
                        f"{n_items} 张轮播分 {duration - intro} 帧，每张仅 {per:.0f} 帧"
                        f"（{per / FPS:.2f}s），低于下限 {MIN_DWELL_FRAMES} 帧（2s）"
                    ),
                })

    # G14 画面不能在口播说完前就停住
    for index, block in blocks:
        if index > len(ranges):
            continue
        scene_from, duration = ranges[index - 1]
        # 该镜所有写成字面量的 delay，取最大值当作「最后一次画面动作」
        delays = [int(d) for d in re.findall(r"delay(?:=\{|:\s*)(\d+)", block)]
        # 也认 rise(frame, N) / rise(useCurrentFrame(), N) 这种内联排期，
        # 否则用这种写法铺开的画面动作会被当成不存在
        delays += [int(d) for d in re.findall(r"rise\(\s*(?:frame|useCurrentFrame\(\))\s*,\s*(\d+)", block)]
        steps = [int(d) for d in re.findall(r"step(?:=\{|:\s*)(\d+)", block)]
        if not delays:
            continue
        last = max(delays)
        if steps:
            # 逐条式动效的末条还要往后推几拍
            last += max(steps) * 3
        last += 30  # 动效自身跑完
        static = duration - last
        if static > MAX_STATIC_FRAMES:
            failures.append({
                "gate": "G14",
                "scene": index,
                "message": (
                    f"最后一次画面动作约在第 {last} 帧，本镜共 {duration} 帧，"
                    f"之后静止 {static} 帧（{static / FPS:.1f}s，占 {static / duration:.0%}）；"
                    f"上限 {MAX_STATIC_FRAMES} 帧。用 scheduleByCues 按字幕铺开，"
                    f"或给长 hold 段套 LineBoil"
                ),
            })

    # G5 / G7 逐场景
    checked_elements = 0
    for index, block in blocks:
        if index > len(ranges):
            continue
        scene_from, duration = ranges[index - 1]
        scene_to = scene_from + duration
        scene_cues = [c for c in cues if c[0] < scene_to and c[1] > scene_from]
        narration = "".join(c[2] for c in scene_cues)

        # G5 具名元素同步
        for title, delay in TITLED_DELAY.findall(block):
            appear = scene_from + int(delay)
            target = next((c for c in scene_cues if title in c[2]), None)
            if target is None:
                continue
            checked_elements += 1
            # 一句话里点到多个对象时，元素在这句话期间依次出现都算对齐，
            # 所以判定的是「是否落在该句的时间窗内」，不是「是否贴着句首」。
            lo, hi = target[0] - SYNC_TOLERANCE_FRAMES, target[1] + SYNC_TOLERANCE_FRAMES
            if not (lo <= appear <= hi):
                drift = appear - target[0] if appear < target[0] else appear - target[1]
                direction = "提前" if drift < 0 else "滞后"
                failures.append({
                    "gate": "G5",
                    "scene": index,
                    "message": (
                        f"「{title}」画面第 {appear} 帧出现，口播讲到它的区间是 "
                        f"[{target[0]}, {target[1]}]，{direction} {abs(drift)} 帧"
                        f"（容差 {SYNC_TOLERANCE_FRAMES}）"
                    ),
                })

        # G7 复述复查
        fragments = on_screen_strings(block, data)
        if not narration or not fragments:
            continue
        target_cjk = cjk_only(narration)
        for fragment in fragments:
            common = longest_common_substring(fragment, target_cjk)
            if len(common) > MAX_TEXT_OVERLAP_CHARS:
                failures.append({
                    "gate": "G7",
                    "scene": index,
                    "message": f"画面「{fragment}」与字幕连续重合 {len(common)} 字：「{common}」",
                })

        covered = [False] * len(target_cjk)
        hits: list[str] = []
        for fragment in fragments:
            for match in re.finditer(re.escape(fragment), target_cjk):
                for i in range(match.start(), match.end()):
                    covered[i] = True
                if fragment not in hits:
                    hits.append(fragment)
        ratio = sum(covered) / len(target_cjk) if target_cjk else 0
        if ratio >= COVERAGE_THRESHOLD:
            failures.append({
                "gate": "G7",
                "scene": index,
                "message": f"字幕被画面覆盖 {ratio:.0%}（阈值 {COVERAGE_THRESHOLD:.0%}），命中：{'、'.join(hits)}",
            })

    summary = {
        "scenes": len(ranges),
        "total_frames": total,
        "duration_sec": round(total / FPS, 2),
        "cues": len(cues),
        "sync_checked": checked_elements,
    }
    return failures, summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("production", type=Path)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if not args.production.exists():
        print(f"找不到文件：{args.production}", file=sys.stderr)
        return 2

    failures, summary = check(args.production)

    if args.json:
        print(json.dumps({"ok": not failures, "failures": failures, "summary": summary}, ensure_ascii=False, indent=2))
    else:
        print(
            f"场景 {summary.get('scenes')}｜总帧 {summary.get('total_frames')}"
            f"（{summary.get('duration_sec')}s）｜字幕 {summary.get('cues')} 条"
            f"｜同步校验 {summary.get('sync_checked')} 个元素"
        )
        if not failures:
            print("闸门2 通过")
        else:
            print(f"闸门2 未通过，{len(failures)} 项：")
            for item in failures:
                scene = f"镜{item['scene']:02d}" if item["scene"] else "全片"
                print(f"  [{item['gate']}] {scene} {item['message']}")

    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
