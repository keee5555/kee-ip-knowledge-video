#!/bin/bash
# 逐镜验收：写完一镜立刻渲一张代表帧看，不等 8 镜全做完。
#
# 用法:
#   ./scripts/qa_shot.sh <ProductionVideoX.tsx> <CompositionId> <镜号>   单镜
#   ./scripts/qa_shot.sh <ProductionVideoX.tsx> <CompositionId> all      全部 + contact sheet
#
# 为什么逐镜:
#   渲染次数完全一样（8 镜就是 8 张），差别只在时机。
#   一起看 → 第 8 镜才发现第 2 镜错了，可能要重排后面所有镜。
#   逐镜看 → 第 2 镜当场发现，只废这一镜。
#   token 成本几乎相同，省的是返工。
#
# 代表帧取该镜的中点——入场动效已完成、退场还没开始，最能代表成品状态。
# 产物按 out/qa/<合成id>/ 归档，不散在 out/ 根目录。

set -uo pipefail

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LIB="$SKILL_DIR/remotion-library"
PARSER="$SKILL_DIR/scripts/_scene_mids.py"

PRODUCTION="${1:?用法: qa_shot.sh <生产.tsx> <CompositionId> <镜号|all>}"
COMPOSITION="${2:?缺少 Composition id}"
WHICH="${3:?缺少镜号或 all}"

[ -f "$PRODUCTION" ] || { echo "找不到生产文件：$PRODUCTION" >&2; exit 2; }

OUT_DIR="$LIB/out/qa/$COMPOSITION"
mkdir -p "$OUT_DIR"

# macOS 自带 bash 3.2 没有 mapfile，落地成临时文件再逐行读
MIDS_FILE=$(mktemp)
trap 'rm -f "$MIDS_FILE"' EXIT
python3 "$PARSER" "$PRODUCTION" > "$MIDS_FILE" || exit 2

TOTAL=$(wc -l < "$MIDS_FILE" | tr -d ' ')
[ "$TOTAL" -gt 0 ] || { echo "ranges 为空" >&2; exit 2; }

frame_of() { sed -n "${1}p" "$MIDS_FILE"; }

shoot() {
  n=$1
  frame=$(frame_of "$n")
  dst="$OUT_DIR/s$(printf '%02d' "$n").png"
  printf '\033[36m▌镜%02d\033[0m 第 %s 帧 → %s\n' "$n" "$frame" "${dst#"$LIB"/}"
  (cd "$LIB" && npx remotion still src/index.ts "$COMPOSITION" "${dst#"$LIB"/}" --frame="$frame" --log=error) \
    || { echo "渲染失败" >&2; return 1; }
}

if [ "$WHICH" = "all" ]; then
  n=1
  while [ "$n" -le "$TOTAL" ]; do
    shoot "$n" || exit 1
    n=$((n + 1))
  done

  # 拼 contact sheet，一屏看完
  SHEET="$OUT_DIR/contact-sheet.png"
  HALF=$((TOTAL / 2))
  ARGS=""
  FILT=""
  n=0
  while [ "$n" -lt "$TOTAL" ]; do
    ARGS="$ARGS -i $OUT_DIR/s$(printf '%02d' $((n + 1))).png"
    FILT="$FILT[$n:v]scale=270:-1[v$n];"
    n=$((n + 1))
  done
  n=0
  while [ "$n" -lt "$HALF" ]; do FILT="$FILT[v$n]"; n=$((n + 1)); done
  FILT="${FILT}hstack=inputs=$HALF[top];"
  while [ "$n" -lt "$TOTAL" ]; do FILT="$FILT[v$n]"; n=$((n + 1)); done
  FILT="${FILT}hstack=inputs=$((TOTAL - HALF))[bot];[top][bot]vstack=inputs=2"

  # shellcheck disable=SC2086
  ffmpeg -y $ARGS -filter_complex "$FILT" "$SHEET" >/dev/null 2>&1 \
    && printf '\n\033[32m✓ contact sheet：%s\033[0m\n' "${SHEET#"$LIB"/}"
else
  if [ "$WHICH" -lt 1 ] || [ "$WHICH" -gt "$TOTAL" ]; then
    echo "镜号超范围（共 $TOTAL 镜）" >&2
    exit 2
  fi
  shoot "$WHICH" || exit 1
fi

printf '\n看图时确认三件事（闸门2 都看不到）：\n'
printf '  1 计算式动效（delay={base + i * step}）是否跟口播对上\n'
printf '  2 截图里关键字段是否真的可读\n'
printf '  3 IP 与文字、IP 与字幕是否重叠\n'
